package uitl

import (
	"bytes"
	"crypto/md5"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	_ "github.com/go-sql-driver/mysql"
	"gopkg.in/gomail.v2"
	"io/ioutil"
	"log"
	"os"
	"reflect"
	"strconv"
	"strings"
	"time"
)

//var Db *sqlx.DB
//func init() {
//	database,err:=sqlx.Open("mysql",
//		"root:"+beego.AppConfig.String("mysqlpass")+"@tcp("+beego.AppConfig.String("mysqlurls")+":3306)/vvlgo?charset=utf8&parseTime=true")
//	if err !=nil{
//		fmt.Println("open mysql failed:", err)
//	}
//	Db=database
//}

func StructToMap(obj interface{}) map[string]interface{} {
	t := reflect.TypeOf(obj)
	v := reflect.ValueOf(obj)

	var data = make(map[string]interface{})
	for i := 0; i < t.NumField(); i++ {
		data[t.Field(i).Name] = v.Field(i).Interface()
	}
	return data

}

// StringsJoin 字符串拼接
func StringsJoin(strs ...string) string {
	var str string
	var b bytes.Buffer
	strsLen := len(strs)
	if strsLen == 0 {
		return str
	}
	for i := 0; i < strsLen; i++ {
		b.WriteString(strs[i])
	}
	str = b.String()
	return str

}

// consoleLogs开发模式下日志
var consoleLogs *logs.BeeLogger

// fileLogs 生产环境下日志
var fileLogs *logs.BeeLogger
var runmode string

//LogOut 输出日志
// @Title LogOut
// @Param	body		body 	models.AccountAccountTag	true		"body for AccountAccountTag content"
func LogOut(level, v interface{}) {
	format := "%s"
	if level == "" {
		level = "debug"
	}
	if runmode == "dev" {
		switch level {
		case "emergency":
			fileLogs.Emergency(format, v)
		case "alert":
			fileLogs.Alert(format, v)
		case "critical":
			fileLogs.Critical(format, v)
		case "error":
			fileLogs.Error(format, v)
		case "warning":
			fileLogs.Warning(format, v)
		case "notice":
			fileLogs.Notice(format, v)
		case "informational":
			fileLogs.Informational(format, v)
		case "debug":
			fileLogs.Debug(format, v)
		case "warn":
			fileLogs.Warn(format, v)
		case "info":
			fileLogs.Info(format, v)
		case "trace":
			fileLogs.Trace(format, v)
		default:
			fileLogs.Debug(format, v)
		}
	}
	switch level {
	case "emergency":
		consoleLogs.Emergency(format, v)
	case "alert":
		consoleLogs.Alert(format, v)
	case "critical":
		consoleLogs.Critical(format, v)
	case "error":
		consoleLogs.Error(format, v)
	case "warning":
		consoleLogs.Warning(format, v)
	case "notice":
		consoleLogs.Notice(format, v)
	case "informational":
		fileLogs.Informational(format, v)
	case "debug":
		consoleLogs.Debug(format, v)
	case "warn":
		consoleLogs.Warn(format, v)
	case "info":
		consoleLogs.Info(format, v)
	case "trace":
		consoleLogs.Trace(format, v)
	default:
		consoleLogs.Debug(format, v)
	}

}

var file_dir = beego.AppConfig.String("fileUpPath") //文件存储位置
var CONTRACT string = "contract/"                   // 合同
var COUSTOMER string = "coustomer/"                 // 客户
var ORD_REIMBURSE string = "ordReimburse/"          // 普通报销文件
var TRA_REIMBURSE string = "traReimburse/"          // 差旅报销文件
var TEMP string = "TEMP/"                           // 缓存文件夹, 尽量定时清理
var NOTICE string = "notice/"                       // 通知文件
var PURCHASE = "purchase/"							// 采购文件

/*
 传递文件名称,带后缀会处理,进行uuid标识,返回对应的uuid文件路径和新的文件名称
@filename:  文件名称
@types: 文件类型 如合同,可以传递uitl.CONTRACT
@return: filepath 生成的uuid文件路径, filename 生成的uuid文件名
*/
func GetFilePath(filename string, types string) (string, string) {
	u := make([]byte, 16)
	_, err := rand.Read(u)
	if err != nil {
		logs.Info(err)
	}
	u[8] = (u[8] | 0x80) & 0xBF // what does this do?
	u[6] = (u[6] | 0x40) & 0x4F // what does this do?
	out := hex.EncodeToString(u)
	s := out[:8]                                           // 取前8位
	index := strings.LastIndex(filename, ".")              // 文件名切割
	suffix := filename[index:]                             // 获取后缀
	filename = filename[:index] + "_" + string(s) + suffix // 文件名重新拼接
	//b,_:=PathExists(file_dir+types)
	//if !b {
	//	err2 := os.MkdirAll(file_dir+types, os.ModePerm)
	//	if err2 != nil {
	//		err := fmt.Errorf("make die err:", err2)
	//		logs.Info("上传文件出错",err)
	//	}
	//}
	filepath := file_dir + types + filename // 组成文件路径
	return filepath, filename
}

func GetFilePathByUrl(fileUrl string, types string) string {
	index := strings.Index(fileUrl, types)
	fileStr := fileUrl[index:]
	filePath := file_dir + fileStr
	return filePath
}

/*
将缓存中的文件移动到对应类型的文件夹中
@filename: 对应TEMP文件夹中的文件名称
@types: 对应模块的文件名
@return: 返回bool 成功为true,失败为false
*/
func MoveFileFromTemp(filename string, types string) bool {
	//b,_:=PathExists(file_dir+types)
	//if !b {
	//	err2 := os.MkdirAll(file_dir+types, os.ModePerm)
	//	if err2 != nil {
	//		err := fmt.Errorf("make die err:", err2)
	//		logs.Info("上传文件出错",err)
	//	}
	//}

	oldpath := file_dir + TEMP + filename // 旧文件路径
	oldfile, _ := os.Open(oldpath)
	readAll, _ := ioutil.ReadAll(oldfile)
	newpath := file_dir + types + filename // 新文件路径
	err := ioutil.WriteFile(newpath, readAll, 666)
	if err != nil {
		logs.Info("move file err ,", err)
		return false
	}
	defer oldfile.Close()
	os.Remove(oldpath)
	return true
}

// 判断文件夹是否存在
func PathExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}

/*
复制map函数
*/
func CopyMap(oldMap map[string]interface{}) map[string]interface{} {
	newMap := make(map[string]interface{})

	// Copy from the original map to the target map
	for key, value := range oldMap {
		newMap[key] = value
	}
	return newMap
}

/*
将各种类型转换为字符串
*/
func TypeToString(value interface{}) string {
	return fmt.Sprintf("%v", value)
}

/*
解析查询条件
*/
func AnalyzeCondition(condition string) (string, string) {
	index := strings.Index(condition, "__")
	var key string
	var value string
	var symbol string
	if index == -1 {
		value = condition + " "
		symbol = "= "
		return value, symbol
	}
	value = condition[:index]
	key = condition[index+2:]
	switch key {
	case "lt":
		symbol = "< "
	case "le":
		symbol = "<= "
	case "eq":
		symbol = "= "
	case "ne":
		symbol = "<> "
	case "ge":
		symbol = ">= "
	case "gt":
		symbol = "> "
	}
	return value + " ", symbol
}

/*
计算时间，返回time，输入参数xxxx-xx-xx xx:xx:xx
*/
func CalculateTime(stime string, year, month, day int) time.Time {
	ntime, err := time.Parse("2006-01-02 15:04:05", strings.Replace(stime, "\\", "", -1))
	if err != nil {
		logs.Error("string to time err,", err)
	}
	caltime := ntime.AddDate(year, month, day)
	return caltime
}

/*
xxxx-xx-xx字符串转日期
*/
func StrToDay(stime string) time.Time {
	stime = strings.Replace(stime, "\\", "", -1)

	ntime, err := time.Parse("2006-01-02", stime[:10])
	if err != nil {
		logs.Error("string to day err,", err)
	}
	return ntime
}

/*
xxxx-xx字符串转日期
*/
func StrToMonth(stime string) time.Time {
	stime = strings.Replace(stime, "\\", "", -1)
	ntime, err := time.Parse("2006-01", stime[:7])
	if err != nil {
		logs.Error("string to month err,", err)
	}
	return ntime
}

/*
提取员工编号的数字,并生成新的编号
*/
func GetMnum(str *string, i int, flag bool) *string {
	runes := []rune(*str)
	var s string
	var s2 string
	var num int
	for k, v := range runes {
		if v > 48 && v <= 57 {
			s = string(runes[k:])
			num, _ = strconv.Atoi(s)
			if flag {
				num = num + 1
			}
			if num < 10 {
				s2 = string(runes[:k])
			}
			if num >= 10 {
				s2 = string(runes[:k-1])
			}
			break
		}
	}

	new := s2 + strconv.Itoa(num+i)
	return &new
}

/*
对计算后的浮点数处理，n保留几位小数
*/
func Decimal(value float64, n string) float64 {
	value, _ = strconv.ParseFloat(fmt.Sprintf("%."+n+"f", value), 64)
	return value
}

/*
发送邮件
*/
func SendEmail(to []string, title, context string) {
	m := gomail.NewMessage()
	email := beego.AppConfig.String("email")
	emailpwd := beego.AppConfig.String("emailpwd")
	m.SetAddressHeader("From", email, "ERP系统")
	m.SetHeader("To", to...)
	m.SetHeader("Subject", title)
	m.SetBody("text/html", context)
	d := gomail.NewDialer("smtp.exmail.qq.com", 465, email, emailpwd)

	if err := d.DialAndSend(m); err != nil {
		panic(err)
	}

	log.Println("done.发送成功")
}

/*
float64 to string
*/
func Float64ToString(f float64) string {
	return strconv.FormatFloat(f, 'f', -1, 64)
}

/*
float32 to string
*/
func Float32ToString(f float32) string {
	return strconv.FormatFloat(float64(f), 'f', -1, 32)
}

/*
计算两个时间之间相差的天数,n小数位数
*/
func TimeDValue(startTime, endTime time.Time, n string) float64 {

	return Decimal(float64(endTime.Unix()-startTime.Unix())/(60.00*60*24), n)
}

/*
md5加密
*/
func Md5PWD(pwd string) string {
	return fmt.Sprintf("%x", md5.Sum([]byte(pwd)))
}
