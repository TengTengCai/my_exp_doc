package test

import (
	"bytes"
	"fmt"
	"github.com/astaxie/beego/orm"
	_ "github.com/go-sql-driver/mysql"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestTime(t *testing.T) {
	s1 := "M1"
	s2 := "P1"
	s3 := "T1"
	s1s := []rune(s1)
	fmt.Println(string(s1s[0]) == "M")
	s2s := []rune(s2)
	fmt.Println(string(s2s[0]))
	s3s := []rune(s3)
	fmt.Println(string(s3s[0]))
	//str := "2017-09-05 12:00:00"
	//
	//str2 := "413049"
	//m := fmt.Sprintf("%x", md5.Sum([]byte(str2)))
	//fmt.Println(m)
	//
	//time1, _ := time.Parse("2006-01-02 15:04:05", str)
	//time2, _ := time.Parse("2006-01-02 15:04:05", str2)
	//
	//fmt.Println(Decimal(float64(time2.Unix()-time1.Unix())/(60.00*60*24), "1"))
	//fmt.Println(math.Round(5 / 12.00 * (12 - 6)))
	//
	//fmt.Println(int(time1.Month()))
	//
	//var times time.Time

	//fmt.Println(times)
	//s := "ERP需求流程_1aeaca4a.pdf"
	//ss := strings.Split(s, "_")
	//ss1 := strings.Split(s, ".")
	//fmt.Println(ss[0])
	//fmt.Println(ss1[1])
	//dbAlias := "default"
	//dbUser := "root"
	//dbPwd := "29571935"
	//dbName := "cpxerp"
	//dbUrl := "172.16.30.10"
	//dbPort := "3306"
	////重新运行时是否覆盖原表创建,false:不会删除原表,修改表信息时将会在原来的基础上修改，true删除原表重新创建
	//coverDb:= false
	//
	//orm.RegisterDriver("mysql", orm.DRMySQL)
	//
	//dataSource := StringsJoin(dbUser, ":", dbPwd, "@tcp(", dbUrl, ":", dbPort, ")", "/", dbName, "?charset=", "utf8&parseTime=true")
	//orm.RegisterDataBase(dbAlias, "mysql", dataSource)
	//orm.RegisterModel(new(User))
	////自动建表
	//orm.RunSyncdb(dbAlias, coverDb, true)
	//
	//user := SelectByIdCard("123123123")
	//fmt.Println(user)
}
func StrToMonth(stime string) time.Time {
	stime = strings.Replace(stime, "\\", "", -1)
	ntime, err := time.Parse("2006-01", stime[:7])
	if err != nil {
		fmt.Println("string to month err,", err)
	}
	return ntime
}

/*
提取员工编号的数字,并生成新的编号
*/
func GetMnum(str *string, i int) *string {
	runes := []rune(*str)
	var s string
	var s2 string
	var num int
	for k, v := range runes {
		if v > 48 && v <= 57 {
			s = string(runes[k:])
			num, _ = strconv.Atoi(s)
			num = num + 1
			if num < 10 {
				s2 = string(runes[:k])
			}
			if num >= 10 {
				s2 = string(runes[:k-1])
			}
			break
		}
	}

	new := s2 + strconv.Itoa(num+i)
	return &new
}

func StrToDay(stime string) time.Time {
	stime = strings.Replace(stime, "\\", "", -1)

	ntime, err := time.Parse("2006-01-02", stime[:10])
	if err != nil {
		fmt.Println("string to day err,", err)
	}
	return ntime
}

// StringsJoin 字符串拼接
func StringsJoin(strs ...string) string {
	var str string
	var b bytes.Buffer
	strsLen := len(strs)
	if strsLen == 0 {
		return str
	}
	for i := 0; i < strsLen; i++ {
		b.WriteString(strs[i])
	}
	str = b.String()
	return str

}

func Decimal(value float64, n string) float64 {
	value, _ = strconv.ParseFloat(fmt.Sprintf("%."+n+"f", value), 64)
	return value
}

type User struct {
	Id         int        `orm:"column(user_id);pk;auto;" form:"Id"`
	Name       string     `orm:"column(name);size(10)" form:"Name"`                                      //姓名
	CreateTime *time.Time `orm:"column(create_time);auto_now_add;type(datetime);null" form:"CreateTime"` //创建时间
}

func SelectAll() *[]User {
	users := []User{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from user").QueryRows(&users)
	if err != nil {
		fmt.Println("exec select faild", err)
		return nil
	}
	return &users
}

func Add(u User) bool {
	o := orm.NewOrm()
	_, err := o.Raw("INSERT into user (name,create_time) VALUES (?,?)", u.Name, u.CreateTime).Exec()
	if err != nil {
		fmt.Println("exec select faild", err)
		return false
	}
	return true
}
