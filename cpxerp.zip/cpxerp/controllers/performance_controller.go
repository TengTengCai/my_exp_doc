package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"encoding/json"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"github.com/tealeg/xlsx"
	"strconv"
	"time"
)

type PerformanceController struct {
	beego.Controller
}

/*
进入绩效录入界面
*/
func (p *PerformanceController) PerformanceAddHtml() {
	companyId := p.GetSession("companyId").(int) // 公司ID
	user := p.GetSession("CPXERP").(models.User)
	users := user.GetByComIdAndDSuperId(companyId, user.Id)

	temps := make([]interface{}, 0)
	for _, v := range *users {
		var TempUser struct {
			Id   int
			Name string
		}
		TempUser.Id = v.Id
		TempUser.Name = v.EmployeeNum + "(" + v.Name + ")"
		temps = append(temps, TempUser)
	}
	p.Data["users"] = temps
	p.TplName = "performance/performance_add.html"
}

/*
录入数据
*/
func (p *PerformanceController) PerformanceDoAdd() {

	performance := models.Performance{}
	err := p.ParseForm(&performance)
	if err != nil {
		logs.Error("customer formData err", err)
	}

	month := p.GetString("Month") + "-01"
	performance.Month = uitl.StrToMonth(p.GetString("Month"))

	per := performance.SelectByUserIdAndMonth(month)
	if per == nil {
		performance.Overall = uitl.Decimal(performance.CompletionRate*0.6+performance.ShowAttitude*0.4, "2")
		if performance.Overall >= 1.2 {
			performance.ExamineStatus = 0
			performance.ApplyStatus = 4
		} else {
			performance.ExamineStatus = 3
			performance.ApplyStatus = 0
		}
		b := performance.Add()
		if b {
			res := &uitl.RtMsg{0, "打分成功", 0, nil}
			p.Data["json"] = res
			p.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{1, "系统异常！", 0, nil}
			p.Data["json"] = res
			p.ServeJSON()
			return
		}
	} else {
		res := &uitl.RtMsg{1, "此员工已打分", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	}

}

/*
进入绩效查询界面
*/
func (p *PerformanceController) PerformanceHRListHtml() {
	p.TplName = "performance/performance_list.html"
}

/*
上级可查看绩效数据
*/
func (p *PerformanceController) PerformanceList() {
	companyId := p.GetSession("companyId").(int)
	user := p.GetSession("CPXERP").(models.User)
	page, err := p.GetInt("page")
	if err != nil {
		return
	}
	limit, err := p.GetInt("limit")
	if err != nil {
		return
	}
	datas := p.GetString("datas")
	performance := models.Performance{}
	if datas == "" {
		maps := make(map[string]interface{})
		maps["superior_id"] = strconv.Itoa(user.Id)
		now := time.Now()
		month := now.Format("2006-01")
		maps["month"] = month
		byPage := performance.SelectByMap(page, limit, companyId, maps)
		if byPage != nil {
			res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
			p.Data["json"] = res
			p.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "", 0, nil}
			p.Data["json"] = res
			p.ServeJSON()
			return
		}

	} else {
		maps := make(map[string]interface{})
		maps["superior_id"] = strconv.Itoa(user.Id)
		err := json.Unmarshal([]byte(datas), &maps)
		if err != nil {
			fmt.Println("json to map ", err)
		}
		byPage := performance.SelectByMap(page, limit, companyId, maps)
		if byPage != nil {
			res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
			p.Data["json"] = res
			p.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "", 0, nil}
			p.Data["json"] = res
			p.ServeJSON()
			return
		}
	}
}

/*
HR可查看绩效数据
*/
func (p *PerformanceController) PerformanceHRList() {
	companyId := p.GetSession("companyId").(int)
	page, err := p.GetInt("page")
	if err != nil {
		return
	}
	limit, err := p.GetInt("limit")
	if err != nil {
		return
	}
	datas := p.GetString("datas")
	performance := models.Performance{}
	if datas == "" {
		maps := make(map[string]interface{})
		maps["examine_status"] = "1,3"
		now := time.Now()
		month := now.Format("2006-01")
		maps["month"] = month
		byPage := performance.SelectByMap(page, limit, companyId, maps)
		if byPage != nil {
			res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
			p.Data["json"] = res
			p.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "", 0, nil}
			p.Data["json"] = res
			p.ServeJSON()
			return
		}

	} else {
		maps := make(map[string]interface{})
		maps["examine_status"] = "1,3"
		err := json.Unmarshal([]byte(datas), &maps)
		if err != nil {
			fmt.Println("json to map ", err)
		}
		byPage := performance.SelectByMap(page, limit, companyId, maps)
		if byPage != nil {
			res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
			p.Data["json"] = res
			p.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "", 0, nil}
			p.Data["json"] = res
			p.ServeJSON()
			return
		}
	}
}

/*
大于1.2的绩效审核界面
*/
func (p *PerformanceController) PerformanceExamineHtml() {
	p.TplName = "performance/performance_examine.html"
}

/*
大于1.2的绩效审核数据
*/
func (p *PerformanceController) PerformanceExamineList() {
	companyId := p.GetSession("companyId").(int)
	page, err := p.GetInt("page")
	if err != nil {
		return
	}
	limit, err := p.GetInt("limit")
	if err != nil {
		return
	}
	datas := p.GetString("datas")
	performance := models.Performance{}
	if datas == "" {
		maps := make(map[string]interface{})
		maps["examine_status"] = "0"
		now := time.Now()
		month := now.Format("2006-01")
		maps["month"] = month
		byPage := performance.SelectByMap(page, limit, companyId, maps)
		if byPage != nil {
			res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
			p.Data["json"] = res
			p.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "", 0, nil}
			p.Data["json"] = res
			p.ServeJSON()
			return
		}

	} else {
		maps := make(map[string]interface{})
		maps["examine_status"] = "0"
		err := json.Unmarshal([]byte(datas), &maps)
		if err != nil {
			fmt.Println("json to map ", err)
		}
		byPage := performance.SelectByMap(page, limit, companyId, maps)
		if byPage != nil {
			res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
			p.Data["json"] = res
			p.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "", 0, nil}
			p.Data["json"] = res
			p.ServeJSON()
			return
		}
	}
}

/*
大于1.2的绩效审核操作
*/
func (p *PerformanceController) PerformanceDoExamine() {
	id, _ := p.GetInt("Id")
	authitStatus, _ := p.GetInt("AuditStatus")

	performance := models.Performance{}
	performance.Id = id
	performance.ExamineStatus = authitStatus

	if authitStatus == 2 {
		remark := p.GetString("Remarks")
		if remark != "" {
			performance.Remark = remark
		}
		performance.ApplyStatus = 2
	} else {
		performance.ApplyStatus = 4
	}

	b := performance.UpdateExamineStatus()
	if b {
		res := &uitl.RtMsg{0, "已审核", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	}
}

/*
未通过的修改页面
*/
func (p *PerformanceController) PerformanceUpdateHtml() {
	companyId := p.GetSession("companyId").(int)
	id, err := strconv.Atoi(p.Ctx.Input.Param(":id"))
	if err != nil {
		fmt.Println(err)
	}
	performance := models.Performance{}
	performance.Id = id
	performance.SelectById(companyId)
	p.Data["per"] = performance
	p.Data["month"] = performance.Month.Format("2006-01")
	p.TplName = "performance/performance_update.html"
}

/*
修改操作
*/
func (p *PerformanceController) PerformanceDoUpdate() {
	performance := models.Performance{}
	err := p.ParseForm(&performance)
	if err != nil {
		fmt.Println("customer formData err", err)
	}
	performance.Overall = uitl.Decimal(performance.CompletionRate*0.6+performance.ShowAttitude*0.4, "2")
	if performance.Overall >= 1.2 {
		performance.ExamineStatus = 0
		performance.ApplyStatus = 4
	} else {
		performance.ExamineStatus = 3
		performance.ApplyStatus = 0
	}
	performance.Remark = ""
	performance.Month = uitl.StrToMonth(p.GetString("Month"))

	b := performance.UpdateDetail()
	if b {
		res := &uitl.RtMsg{0, "修改成功", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	}
}

/*
申请修改操作
*/
func (p *PerformanceController) PerformanceApplyUpdate() {
	performance := models.Performance{}
	err := p.ParseForm(&performance)
	if err != nil {
		logs.Error("performance formData err", err)
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	}

	b := performance.UpdateApplyStatus()
	if b {
		res := &uitl.RtMsg{0, "已申请", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	}
}

/*
审核修改操作
*/
func (p *PerformanceController) PerformanceExamineApply() {
	id, _ := p.GetInt("Id")
	authitStatus, _ := p.GetInt("AuditStatus")

	performance := models.Performance{}
	performance.Id = id

	if authitStatus == 3 {
		remark := p.GetString("Remarks")
		if remark != "" {
			performance.Remark = remark
		}
		performance.ApplyStatus = 3
	} else {
		performance.ApplyStatus = 2
	}

	b := performance.UpdateApplyStatus()
	if b {
		res := &uitl.RtMsg{0, "已审核", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	}
}

/*
导出数据到excel表格中
*/
func (p *PerformanceController) ExportExcel() {
	companyId := p.GetSession("companyId").(int) // 公司ID
	month := p.Ctx.Input.Param("month")
	xlFile := xlsx.NewFile()
	titleList := []string{"员工编号", "姓名", "月工作完成率", "月工作表现", "绩效综合得分", "月工作表现说明"}
	performance := models.Performance{}
	maps := make(map[string]interface{})
	var m string
	if month == "" {
		maps["examine_status"] = "1,3"
		now := time.Now()
		monthnow := now.Format("2006-01")
		maps["month"] = monthnow
		m = monthnow
	} else {
		maps["examine_status"] = "1,3"
		maps["month"] = month
		m = month
	}
	byPage := performance.SelectByMap(1, 1000000, companyId, maps)
	performances := byPage.Data.(*[]models.Performance)
	xlFile.AddSheet("员工绩效评分")
	for _, sheet := range xlFile.Sheets {

		for r := 0; r < len(*performances)+2; r++ {
			fmt.Println(r)
			if r == 0 {
				sheet.AddRow().AddCell().SetValue("员工绩效评分-" + m)
			}
			if r == 1 {
				raw := sheet.AddRow()
				for _, v := range titleList {
					raw.AddCell().SetValue(v)
				}
			}
			if r > 1 {
				var raw *xlsx.Row
				raw = sheet.AddRow()
				per := (*performances)[r-2]
				raw.AddCell().SetValue(per.EmployeeNum)
				raw.AddCell().SetValue(per.Name)

				raw.AddCell().SetValue(per.CompletionRate)
				raw.AddCell().SetValue(per.ShowAttitude)
				raw.AddCell().SetValue(per.Overall)
				raw.AddCell().SetValue(per.ShowExplain)
			}
			if len(*performances) == r-1 {
				break
			}
		}
	}
	filePath := "/ERPFile/TEMP/员工绩效评分.xlsx"
	err := xlFile.Save(filePath)
	if err != nil {
		logs.Error(err)
	}
	p.Ctx.Output.Download(filePath, "员工绩效评分.xlsx")
}
