package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"github.com/tealeg/xlsx"
	"strconv"
	"time"
)

type LeaveController struct {
	beego.Controller
}

/*
请假申请页面
*/
func (c *LeaveController) LeaveAddHtml() {
	user := c.GetSession("CPXERP").(models.User)
	dep := models.Department{}
	department := dep.GetDepartmentById(user.DepartmentId)
	anlev := models.AnnualLeave{}
	anlev.UserId = user.Id
	annualLeave := anlev.SelectByUserId()
	if annualLeave != nil {
		if annualLeave.AnnualLeaveDays == 0 {
			c.Data["days"] = 0
			c.Data["annualLeave"] = true
		} else {
			c.Data["days"] = annualLeave.AnnualLeaveDays
			c.Data["annualLeave"] = false
		}
	} else {
		c.Data["days"] = 0
		c.Data["annualLeave"] = true

	}
	c.Data["deparment"] = department
	c.TplName = "leave/leave_add.html"
}

/*
请假申请提交操作
*/
func (c *LeaveController) LeaveDoAdd() {
	user := c.GetSession("CPXERP").(models.User)
	leave := models.AskLeave{}
	err := c.ParseForm(&leave)
	if err != nil {
		logs.Error("customer formData err", err)
	}
	superUser := user.GetByUserId(user.Superior)
	ro := models.Role{}
	_, role := ro.GetRoleById(superUser.RoleId)

	leave.UserId = user.Id
	leave.UserName = user.Name
	leave.EmployeeNum = user.EmployeeNum
	leave.DepartmentId = user.DepartmentId
	dep := models.Department{}
	depart := dep.GetDepartmentById(user.DepartmentId)
	leave.DepartmentName = depart.DepartmentName
	leave.LeaveStartTime = uitl.StrToDay(c.GetString("LeaveStartTime"))
	leave.LeaveEndTime = uitl.StrToDay(c.GetString("LeaveEndTime"))
	leave.CreateTime = time.Now()
	leave.CompanyId = user.CompanyId
	leave.SuperiorId = user.Superior
	leave.HRExamineStatus = 3
	if role.RoleName == "CEO" || role.RoleName == "COO" {
		leave.SuperiorExamineStatus = 1
		leave.CeoExamineStatus = 0
	} else {
		leave.SuperiorExamineStatus = 0
		if leave.LeaveDays > 3 {
			leave.CeoExamineStatus = 0
		} else {
			leave.CeoExamineStatus = 3
		}

	}
	b := leave.Add()
	if b {
		res := &uitl.RtMsg{0, "申请成功！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
查询个人的请假记录
*/

func (c *LeaveController) SelectSelfList() {
	user := c.GetSession("CPXERP").(models.User)
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	as := models.AskLeave{}
	as.UserId = user.Id
	newPage := as.SelectByUserId(page, limit)
	if newPage != nil {
		res := &uitl.RtMsg{0, "", newPage.TotalCount, newPage.Data}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
审核页面
*/
func (c *LeaveController) ExamineHtml() {
	c.TplName = "leave/leave_examine.html"

}

/*
审核数据，根据权限获得待审核的数据
*/
func (c *LeaveController) ExamineList() {
	companyId := c.GetSession("companyId").(int)
	user := c.GetSession("CPXERP").(models.User)
	role := models.Role{}
	err, modules := role.GetModuleMaps(user.RoleId)
	if err != nil {
		logs.Error("leave select module err,", err)
		res := &uitl.RtMsg{1, "系统异常", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	leave := models.AskLeave{}
	leave.CompanyId = companyId
	if (modules["superior_examine"] == true) || (modules["persionnel2_examine"] == true) || (modules["finance_examine"] == true) {
		leave.SuperiorId = user.Id
		newPages := leave.SelectBySuperiorId(page, limit)
		if newPages != nil {
			res := &uitl.RtMsg{0, "", newPages.TotalCount, newPages.Data}
			c.Data["json"] = res
			c.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
	} else if (modules["ceo_examine"] == true) || (modules["coo_examine"] == true) {
		newPages := leave.SelectByCeoStatus(page, limit)
		if newPages != nil {
			res := &uitl.RtMsg{0, "", newPages.TotalCount, newPages.Data}
			c.Data["json"] = res
			c.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
	} else {
		res := &uitl.RtMsg{1, "权限不足", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
审核操作
*/
func (c *LeaveController) DoExamine() {
	id, _ := c.GetInt("Id")
	authitStatus, _ := c.GetInt("AuditStatus")
	user := c.GetSession("CPXERP").(models.User)
	role := models.Role{}
	err, modules := role.GetModuleMaps(user.RoleId)
	if err != nil {
		logs.Error("leave select module err,", err)
		res := &uitl.RtMsg{1, "系统异常", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

	leave := models.AskLeave{}
	leave.LeaveId = id
	leave.SelectById()

	annul := models.AnnualLeave{}
	annul.UserId = leave.UserId
	annualLeave := annul.SelectByUserId()
	var b bool
	if (modules["superior_examine"] == true) || (modules["persionnel2_examine"] == true) || (modules["finance_examine"] == true) {
		if authitStatus == 2 {
			remark := c.GetString("Remarks")
			if remark != "" {
				leave.Remark = remark
			}
			leave.SuperiorExamineStatus = 2
		} else {
			leave.SuperiorExamineStatus = 1
			//审核通过如果是年假，修改个人年假数据
			if leave.LeaveDays > 3 {
				leave.CeoExamineStatus = 0
			} else {
				if leave.LeaveType == "年假" {
					annualLeave := makePersonAnnualLeave(*annualLeave, leave.LeaveDays, 0, 0, int(leave.CreateTime.Month()))
					b := annualLeave.UpdateByUserId()
					if b {
						logs.Info("annulLeave update ok!")
					} else {
						logs.Error("annulLeave update ok!")
					}
				}
			}
		}
		b = leave.SupUpdateExamineStatus()
	}
	if (modules["ceo_examine"] == true) || (modules["coo_examine"] == true) {
		if authitStatus == 2 {
			remark := c.GetString("Remarks")
			if remark != "" {
				leave.Remark = remark
			}
			leave.CeoExamineStatus = 2
		} else {
			leave.CeoExamineStatus = 1
			//审核通过如果是年假，修改个人年假数据
			if leave.LeaveType == "年假" {
				annualLeave := makePersonAnnualLeave(*annualLeave, leave.LeaveDays, 0, 0, int(leave.CreateTime.Month()))
				b := annualLeave.UpdateByUserId()
				if b {
					logs.Info("annulLeave update ok!")
				} else {
					logs.Error("annulLeave update ok!")
				}
			}

		}
		b = leave.CeoUpdateExamineStatus()
	}

	if b {
		res := &uitl.RtMsg{0, "已审核", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
删除某条记录
*/
func (c *LeaveController) DoDel() {
	id, _ := c.GetInt("Id")
	leave := models.AskLeave{}
	leave.LeaveId = id
	b := leave.DeleteById()
	if b {
		res := &uitl.RtMsg{0, "已删除", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
请假备份页面
*/
func (c *LeaveController) ListHtml() {
	c.TplName = "leave/leave_list.html"
}

/*
请假备份页面
*/
func (c *LeaveController) List() {
	companyId := c.GetSession("companyId").(int)
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	leave := models.AskLeave{}
	leave.CompanyId = companyId
	byPage := leave.SelectAllByPage(page, limit)
	if byPage != nil {
		res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
导出请假记录
*/
func (c *LeaveController) ExportExcel() {
	companyId := c.GetSession("companyId").(int) // 公司ID
	xlFile := xlsx.NewFile()
	titleList := []string{"员工编号", "姓名", "部门", "假别", "时间", "起始时间", "结束", "请假缘由"}
	leave := models.AskLeave{}
	leave.CompanyId = companyId
	byPage := leave.SelectAllByPage(1, 1000000)
	levs := byPage.Data.(*[]models.AskLeave)
	xlFile.AddSheet("员工请假记录")
	for _, sheet := range xlFile.Sheets {

		for r := 0; r < len(*levs)+2; r++ {
			fmt.Println(r)
			if r == 0 {
				sheet.AddRow().AddCell().SetValue("员工请假记录")
			}
			if r == 1 {
				raw := sheet.AddRow()
				for _, v := range titleList {
					raw.AddCell().SetValue(v)
				}
			}
			if r > 1 {
				var raw *xlsx.Row
				raw = sheet.AddRow()
				per := (*levs)[r-2]
				raw.AddCell().SetValue(per.EmployeeNum)
				raw.AddCell().SetValue(per.UserName)

				raw.AddCell().SetValue(per.DepartmentName)
				raw.AddCell().SetValue(per.LeaveType)
				raw.AddCell().SetValue(per.LeaveDays)
				raw.AddCell().SetValue(per.LeaveStartTime.Format("2006-01-02") + "(" + per.StartType + ")")
				raw.AddCell().SetValue(per.LeaveEndTime.Format("2006-01-02") + "(" + per.EndType + ")")
				raw.AddCell().SetValue(per.LeaveReason)
			}
			if len(*levs) == r-1 {
				break
			}
		}
	}
	filePath := "/ERPFile/TEMP/员工请假记录.xlsx"
	err := xlFile.Save(filePath)
	if err != nil {
		logs.Error(err)
	}
	c.Ctx.Output.Download(filePath, "员工请假记录.xlsx")
}

/*
销假界面
*/
func (c *LeaveController) LeaveOffHtml() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		logs.Error(err)
	}
	leave := models.AskLeave{}
	leave.LeaveId = id
	leave.SelectById()
	c.Data["lea"] = leave
	c.TplName = "leave/leave_off.html"
}

/*
增加销假数据，人事状态进入待审核
*/
func (c *LeaveController) LeaveDoOff() {
	leave := models.AskLeave{}
	err := c.ParseForm(&leave)
	if err != nil {
		logs.Error("customer formData err", err)
	}
	leave.LeaveOffTime = uitl.StrToDay(c.GetString("LeaveOffTime"))
	leave.HRExamineStatus = 11
	b := leave.UpdateOff()
	if b {
		res := &uitl.RtMsg{0, "申请提交成功", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
进入销假审核页面
*/
func (c *LeaveController) LeaveOffExamineHtml() {
	c.TplName = "leave/leave_off_examine.html"
}

/*
查询hr待审的销假数据
*/
func (c *LeaveController) LeaveHROffExamineList() {
	companyId := c.GetSession("companyId").(int) // 公司ID
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	leave := models.AskLeave{}
	leave.CompanyId = companyId
	offByPage := leave.SelectAllOffByPage(page, limit)
	if offByPage != nil {
		res := &uitl.RtMsg{0, "", offByPage.TotalCount, offByPage.Data}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
销假审核操作
*/
func (c *LeaveController) LeaveDoOffExamine() {
	id, _ := c.GetInt("Id")
	authitStatus, _ := c.GetInt("AuditStatus")
	leave := models.AskLeave{}
	leave.LeaveId = id
	leave.SelectById()
	leave2 := models.AskLeave{}

	if authitStatus == 2 {
		remark := c.GetString("Remarks")
		if remark != "" {
			leave.Remark = remark
		}
		leave.HRExamineStatus = 2
	} else {
		leave.LeaveEndTime = leave.LeaveOffTime
		leave.LeaveDays = uitl.Decimal(leave.LeaveDays-leave.OffDays, "1")
		leave.HRExamineStatus = 1
		//审核通过如果是年假，修改个人年假数据
		annul := models.AnnualLeave{}
		annul.UserId = leave.UserId
		annualLeave := annul.SelectByUserId()
		annualLeave = makePersonAnnualLeave(*annualLeave, 0, leave.OffDays, 0, int(leave.CreateTime.Month()))
		b := annualLeave.UpdateByUserId()
		if b {
			logs.Info("annulLeave update ok!")
		} else {
			logs.Error("annulLeave update ok!")
		}
	}
	leave.LeaveOffTime = leave2.LeaveOffTime
	leave.OffDays = 0
	leave.OffType = ""
	b := leave.UpdateLeaveByOff()

	if b {
		res := &uitl.RtMsg{0, "已审核", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*---------------------------------------------------*/

/*
补假界面
*/
func (c *LeaveController) LeaveDelayHtml() {
	user := c.GetSession("CPXERP").(models.User)
	anlev := models.AnnualLeave{}
	anlev.UserId = user.Id
	annualLeave := anlev.SelectByUserId()
	if annualLeave != nil {
		if annualLeave.AnnualLeaveDays == 0 {
			c.Data["days"] = 0

		} else {
			c.Data["days"] = annualLeave.AnnualLeaveDays
		}
	} else {
		c.Data["days"] = 0

	}
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		fmt.Println(err)
	}
	leave := models.AskLeave{}
	leave.LeaveId = id
	leave.SelectById()
	c.Data["lea"] = leave
	c.TplName = "leave/leave_delay.html"
}

/*
增加补假数据，人事状态进入待审核
*/
func (c *LeaveController) LeaveDoDelay() {
	leave := models.AskLeave{}
	err := c.ParseForm(&leave)
	if err != nil {
		logs.Error("customer formData err", err)
	}
	leave.LeaveDelayTime = uitl.StrToDay(c.GetString("LeaveDelayTime"))
	leave.HRExamineStatus = 12
	b := leave.UpdateDelay()
	if b {
		res := &uitl.RtMsg{0, "申请提交成功", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
进入补假审核页面
*/
func (c *LeaveController) LeaveDelayExamineHtml() {
	c.TplName = "leave/leave_delay_examine.html"
}

/*
查询hr待审的补假数据
*/
func (c *LeaveController) LeaveHRDelayExamineList() {
	companyId := c.GetSession("companyId").(int) // 公司ID
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	leave := models.AskLeave{}
	leave.CompanyId = companyId
	offByPage := leave.SelectAllDelayByPage(page, limit)
	if offByPage != nil {
		res := &uitl.RtMsg{0, "", offByPage.TotalCount, offByPage.Data}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
补假审核操作
*/
func (c *LeaveController) LeaveDoDelayExamine() {
	id, _ := c.GetInt("Id")
	authitStatus, _ := c.GetInt("AuditStatus")

	leave := models.AskLeave{}
	leave.LeaveId = id
	leave.SelectById()
	leave2 := models.AskLeave{}

	if authitStatus == 2 {
		remark := c.GetString("Remarks")
		if remark != "" {
			leave.Remark = remark
		}
		leave.HRExamineStatus = 2
	} else {
		leave.LeaveEndTime = leave.LeaveDelayTime
		leave.LeaveDays = uitl.Decimal(leave.LeaveDays+leave.DelayDays, "1")
		leave.HRExamineStatus = 1
		//审核通过如果是年假，修改个人年假数据
		annul := models.AnnualLeave{}
		annul.UserId = leave.UserId
		annualLeave := annul.SelectByUserId()
		annualLeave = makePersonAnnualLeave(*annualLeave, 0, 0, leave.DelayDays, int(leave.CreateTime.Month()))
		b := annualLeave.UpdateByUserId()
		if b {
			logs.Info("annulLeave update ok!")
		} else {
			logs.Error("annulLeave update ok!")
		}
	}
	leave.LeaveDelayTime = leave2.LeaveDelayTime
	leave.DelayDays = 0
	leave.DelayType = ""
	b := leave.UpdateLeaveByDelay()

	if b {
		res := &uitl.RtMsg{0, "已审核", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
假期审核后，计算个人年假剩余天数及每个月年假使用天数，返回已被修改后的年假对象
annulLeave 年假对象
days	请假天数
offdays	销假天数
delayDays 补假天数
month 月份
*/
func makePersonAnnualLeave(annulLeave models.AnnualLeave, days, offdays, delayDays float64, month int) *models.AnnualLeave {
	if days != 0 && offdays == 0 && delayDays == 0 {
		annulLeave.AnnualLeaveDays = uitl.Decimal(annulLeave.AnnualLeaveDays-days, "1")
		annulLeave.UsedAnnualLeaveDays = uitl.Decimal(annulLeave.UsedAnnualLeaveDays+days, "1")
		switch month {
		case 1:
			annulLeave.January = uitl.Decimal(annulLeave.January+days, "1")
		case 2:
			annulLeave.February = uitl.Decimal(annulLeave.February+days, "1")
		case 3:
			annulLeave.March = uitl.Decimal(annulLeave.March+days, "1")
		case 4:
			annulLeave.April = uitl.Decimal(annulLeave.April+days, "1")
		case 5:
			annulLeave.May = uitl.Decimal(annulLeave.May+days, "1")
		case 6:
			annulLeave.June = uitl.Decimal(annulLeave.June+days, "1")
		case 7:
			annulLeave.July = uitl.Decimal(annulLeave.July+days, "1")
		case 8:
			annulLeave.August = uitl.Decimal(annulLeave.August+days, "1")
		case 9:
			annulLeave.September = uitl.Decimal(annulLeave.September+days, "1")
		case 10:
			annulLeave.October = uitl.Decimal(annulLeave.October+days, "1")
		case 11:
			annulLeave.November = uitl.Decimal(annulLeave.November+days, "1")
		case 12:
			annulLeave.December = uitl.Decimal(annulLeave.December+days, "1")
		}
	}
	if days == 0 && offdays != 0 && delayDays == 0 {
		annulLeave.AnnualLeaveDays = uitl.Decimal(annulLeave.AnnualLeaveDays+offdays, "1")
		annulLeave.UsedAnnualLeaveDays = uitl.Decimal(annulLeave.UsedAnnualLeaveDays-offdays, "1")
		switch month {
		case 1:
			annulLeave.January = uitl.Decimal(annulLeave.January-offdays, "1")
		case 2:
			annulLeave.February = uitl.Decimal(annulLeave.February-offdays, "1")
		case 3:
			annulLeave.March = uitl.Decimal(annulLeave.March-offdays, "1")
		case 4:
			annulLeave.April = uitl.Decimal(annulLeave.April-offdays, "1")
		case 5:
			annulLeave.May = uitl.Decimal(annulLeave.May-offdays, "1")
		case 6:
			annulLeave.June = uitl.Decimal(annulLeave.June-offdays, "1")
		case 7:
			annulLeave.July = uitl.Decimal(annulLeave.July-offdays, "1")
		case 8:
			annulLeave.August = uitl.Decimal(annulLeave.August-offdays, "1")
		case 9:
			annulLeave.September = uitl.Decimal(annulLeave.September-offdays, "1")
		case 10:
			annulLeave.October = uitl.Decimal(annulLeave.October-offdays, "1")
		case 11:
			annulLeave.November = uitl.Decimal(annulLeave.November-offdays, "1")
		case 12:
			annulLeave.December = uitl.Decimal(annulLeave.December-offdays, "1")
		}
	}
	if days == 0 && offdays == 0 && delayDays != 0 {
		annulLeave.AnnualLeaveDays = uitl.Decimal(annulLeave.AnnualLeaveDays-delayDays, "1")
		annulLeave.UsedAnnualLeaveDays = uitl.Decimal(annulLeave.UsedAnnualLeaveDays+delayDays, "1")
		switch month {
		case 1:
			annulLeave.January = uitl.Decimal(annulLeave.January+delayDays, "1")
		case 2:
			annulLeave.February = uitl.Decimal(annulLeave.February+delayDays, "1")
		case 3:
			annulLeave.March = uitl.Decimal(annulLeave.March+delayDays, "1")
		case 4:
			annulLeave.April = uitl.Decimal(annulLeave.April+delayDays, "1")
		case 5:
			annulLeave.May = uitl.Decimal(annulLeave.May+delayDays, "1")
		case 6:
			annulLeave.June = uitl.Decimal(annulLeave.June+delayDays, "1")
		case 7:
			annulLeave.July = uitl.Decimal(annulLeave.July+delayDays, "1")
		case 8:
			annulLeave.August = uitl.Decimal(annulLeave.August+delayDays, "1")
		case 9:
			annulLeave.September = uitl.Decimal(annulLeave.September+delayDays, "1")
		case 10:
			annulLeave.October = uitl.Decimal(annulLeave.October+delayDays, "1")
		case 11:
			annulLeave.November = uitl.Decimal(annulLeave.November+delayDays, "1")
		case 12:
			annulLeave.December = uitl.Decimal(annulLeave.December+delayDays, "1")
		}

	}
	return &annulLeave
}
