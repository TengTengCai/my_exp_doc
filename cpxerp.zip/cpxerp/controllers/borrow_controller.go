package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"time"
)

type BorrowController struct {
	beego.Controller
}

/*
进入借款申请页面
*/
func (b *BorrowController) BorrowAddHtml() {
	b.Data["departments"] = models.SelectAllDepartment()
	b.TplName = "borrow/borrow_add.html"
}

/*
进入借款审核页面
*/
func (b *BorrowController) BorrowListHtml() {
	b.TplName = "borrow/borrow_list.html"
}

/*
进入查询页面
*/
func (b *BorrowController) BorrowSelectHtml() {
	b.TplName = "borrow/borrow_select.html"
}

/*
进入待放款页面
*/
func (b *BorrowController) BorrowPayHtml() {
	b.TplName = "borrow/borrow_pay.html"
}

/*
添加借款数据
*/
func (b *BorrowController) BorrowDoAdd() {
	user := b.GetSession("CPXERP").(models.User)
	companyId := b.GetSession("companyId").(int)
	comp := models.Company{}
	company := comp.SelectById(companyId)

	borrow := models.Borrow{}
	err := b.ParseForm(&borrow)
	if err != nil {
		logs.Error("customer formData err", err)
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		b.Data["json"] = res
		b.ServeJSON()
		return
	}
	applicationTime := b.GetString("ApplicationTime") + " 00:00:00"
	atime, err := time.Parse("2006-01-02 15:04:05", applicationTime)
	if err != nil {
		logs.Error("string to time err,", err)
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		b.Data["json"] = res
		b.ServeJSON()
		return
	}
	borrow.ApplicationTime = atime
	borrow.CreateTime = time.Now()
	borrow.CompanyId = company.Id
	borrow.CreateUserId = user.Id
	borrow.DivisionLeaderStatus = 0
	borrow.FinancialCheckStatus = 0
	borrow.CompanyHeaderStatus = 0
	borrow.PaymentStatus = 0
	flag, err := borrow.Add()
	if err != nil {
		fmt.Println("add borrow err ,", err)
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		b.Data["json"] = res
		b.ServeJSON()
		return
	}
	if flag {
		res := &uitl.RtMsg{0, "添加成功！！", 0, nil}
		b.Data["json"] = res
		b.ServeJSON()
		return
	}
}

/*
查询审核数据，根据部门，财务，公司领导展示不同数据
*/
func (b *BorrowController) BorrowList() {
	user := b.GetSession("CPXERP").(models.User)
	companyId := b.GetSession("companyId").(int)
	role := models.Role{}
	_, modules := role.GetModuleMaps(user.RoleId)
	page, err := b.GetInt("page")
	if err != nil {
		return
	}
	limit, err := b.GetInt("limit")
	if err != nil {
		return
	}
	borrow := models.Borrow{}
	list := borrow.SelectDataList(page, limit, modules, user, companyId)
	if list == nil {
		res := &uitl.RtMsg{0, "", 0, nil}
		b.Data["json"] = res
		b.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "", list.TotalCount, list.Data}
	b.Data["json"] = res
	b.ServeJSON()
	return
}

/*
审核借款信息，部门-财务-公司领导
*/
func (b *BorrowController) BorrowDoExamine() {
	user := b.GetSession("CPXERP").(models.User)
	borrowId, _ := b.GetInt("Id")
	authitStatus, _ := b.GetInt("AuditStatus")
	role := models.Role{}
	_, modules := role.GetModuleMaps(user.RoleId)
	if modules["deppart_examine"] == true || modules["finance_examine"] == true || modules["ceo_examine"] == true {
		borrow := models.Borrow{}
		flag := borrow.UpdateStatus(modules, authitStatus, borrowId)
		if flag {
			res := &uitl.RtMsg{0, "已审核", 0, nil}
			b.Data["json"] = res
			b.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{-1, "系统异常！！", 0, nil}
			b.Data["json"] = res
			b.ServeJSON()
			return
		}
	} else {
		res := &uitl.RtMsg{-1, "权限不足！！", 0, nil}
		b.Data["json"] = res
		b.ServeJSON()
		return

	}
}

/*
查询当前账号的借款申请记录及申请状态
*/
func (b *BorrowController) BorrowSelectData() {
	user := b.GetSession("CPXERP").(models.User)
	page, err := b.GetInt("page")
	if err != nil {
		return
	}
	limit, err := b.GetInt("limit")
	if err != nil {
		return
	}
	borrow := models.Borrow{}
	newPage := borrow.SelectBuCreateUser(page, limit, user)
	res := &uitl.RtMsg{0, "", newPage.TotalCount, newPage.Data}
	b.Data["json"] = res
	b.ServeJSON()
	return
}

/*
查询待放款的数据
*/
func (b *BorrowController) BorrowPayData() {
	companyId := b.GetSession("companyId").(int)
	page, err := b.GetInt("page")
	if err != nil {
		return
	}
	limit, err := b.GetInt("limit")
	if err != nil {
		return
	}
	borrow := models.Borrow{}
	newPage := borrow.SelectByStatus(page, limit, companyId)
	res := &uitl.RtMsg{0, "", newPage.TotalCount, newPage.Data}
	b.Data["json"] = res
	b.ServeJSON()
	return
}

/*
操作放款，修改放款状态
*/
func (b *BorrowController) BorrowDoPay() {
	borrowId, _ := b.GetInt("Id")
	borrow := models.Borrow{}
	flag := borrow.UpdatePayStatus(borrowId)
	if flag {
		res := &uitl.RtMsg{0, "已放款", 0, nil}
		b.Data["json"] = res
		b.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{-1, "系统异常！！", 0, nil}
		b.Data["json"] = res
		b.ServeJSON()
		return
	}
}
