package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"net/http"
	url1 "net/url"
	"os"
	"strings"
)

type MainController struct {
	beego.Controller
}

func (c *MainController) Index() {
	user := c.GetSession("CPXERP").(models.User)
	c.Data["user"] = "/static/login/img/timg.jpg"
	c.Data["name"] = user.Name
	c.Data["pwdstatus"] = user.PwdStatus
	role := models.Role{}
	module := models.Module{}
	err, modelMap := module.GetModuleAll()

	if err != nil {
		logs.Error(err)
	}
	if user.RoleId == 5 {
		for k, _ := range modelMap {
			modelMap[k] = true
		}
	} else {
		err, modules := role.GetModuleList(user.RoleId)
		if err != nil {
			logs.Error("main_controller", err)
		}
		for _, v := range modules {
			modelMap[v.ModuleKey] = true
		}

	}
	c.Data["modules"] = modelMap

	company := models.Company{}
	companies := company.GetAll()
	companyId := c.GetSession("companyId")
	for i := 0; i < len(companies); i++ {
		if companyId == companies[i].Id {
			companies[i].Flag = true
		} else {
			companies[i].Flag = false
		}
	}
	fmt.Println(companies)
	c.Data["companies"] = companies

	c.TplName = "index.html"
}

func (c *MainController) Main() {
	c.TplName = "main.html"
}

func (c *MainController) Login() {
	c.TplName = "login.html"
}

func (c *MainController) DoLogin() {

	accountName := c.GetString("accountName")
	accountPwd := c.GetString("accountPwd")
	err, user := models.User{}.GetOneByName(accountName)

	if err == nil && accountName == user.Email && uitl.Md5PWD(accountPwd) == user.Password && user.Incumbency != "离职" {
		c.SetSession("CPXERP", user)
		c.SetSession("companyId", user.CompanyId)
		logs.Info(user, " 登录！")
		res := &uitl.RtMsg{1, "ok！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		logs.Error(user, "登录失败")
		//c.Ctx.ResponseWriter.Write([]byte("{\"success\":true,\"msg\":\"密码错误！\"}"))
		res := &uitl.RtMsg{0, "账号密码错误！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}
func (c *MainController) Logout() {
	c.DelSession("CPXERP")
	c.TplName = "login.html"
}

////文件上传
//func (c *MainController) FileUpLoad() {
//	file, h, err := c.GetFile("file")
//	if err != nil {
//		fmt.Println("uplaod file error,", err)
//	}
//	fileHttp := "http://" + beego.AppConfig.String("addr") + ":" + beego.AppConfig.String("httpport") + "/images/" + h.Filename
//	filePath := beego.AppConfig.String("fileUpPath") + h.Filename
//	file.Close()
//	c.SaveToFile("file", filePath)
//	res := &uitl.RtMsg{0, "上传成功！！", 0, fileHttp}
//	c.Data["json"] = res
//	c.ServeJSON()
//	return
//}

//beego展示图片，图片路径非static的时候使用方式！
var img_dir = beego.AppConfig.String("imgUpPath") //文件存储位置
func (c *MainController) ImagesSee() {
	url := c.Ctx.Request.URL.Path
	img := url[len("/images/"):]
	fmt.Println(img)
	file := img_dir + img
	f, err := os.Open(file)
	defer f.Close()

	if err != nil && os.IsNotExist(err) {
		logs.Error("no such img,", err)
	}
	http.ServeFile(c.Ctx.ResponseWriter, c.Ctx.Request, file)
}

func (c *MainController) SetSessionValues() {
	companyId, _ := c.GetInt("companyId")
	c.SetSession("companyId", companyId)
	res := &uitl.RtMsg{0, "切换成功！！！", 0, nil}
	c.Data["json"] = res
	c.ServeJSON()
	return
}

var file_dir = beego.AppConfig.String("fileUpPath") //文件存储位置
func (c *MainController) GetERPFile() {
	url := c.Ctx.Request.URL.Path
	filename := url[len("/file/"):]
	filepath := file_dir + filename
	f, err := os.Open(filepath)
	if err != nil {
		logs.Error("down file open err,", err)
		return
	}
	defer f.Close()

	if err != nil && os.IsNotExist(err) {
		c.Abort("404")
		return
	}
	fileNameSlice := strings.Split(filename, "/")
	fileNameSlice1 := strings.Split(fileNameSlice[len(fileNameSlice)-1], "_")
	fileNameSlice2 := strings.Split(fileNameSlice[len(fileNameSlice)-1], ".")

	//原生下载，pdf文件可网页打开，其他文件下载
	http.Header{}.Add("Content-Disposition", "attachment; filename="+url1.QueryEscape(fileNameSlice1[0]+"."+fileNameSlice2[1]))
	http.Header{}.Add("Content-Type", "application/octet-stream")
	http.ServeFile(c.Ctx.ResponseWriter, c.Ctx.Request, filepath)

	//beego下载所有文件文件
	//c.Ctx.ResponseWriter.Header().Add("Content-Disposition","attachment; filename="+url1.QueryEscape(fileNameSlice1[0]+"."+fileNameSlice2[1]))
	//c.Ctx.ResponseWriter.Header().Add("Content-Type", "application/octet-stream")
	//c.Ctx.Output.Download(filepath,url1.QueryEscape(fileNameSlice1[0]+"."+fileNameSlice2[1]))
}

/*
上传文件的方法
*/
func (c *MainController) FileUpload() {
	f, h, err := c.GetFile("uploadName") // 文件获取
	if err != nil {
		//log.Fatal("getfile err ", err)
		res := &uitl.RtMsg{1, "上传文件失败!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
	}
	defer f.Close()                                               // 文件流的关闭
	filepath, filename := uitl.GetFilePath(h.Filename, uitl.TEMP) // uuid文件名生成,路径生成
	c.SetSession("isChangeFile", true)                            // 修改文件状态为true
	c.SaveToFile("uploadName", filepath)
	res := &uitl.RtMsg{0, "上传文件成功!", 0, filename} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
}

/*
弹出修改密码界面
*/
func (c *MainController) UpdatePwdHtml() {
	c.TplName = "update_password.html"
}

/*
修改密码
*/
func (c *MainController) DoUpdatePwd() {
	user := c.GetSession("CPXERP").(models.User)
	password := c.GetString("password")
	user.Password = uitl.Md5PWD(password)
	user.PwdStatus = 1
	b := user.UpdatePassword()
	if b {
		res := &uitl.RtMsg{0, "修改成功", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}
