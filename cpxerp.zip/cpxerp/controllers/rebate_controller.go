package controllers

import (
	"github.com/astaxie/beego"
	"cpxerp/models"
	"cpxerp/util"
)

type ReabseController struct {
	beego.Controller
}

/*
通过合同ID找返点率
 */
func (r *ReabseController)GetReabetByCid(){
	c_id, err := r.GetInt(":id")
	if err != nil {
		r.Abort("404")
	}
	rebates, count, err := models.GetRebateByConId(c_id)

	res := &uitl.RtMsg{0, "请求成功", int(count), rebates} // 返回的对应的相应数据
	r.Data["json"] = res
	r.ServeJSON()
}