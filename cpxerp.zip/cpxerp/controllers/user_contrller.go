package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"encoding/json"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"github.com/shopspring/decimal"
	"github.com/tealeg/xlsx"
	"math"
	"strconv"
	"time"
)

type UserController struct {
	beego.Controller
}

//员工管理 ----- start -----
//录入员工界面
func (u *UserController) AddHtml() {
	companyId := u.GetSession("companyId").(int) // 公司ID
	u.Data["users"] = models.GetAllUsersByStatus("在职", companyId)
	u.Data["areas"] = models.SelectAllArea()
	u.Data["companies"] = models.SelectAllCompany()
	u.Data["departments"] = models.SelectAllDepartment()
	u.Data["businesses"] = models.SelectAllBusiness()
	u.TplName = "user_info/user_add.html"
}

//员工管理界面
func (u *UserController) ListHtml() {
	u.Data["areas"] = models.SelectAllArea()
	u.Data["departments"] = models.SelectAllDepartment()
	u.TplName = "user_info/user_list.html"
}

//员工更新字段界面
func (u *UserController) UpdateUserHtml() {
	user_id, err := u.GetInt(":id")
	if err != nil {
		logs.Error(err)
	}
	user, err := models.GetUserById(user_id)
	fmt.Println(user_id)
	companies := models.SelectAllCompany()
	departments := models.SelectAllDepartment()
	businesses := models.SelectAllBusiness()
	selected := models.GetBusinessByUserId(user_id)
	var selectedList []int
	for _, v := range selected {
		selectedList = append(selectedList, v.BusinessId)
	}
	data, err := json.Marshal(selectedList)
	u.Data["user"] = user
	u.Data["companies"] = companies
	u.Data["departments"] = departments
	u.Data["businesses"] = businesses
	u.Data["selected"] = string(data[:])
	u.TplName = "user_info/user_update.html"
}

/*
员工基本信息修改页面
*/
func (u *UserController) UpdateUserBaseHtml() {
	userId, err := u.GetInt(":id")          // 获取用户ID
	user, err := models.GetUserById(userId) // 获取用户model
	abnId, err := u.GetInt("abnId", 0)
	if err != nil {
		u.Abort("404")
	}
	timeOfEntry := user.TimeOfEntry.Format("2006-01-02")   // 解析入职时间
	birthday := user.Birthday.Format("2006-01-02")         // 解析生日
	graduateTime := user.GraduateTime.Format("2006-01-02") // 解析毕业时间
	workingHours := user.WorkingHours.Format("2006-01-02") // 解析参加工作时间
	contractNature := user.ContractNature                  // 合同类型
	var contractPeriod, probationPeriod int                // 初始化变量
	if contractNature == "合同制" {
		contractPeriod = user.ContractPeriod // 正式合同期限
		probationPeriod = 0
	} else if contractNature == "实习" {
		contractPeriod = 0
		probationPeriod = user.ProbationPeriod // 实习合同期限
	}
	// 页面渲染数据
	u.Data["user"] = user
	u.Data["TimeOfEntry"] = timeOfEntry
	u.Data["Birthday"] = birthday
	u.Data["GraduateTime"] = graduateTime
	u.Data["WorkingHours"] = workingHours
	u.Data["ContractPeriod"] = contractPeriod
	u.Data["ProbationPeriod"] = probationPeriod
	u.Data["abnId"] = abnId
	u.TplName = "user_info/user_update_base.html"
}

/*
员工岗位信息修改
auth: ttc
date: 2018-08-30
*/
func (u *UserController) UpdateUserPostHtml() {
	userId, err := u.GetInt(":id")               // 用户ID
	companyId := u.GetSession("companyId").(int) // 公司ID
	isAbnChange, err := u.GetInt("isAbnChange", 0)
	abnId, err := u.GetInt("abnId", 0)
	user, err := models.GetUserById(userId) // 用户Model
	if err != nil {
		u.Abort("404")
	}
	selected := models.GetBusinessByUserId(userId) // 用户当前所属商业线
	var selectedList []int
	for _, v := range selected {
		selectedList = append(selectedList, v.BusinessId)
	}
	data, err := json.Marshal(selectedList)
	// 初始化页面渲染数据
	employeeNature := []string{"合同制", "外派", "实习", "兼职"}
	incumbency := []string{"在职", "离职", "病休"}
	postAttributes := []string{"技术", "专业", "管理"}
	if isAbnChange == 0 {
		u.Data["title"] = "员工岗位修改"
	} else {
		u.Data["title"] = "异动员工岗位修改"
	}
	u.Data["user"] = user
	u.Data["users"] = models.GetAllUsersByStatus("在职", companyId)
	u.Data["areas"] = models.SelectAllArea()
	u.Data["employeeNature"] = employeeNature
	u.Data["incumbency"] = incumbency
	u.Data["postAttributes"] = postAttributes
	u.Data["companies"] = models.SelectAllCompany()
	u.Data["departments"] = models.SelectAllDepartment()
	u.Data["businesses"] = models.SelectAllBusiness()
	u.Data["selected"] = string(data[:])
	u.Data["isAbnChange"] = isAbnChange
	u.Data["abnId"] = abnId
	u.TplName = "user_info/user_update_post.html"
}

/*
员工薪资更新界面
auth: ttc
date: 2018-08-30
*/
func (u *UserController) UpdateUserSalaryHtml() {
	userId, err := u.GetInt(":id")
	user, err := models.GetUserById(userId)
	isAbnChange, err := u.GetInt("isAbnChange", 0)
	abnId, err := u.GetInt("abnId", 0)
	if err != nil {
		u.Abort("404")
	}
	probationSalary := user.ProbationBasicSalary + user.ProbationAchieveSalary
	regularSalary := user.RegularBasicSalary + user.RegularAchieveSalary
	u.Data["user"] = user
	u.Data["ProbationSalary"] = probationSalary
	u.Data["RegularSalary"] = regularSalary
	pasd := decimal.NewFromFloat(user.ProbationAchieveSalary)
	psd := decimal.NewFromFloat(probationSalary)
	if probationSalary == 0 {
		u.Data["ProbationAchievePercent"] = 0
	} else {
		u.Data["ProbationAchievePercent"], _ = pasd.Div(psd).Mul(decimal.New(100, 0)).Float64()
	}
	rasd := decimal.NewFromFloat(user.RegularAchieveSalary)
	rsd := decimal.NewFromFloat(regularSalary)
	if regularSalary == 0 {
		u.Data["RegularAchievePercent"] = 0
	} else {
		u.Data["RegularAchievePercent"], _ = rasd.Div(rsd).Mul(decimal.New(100, 0)).Float64()
	}
	u.Data["PaymentMonth"] = user.PaymentMonth.Format("2006-01-02")
	if isAbnChange == 0 {
		u.Data["title"] = "员工薪资修改"
	} else {
		u.Data["title"] = "异动员工薪资修改"
	}
	u.Data["isAbnChange"] = isAbnChange
	u.Data["abnId"] = abnId
	u.TplName = "user_info/user_update_salary.html"
}

/*
添加用户的方法
auth:ttc
*/
func (u *UserController) UserDoAdd() {
	opUser := u.GetSession("CPXERP").(models.User)
	postRecord := models.PostRecord{}
	salaryRecord := models.SalaryRecord{}
	user := models.User{} // 新建结构体
	areaId, err := u.GetInt("AreaId")
	departId, err := u.GetInt("DepartmentId")
	roleId, err := u.GetInt("RoleId")
	area, err := models.GetAreaById(areaId)
	depart, err := models.GetDepartmentById(departId)
	role, err := models.GetRoleById(roleId)
	if err != nil {
		res := &uitl.RtMsg{1, "修改失败，参数错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	busniessStr := u.GetString("business") //
	var businessList []string
	err = json.Unmarshal([]byte(busniessStr), &businessList)
	if err := u.ParseForm(&user); err != nil { // 对表单数据进行解析，转换为对应的结构体，判断是否出错
		res := &uitl.RtMsg{1, "添加失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 获取时间戳
	user.Password = uitl.Md5PWD("123456")
	timeOfEntry := u.GetString("TimeOfEntry") + " 00:00:00"        // 入职时间
	birthday := u.GetString("Birthday") + " 00:00:00"              // 生日
	graduateTime := u.GetString("GraduateTime") + " 00:00:00"      // 毕业时间
	workingHours := u.GetString("WorkingHours") + " 00:00:00"      // 工作时间
	paymentMonth := u.GetString("PaymentMonth") + " 00:00:00"      // 缴纳时间
	entry, _ := time.Parse("2006-01-02 15:04:05", timeOfEntry)     // 解析为时间戳
	birth, _ := time.Parse("2006-01-02 15:04:05", birthday)        // 解析为时间戳
	graduate, _ := time.Parse("2006-01-02 15:04:05", graduateTime) // 解析为时间戳
	working, _ := time.Parse("2006-01-02 15:04:05", workingHours)  // 解析为时间戳
	payMonth, _ := time.Parse("2006-01-02 15:04:05", paymentMonth) // 解析为时间戳
	user.TimeOfEntry = entry
	user.Birthday = birth
	user.GraduateTime = graduate
	user.WorkingHours = working

	contractNature := u.GetString("ContractNature")
	nowTime := time.Now()
	if contractNature == "合同制" {
		var ContractPeriod int
		ContractPeriod, err = u.GetInt("ContractPeriod")
		user.RegularTime = uitl.CalculateTime(timeOfEntry, 0, ContractPeriod, 0)     // 计算转正时间
		user.ContractEndTime = uitl.CalculateTime(timeOfEntry, ContractPeriod, 0, 0) // 计算合同到期时间
		user.PaymentMonth = payMonth
		if nowTime.After(user.RegularTime) {
			user.NatureOfWork = "转正"
		} else {
			user.NatureOfWork = "试用"
		}
	} else if contractNature == "实习" {
		var probationPeriod int
		probationPeriod, err = u.GetInt("ProbationPeriod")
		user.PracticeEndTime = uitl.CalculateTime(timeOfEntry, 0, probationPeriod, 0) // 计算实习到期时间
		user.ContractPeriod = probationPeriod
		if nowTime.After(user.PracticeEndTime) {
			user.NatureOfWork = "试用"
		} else {
			user.NatureOfWork = "实习"
		}
	}
	if err != nil {
		logs.Info(err)
		res := &uitl.RtMsg{1, "添加失败，数据获取计算错误！", 0, nil} // 返回对于的错误信息
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	probationSalary, err := decimal.NewFromString(u.GetString("ProbationSalary", "0.00"))
	regularSalary, err := decimal.NewFromString(u.GetString("RegularSalary", "0.00"))
	if err != nil {
		logs.Error(err)
		res := &uitl.RtMsg{1, "添加失败，工资数值解析错误！", 0, nil} // 返回对于的错误信息
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	user.ProbationAchieveSalary, _ = probationSalary.Mul(decimal.New(3, -1)).Float64()
	user.ProbationBasicSalary, _ = probationSalary.Mul(decimal.New(7, -1)).Float64()
	user.RegularAchieveSalary, _ = regularSalary.Mul(decimal.New(3, -1)).Float64()
	user.RegularBasicSalary, _ = regularSalary.Mul(decimal.New(7, -1)).Float64()
	userId, err := models.AddUser(&user) // 添加数据
	if err != nil {                      // 是否有错，有错就进入
		logs.Error(err)
		res := &uitl.RtMsg{1, "添加失败，数据插入错误！", 0, nil} // 返回对于的错误信息
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	if user.NatureOfWork == "转正" {
		//年假计算
		newUser, _ := models.GetUserById(int(userId))
		annualLeave := models.MakeUserAnnualLeave(*newUser)
		annualLeave.Add()
	}
	models.AddUserBusinessRel(&user, businessList)
	// 添加职位记录
	postRecord.AreaName = area.AreaName
	postRecord.DepartName = depart.DepartmentName
	postRecord.Role = role.RoleName
	postRecord.UserId = user.Id
	postRecord.Business = user.BusinessStr
	postRecord.EmployeeNature = user.EmployeeNature
	postRecord.Incumbency = user.Incumbency
	postRecord.PostAttributes = user.PostAttributes
	postRecord.PostRank = user.PostRank
	postRecord.NatureOfWork = user.NatureOfWork
	postRecord.IsAbnormalChange = -1
	postRecord.ChangeUser = opUser.Name
	models.AddRoleRecord(&postRecord)
	// 添加薪资记录
	salaryRecord.UserId = user.Id
	if user.NatureOfWork == "转正" {
		salaryRecord.BasicSalary = user.RegularBasicSalary
		salaryRecord.AchieveSalary = user.RegularAchieveSalary
		salaryRecord.Salary, _ = decimal.NewFromFloat(user.RegularBasicSalary).
			Add(decimal.NewFromFloat(user.RegularAchieveSalary)).Float64()
	} else if user.NatureOfWork == "实习" {
		salaryRecord.BasicSalary = user.InternshipSalary
		salaryRecord.AchieveSalary = 0
		salaryRecord.Salary = user.InternshipSalary
	} else if user.NatureOfWork == "试用" {
		salaryRecord.BasicSalary = user.ProbationBasicSalary
		salaryRecord.AchieveSalary = user.ProbationAchieveSalary
		salaryRecord.Salary, _ = decimal.NewFromFloat(user.ProbationBasicSalary).
			Add(decimal.NewFromFloat(user.ProbationAchieveSalary)).Float64()
	}
	salaryRecord.NatureOfWork = user.NatureOfWork
	salaryRecord.IsAbnormalChange = -1
	postRecord.ChangeUser = opUser.Name
	models.AddSalaryRecord(&salaryRecord)
	res := &uitl.RtMsg{0, "添加成功！", 0, nil} // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

/*
删除用户的方法
auth:ttc
*/
func (u *UserController) UserDoDelete() {
	user_id, err := u.GetInt(":id")
	// 抓取参数错误
	if err != nil {
		res := &uitl.RtMsg{1, "删除失败，参数错误！", 0, nil} // 添加成功， 返回对于的JSON数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	err = models.DeleteUser(user_id)
	// 抓取数据库操作错误
	if err != nil {
		res := &uitl.RtMsg{1, "删除失败，数据库删除错误！", 0, nil} // 添加成功， 返回对于的JSON数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 删除数据成功
	res := &uitl.RtMsg{0, "删除成功！", 0, nil} // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

/*
查询员工的方法
auth:ttc
*/
func (u *UserController) UserDoSelect() {
	name := u.GetString("name")
	employeeNature := u.GetString("EmployeeNature")
	incumbency := u.GetString("Incumbency")
	areaId, err := u.GetInt("AreaId", 0)
	departId, err := u.GetInt("DepartmentId", 0)
	roleId, err := u.GetInt("RoleId", 0)
	if err != nil {
		u.Abort("404")
	}
	filter := map[string]interface{}{}
	if len(employeeNature) > 0 {
		filter["employee_nature"] = employeeNature
	}
	if len(incumbency) > 0 {
		filter["incumbency"] = incumbency
	}
	if areaId != 0 {
		filter["area"] = areaId
	}
	if departId != 0 {
		filter["department_id"] = departId
	}
	if roleId != 0 {
		filter["role_id"] = roleId
	}
	if cid := u.GetSession("companyId"); cid == nil {
		filter["company_id"] = 1
	} else {
		filter["company_id"] = cid.(int)
	}
	// 获取页码
	page, err := u.GetInt("page")
	if err != nil {
		page = 1
	}
	// 获取数量限制
	limit, err := u.GetInt("limit")
	if err != nil {
		limit = 10
	}
	// 获取User数组
	//pageData := models.SelectAllUser(name, company_id, page, limit)
	data := models.SelectUserByFilter(filter, name, page, limit)
	count := models.GetUserCountByFilter(filter, name)
	if data == nil {
		res := &uitl.RtMsg{1, "数据为空！！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "获取数据成功！！", int(count), data}
	u.Data["json"] = res
	u.ServeJSON()
}

/*
更新员工的方法
auth:ttc
*/
func (u *UserController) UserDoUpdate() {
	userId, err := u.GetInt("Id")
	user, err := models.GetUserById(userId)
	if err != nil {
		u.Abort("404")
	}
	busniessStr := u.GetString("business") //
	if len(busniessStr) > 0 {
		var businessList []string
		err = json.Unmarshal([]byte(busniessStr), &businessList)
		err = models.UpdateUserBusinessRel(user, businessList)
	}
	if err != nil {
		res := &uitl.RtMsg{1, "修改失败，业务线修改失败！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	if err := u.ParseForm(user); err != nil { // 对表单数据进行解析，转换为对应的结构体，判断是否出错
		res := &uitl.RtMsg{1, "修改失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 赋值新的更新时间
	err = models.UpdateUserById(user)
	if err != nil {
		res := &uitl.RtMsg{1, "修改失败，数据插入错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

	// 修改成功
	res := &uitl.RtMsg{0, "修改成功！", 0, nil} // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

/*
更新员工基本信息
auth:ttc
date:2018-08-31
*/
func (u *UserController) UserDoUpdateBase() {
	userId, err := u.GetInt("Id")           // 用户ID
	user, err := models.GetUserById(userId) // 用户Model
	abnId, err := u.GetInt("abnId", 0)
	if err != nil {
		u.Abort("404") // 为找到用户返回404, 页面
	}

	if err := u.ParseForm(user); err != nil { // 对表单数据进行解析，转换为对应的结构体，判断是否出错
		res := &uitl.RtMsg{1, "修改失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 表单解析无法对时间解析,需要手动进行转换
	timeOfEntry := u.GetString("TimeOfEntry") + " 00:00:00"        // 入职时间
	birthday := u.GetString("Birthday") + "00:00:00"               // 生日
	graduateTime := u.GetString("GraduateTime") + " 00:00:00"      // 毕业时间
	workingHours := u.GetString("WorkingHours") + " 00:00:00"      // 工作时间
	entry, _ := time.Parse("2006-01-02 15:04:05", timeOfEntry)     // 解析为时间戳
	birth, _ := time.Parse("2006-01-02 15:04:05", birthday)        // 解析为时间戳
	graduate, _ := time.Parse("2006-01-02 15:04:05", graduateTime) // 解析为时间戳
	working, _ := time.Parse("2006-01-02 15:04:05", workingHours)  // 解析为时间戳
	user.TimeOfEntry = entry
	user.Birthday = birth
	user.GraduateTime = graduate
	user.WorkingHours = working
	nowTime := time.Now()                           // 获取当前时间戳
	contractNature := u.GetString("ContractNature") // 合同性质
	if contractNature == "合同制" {
		var ContractPeriod int
		// 合同制有社保缴纳月字段, 一下是通过入职时间计算社保缴纳月份
		var year, month int
		year = entry.Year()
		if entry.Day() > 15 {
			month = int(entry.Month()) + 1
			if month > 12 {
				year += 1
				month = 1
			}
		} else {
			month = int(entry.Month())
		}
		payMonth := time.Date(year, time.Month(month), 1, 0, 0, 0, 0, time.Local)    // 转换为时间
		ContractPeriod, err = u.GetInt("ContractPeriod")                             //合同期限
		user.RegularTime = uitl.CalculateTime(timeOfEntry, 0, ContractPeriod, 0)     // 计算转正时间
		user.ContractEndTime = uitl.CalculateTime(timeOfEntry, ContractPeriod, 0, 0) // 计算合同到期时间
		user.PaymentMonth = payMonth
		// 判断工作性质
		if nowTime.After(user.RegularTime) {
			user.NatureOfWork = "转正"
			annualLeave := models.MakeUserAnnualLeave(*user)
			annualLeave.Add()
		} else {
			user.NatureOfWork = "试用"
		}
	} else if contractNature == "实习" {
		// 实习的分析实习到期时间
		var probationPeriod int
		probationPeriod, err = u.GetInt("ProbationPeriod")
		user.PracticeEndTime = uitl.CalculateTime(timeOfEntry, 0, probationPeriod, 0) // 计算实习到期时间
		user.ContractPeriod = probationPeriod
		// 判断工作性质
		if nowTime.After(user.PracticeEndTime) {
			user.NatureOfWork = "试用"
		} else {
			user.NatureOfWork = "实习"
		}
	}
	if err != nil {
		logs.Error(err)
		res := &uitl.RtMsg{1, "添加失败，数据获取计算错误！", 0, nil} // 返回对于的错误信息
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 更新数据
	err = models.UpdateUserById(user)
	if err != nil {
		res := &uitl.RtMsg{1, "修改失败，数据插入错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 修改成功
	if abnId != 0 {
		abnChange, err := models.GetAbnormalChangeById(abnId)
		abnChange.IsChangeInfo = 1
		err = models.UpdateAbnormalChangeById(abnChange)
		if err != nil {
			res := &uitl.RtMsg{1, "修改失败,异动状态修改失败！", 0, nil} // 添加成功， 返回对于的JSON数据
			u.Data["json"] = res
			u.ServeJSON()
			return
		}
	}
	res := &uitl.RtMsg{0, "修改成功！", 0, nil} // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

/*
用户岗位信息修改
auth: ttc
date: 2018-08-31
*/
func (u *UserController) UserDoUpdatePost() {
	opUser := u.GetSession("CPXERP").(models.User)
	userId, err := u.GetInt("Id") // 用户ID
	postRecord := models.PostRecord{}
	user, err := models.GetUserById(userId) // 用户Model
	if err != nil {
		u.Abort("404")
	}
	abnId, err := u.GetInt("abnId", 0)
	areaId, err := u.GetInt("AreaId")
	departId, err := u.GetInt("DepartmentId")
	roleId, err := u.GetInt("RoleId")
	isAbnChange, err := u.GetInt("isAbnChange", 0)
	area, err := models.GetAreaById(areaId)
	depart, err := models.GetDepartmentById(departId)
	role, err := models.GetRoleById(roleId)
	if err != nil {
		res := &uitl.RtMsg{1, "修改失败，参数错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

	err = u.ParseForm(user)
	if err != nil { // 对表单数据进行解析，转换为对应的结构体，判断是否出错
		res := &uitl.RtMsg{1, "修改失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 业务线json数据
	busniessStr := u.GetString("business")
	if len(busniessStr) > 0 {
		// json 数据解析
		var businessList []string
		err = json.Unmarshal([]byte(busniessStr), &businessList)
		models.UpdateUserBusinessRel(user, businessList) // 跟新用户业务线
	}
	// 更新用户数据
	err = models.UpdateUserById(user)
	if err != nil {
		res := &uitl.RtMsg{1, "修改失败，数据插入错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 添加职位变更记录
	postRecord.AreaName = area.AreaName
	postRecord.DepartName = depart.DepartmentName
	postRecord.Role = role.RoleName
	postRecord.UserId = user.Id
	postRecord.Business = user.BusinessStr
	postRecord.EmployeeNature = user.EmployeeNature
	postRecord.Incumbency = user.Incumbency
	postRecord.PostAttributes = user.PostAttributes
	postRecord.PostRank = user.PostRank
	postRecord.NatureOfWork = user.NatureOfWork
	postRecord.IsAbnormalChange = isAbnChange
	postRecord.ChangeUser = opUser.Name
	_, err = models.AddRoleRecord(&postRecord)
	if err != nil {
		logs.Error(err)
	}
	// 修改成功
	if abnId != 0 {
		abnChange, err := models.GetAbnormalChangeById(abnId)
		abnChange.IsChangePost = 1
		postRecord.AbnType = abnChange.ApplyType
		err = models.UpdateAbnormalChangeById(abnChange)
		err = models.UpdateRoleRecordById(&postRecord)
		if err != nil {
			res := &uitl.RtMsg{1, "修改失败,异动状态修改失败！", 0, nil} // 添加成功， 返回对于的JSON数据
			u.Data["json"] = res
			u.ServeJSON()
			return
		}
	}
	res := &uitl.RtMsg{0, "修改成功！", 0, nil} // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

/*
更新用户薪资行为
auth: ttc
date: 2018-08-31
*/
func (u *UserController) UserDoUpdateSalary() {
	opUser := u.GetSession("CPXERP").(models.User)
	salaryRecord := models.SalaryRecord{}
	userId, err := u.GetInt("Id")
	user, err := models.GetUserById(userId)
	isAbnChange, err := u.GetInt("isAbnChange", 0)
	abnId, err := u.GetInt("abnId", 0)
	if err != nil {
		u.Abort("404")
	}

	if err := u.ParseForm(user); err != nil { // 对表单数据进行解析，转换为对应的结构体，判断是否出错
		res := &uitl.RtMsg{1, "修改失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	probationSalary, err := decimal.NewFromString(u.GetString("ProbationSalary", "0.00"))
	paPercent, err := decimal.NewFromString(u.GetString("ProbationAchievePercent", "0"))
	regularSalary, err := decimal.NewFromString(u.GetString("RegularSalary", "0.00"))
	raPercent, err := decimal.NewFromString(u.GetString("RegularAchievePercent", "0"))
	paPercent = paPercent.Div(decimal.NewFromFloat(100))
	raPercent = raPercent.Div(decimal.NewFromFloat(100))
	if err != nil {
		logs.Error(err)
		res := &uitl.RtMsg{1, "修改失败，工资数值解析错误！", 0, nil} // 返回对于的错误信息
		u.Data["json"] = res
		u.ServeJSON()
		return // 赋值新的更新时间
	}
	user.ProbationAchieveSalary, _ = probationSalary.Mul(paPercent).Float64()
	user.ProbationBasicSalary, _ = probationSalary.Sub(probationSalary.Mul(paPercent)).Float64()
	user.RegularAchieveSalary, _ = regularSalary.Mul(raPercent).Float64()
	user.RegularBasicSalary, _ = regularSalary.Sub(regularSalary.Mul(raPercent)).Float64()
	err = models.UpdateUserById(user)
	if err != nil {
		res := &uitl.RtMsg{1, "修改失败，数据插入错误！", 0, nil} // 返回的对应的相应数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	// 添加薪资记录
	salaryRecord.UserId = user.Id
	if user.NatureOfWork == "转正" {
		salaryRecord.BasicSalary = user.RegularBasicSalary
		salaryRecord.AchieveSalary = user.RegularAchieveSalary
		salaryRecord.Salary, _ = decimal.NewFromFloat(user.RegularBasicSalary).
			Add(decimal.NewFromFloat(user.RegularAchieveSalary)).Float64()
	} else if user.NatureOfWork == "实习" {
		salaryRecord.BasicSalary = user.InternshipSalary
		salaryRecord.AchieveSalary = 0
		salaryRecord.Salary = user.InternshipSalary
	} else if user.NatureOfWork == "试用" {
		salaryRecord.BasicSalary = user.ProbationBasicSalary
		salaryRecord.AchieveSalary = user.ProbationAchieveSalary
		salaryRecord.Salary, _ = decimal.NewFromFloat(user.ProbationBasicSalary).
			Add(decimal.NewFromFloat(user.ProbationAchieveSalary)).Float64()
	}
	salaryRecord.NatureOfWork = user.NatureOfWork
	salaryRecord.IsAbnormalChange = isAbnChange
	salaryRecord.ChangeUser = opUser.Name
	models.AddSalaryRecord(&salaryRecord)
	// 修改成功
	if abnId != 0 {
		abnChange, err := models.GetAbnormalChangeById(abnId)
		salaryRecord.AbnType = abnChange.ApplyType
		abnChange.IsChangeSalary = 1
		err = models.UpdateAbnormalChangeById(abnChange)
		err = models.UpdateSalaryRecordById(&salaryRecord)
		if err != nil {
			res := &uitl.RtMsg{1, "修改失败,异动状态修改失败！", 0, nil} // 添加成功， 返回对于的JSON数据
			u.Data["json"] = res
			u.ServeJSON()
			return
		}
	}
	res := &uitl.RtMsg{0, "修改成功！", 0, nil} // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

func (u *UserController) UserDoRegular() {
	opUser := u.GetSession("CPXERP").(models.User)		// 当前操作人
	userId, err := u.GetInt(":id")							// 转正人Id
	user, err := models.GetUserById(userId)						// 查找转正人user
	postRecord := models.PostRecord{}							// 岗位变更记录
	isAbnChange, err := u.GetInt("isAbnChange", 0)		// 是否是异动
	abnId, err := u.GetInt("abnId", 0)
	area, err := models.GetAreaById(user.AreaId)
	depart, err := models.GetDepartmentById(user.DepartmentId)
	role, err := models.GetRoleById(user.RoleId)
	if err != nil {
		logs.Error(err)
		u.Abort("404")
	}
	user.NatureOfWork = "转正"
	user.RegularTime = time.Now() // 转正入职时间更新
	err = models.UpdateUserById(user)
	if err != nil {
		logs.Error(err)
		u.Abort("500")
	}
	ann := models.AnnualLeave{}
	ann.UserId = user.Id
	if ann.SelectByUserId() == nil  {
		annualLeave := models.MakeUserAnnualLeave(*user)
		annualLeave.Add()
	}
	// 添加职位变更记录
	postRecord.AreaName = area.AreaName
	postRecord.DepartName = depart.DepartmentName
	postRecord.Role = role.RoleName
	postRecord.UserId = user.Id
	postRecord.Business = user.BusinessStr
	postRecord.EmployeeNature = user.EmployeeNature
	postRecord.Incumbency = user.Incumbency
	postRecord.PostAttributes = user.PostAttributes
	postRecord.PostRank = user.PostRank
	postRecord.NatureOfWork = user.NatureOfWork
	postRecord.IsAbnormalChange = isAbnChange
	postRecord.ChangeUser = opUser.Name
	_, err = models.AddRoleRecord(&postRecord)
	if err != nil {
		logs.Error(err)
		u.Abort("500")
	}
	if abnId != 0 {
		abnChange, err := models.GetAbnormalChangeById(abnId)
		abnChange.IsChangePost = 1
		postRecord.AbnType = abnChange.ApplyType
		err = models.UpdateAbnormalChangeById(abnChange)
		err = models.UpdateRoleRecordById(&postRecord)
		if err != nil {
			logs.Error(err)
			u.Abort("500")				// 修改失败,异动状态修改失败!
		}
	}
	res := &uitl.RtMsg{0, "转正成功！", 0, nil} // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

//批量导入员工信息，已有的员工不做操作，只新增新的员工；
func (u *UserController) UserAddByExcel() {
	companyId := u.GetSession("companyId").(int)
	f, h, err := u.GetFile("excl")
	if err != nil {
		logs.Error("getfile err ", err)
	}
	defer f.Close()
	filePath := beego.AppConfig.String("fileUpPath") + "TEMP/" + h.Filename
	u.SaveToFile("excl", filePath)
	//开始解析excel文件
	xlFile, err := xlsx.OpenFile(filePath)
	if err != nil {
		logs.Info("read excel err ,", err)
		return
	}
	users := make([]models.User, 0)
	tim := time.Now()
	var flag bool = true
	var msgs string = ""
A:
	for _, sheet := range xlFile.Sheets {
		if sheet.Name == "在职" {
			fmt.Printf("Sheet Name: %s\n", sheet.Name)
			j := 0
			for k, row := range sheet.Rows {
				if k > 1 {
					user := models.User{}
					//先用身份证查询员工，如果存在丢弃这条信息，没有就开始组装信息，准备入库
					u := user.SelectByIdCard(row.Cells[21].String())
					if u == nil {
						u2 := user.SelectUserNum(companyId)
						if u2 == nil {
							num := "M0001"
							userNum := uitl.GetMnum(&num, j, false)
							user.EmployeeNum = *userNum
							j++
						} else {
							userNum := uitl.GetMnum(&u2.EmployeeNum, j, true)
							user.EmployeeNum = *userNum
							j++
						}

						dep := models.Department{}
						b, depart := dep.GetDepartmentByName(row.Cells[2].String())
						if !b {
							flag = false
							msgs = "部门有误请检查"
							break A
						}
						user.DepartmentId = depart.DepartmentId
						user.EmployeeNature = row.Cells[3].String()

						area := models.Area{}
						b, a1 := area.GetAreaByName(row.Cells[4].String())
						if !b {
							flag = false
							msgs = "区域有误请检查"
							break A
						}
						user.AreaId = a1.AreaId

						user.ContractNum = row.Cells[5].String()
						user.Name = row.Cells[6].String()
						user.BusinessStr = row.Cells[7].String()
						role := models.Role{}
						b, ro := role.GetRoleByName(row.Cells[8].String())
						if !b {
							flag = false
							msgs = "岗位有误请检查"
							break A
						}
						user.RoleId = ro.RoleId

						posts := []rune(row.Cells[39].String())
						if string(posts[0]) == "M" {
							user.PostAttributes = "管理"
						}
						if string(posts[0]) == "P" {
							user.PostAttributes = "专业"
						}
						if string(posts[0]) == "T" {
							user.PostAttributes = "技术"
						}

						user.Incumbency = row.Cells[10].String()
						user.RecruitMethod = row.Cells[11].String()
						user.Email = row.Cells[12].String()
						user.QQNum = row.Cells[13].String()
						user.PhoneNumber = row.Cells[14].String()
						user.ContractNature = row.Cells[15].String()
						contractPeriod, _ := row.Cells[16].Int()
						//计算到合同截止的属性
						if row.Cells[15].String() == "合同制" {
							user.ContractPeriod = contractPeriod
							user.TimeOfEntry = uitl.StrToDay(row.Cells[17].String())
							user.RegularTime = uitl.CalculateTime(row.Cells[17].String()+" 00:00:00", 0, contractPeriod, 0)
							user.ProbationPeriod = 0
							user.PracticeEndTime = uitl.StrToDay("0001-01-01")
							user.ContractEndTime = uitl.CalculateTime(row.Cells[17].String()+" 00:00:00", contractPeriod, 0, 0)
						} else if row.Cells[15].String() == "实习" {
							user.ContractPeriod = contractPeriod
							user.TimeOfEntry = uitl.StrToDay(row.Cells[17].String())
							user.RegularTime = uitl.CalculateTime(row.Cells[17].String()+" 00:00:00", 0, contractPeriod, 0)
							user.ProbationPeriod = 0
							user.PracticeEndTime = uitl.CalculateTime(row.Cells[17].String()+" 00:00:00", 0, contractPeriod, 0)
							user.ContractEndTime = uitl.StrToDay("0001-01-01")
						} else {
							user.ContractPeriod = contractPeriod
							user.TimeOfEntry = uitl.StrToDay("0001-01-01")
							user.RegularTime = uitl.StrToDay("0001-01-01")
							user.ProbationPeriod = 0
							user.PracticeEndTime = uitl.StrToDay("0001-01-01")
							user.ContractEndTime = uitl.StrToDay("0001-01-01")
						}
						user.IDCard = row.Cells[21].String()
						user.Birthday = uitl.StrToDay(row.Cells[22].String())
						age, _ := row.Cells[23].Int()
						user.Age = age
						user.Sex = row.Cells[24].String()
						user.Nation = row.Cells[25].String()
						user.NativePlace = row.Cells[26].String()
						user.GraduateSchool = row.Cells[27].String()
						user.Major = row.Cells[28].String()
						user.Education = row.Cells[29].String()
						user.GraduateTime = uitl.StrToMonth(row.Cells[30].String())
						user.PoliticalOutlook = row.Cells[31].String()
						user.MaritalStatus = row.Cells[32].String()
						user.LanguageLevel = row.Cells[33].String()
						user.ComputerLevel = row.Cells[34].String()
						user.WorkingHours = uitl.StrToMonth(row.Cells[35].String())
						user.WorkUnit = row.Cells[36].String()
						user.BankCardInfo = row.Cells[37].String()
						user.BankCardNum = row.Cells[38].String()
						user.PostRank = row.Cells[39].String()

						//工资
						if row.Cells[15].String() == "合同制" {
							user.InternshipSalary = 0

							probationBasicSalary, _ := row.Cells[41].Float()
							user.ProbationBasicSalary = uitl.Decimal(probationBasicSalary, "2")

							probationAchieveSalary, _ := row.Cells[42].Float()
							user.ProbationAchieveSalary = uitl.Decimal(probationAchieveSalary, "2")

							regularBasicSalary, _ := row.Cells[43].Float()
							user.RegularBasicSalary = uitl.Decimal(regularBasicSalary, "2")

							regularAchieveSalary, _ := row.Cells[44].Float()
							user.RegularAchieveSalary = uitl.Decimal(regularAchieveSalary, "2")

							numOfInsurance, _ := row.Cells[45].Float()
							user.NumOfInsurance = uitl.Decimal(numOfInsurance, "2")

							numOfUnempLoymentInsurance, _ := row.Cells[46].Float()
							user.NumOfUnempLoymentInsurance = uitl.Decimal(numOfUnempLoymentInsurance, "2")

							numOfMedicalInsurance, _ := row.Cells[47].Float()
							user.NumOfMedicalInsurance = uitl.Decimal(numOfMedicalInsurance, "2")

							accumulationFundBase, _ := row.Cells[48].Float()
							user.AccumulationFundBase = uitl.Decimal(accumulationFundBase, "2")

							user.PaymentMonth = uitl.StrToMonth(row.Cells[49].String())

							taxSubsidy, _ := row.Cells[50].Float()
							user.TaxSubsidy = uitl.Decimal(taxSubsidy, "2")
							otherSubsidies, _ := row.Cells[51].Float()
							user.OtherSubsidies = uitl.Decimal(otherSubsidies, "2")

							user.SocialSecurityType = row.Cells[52].String()

						} else if row.Cells[15].String() == "实习" {
							internshipSalary, _ := row.Cells[40].Float()
							user.InternshipSalary = uitl.Decimal(internshipSalary, "2")
							user.ProbationBasicSalary = 0
							user.ProbationAchieveSalary = 0
							user.RegularBasicSalary = 0
							user.RegularAchieveSalary = 0
							user.NumOfInsurance = 0
							user.NumOfUnempLoymentInsurance = 0
							user.NumOfMedicalInsurance = 0
							user.AccumulationFundBase = 0
							user.PaymentMonth = uitl.StrToMonth("0001-01")
							user.SocialSecurityType = row.Cells[52].String()
						} else {
							internshipSalary, _ := row.Cells[40].Float()
							user.InternshipSalary = uitl.Decimal(internshipSalary, "2")
							user.ProbationBasicSalary = 0
							user.ProbationAchieveSalary = 0
							user.RegularBasicSalary = 0
							user.RegularAchieveSalary = 0
							user.NumOfInsurance = 0
							user.NumOfUnempLoymentInsurance = 0
							user.NumOfMedicalInsurance = 0
							user.AccumulationFundBase = 0
							user.PaymentMonth = uitl.StrToMonth("0001-01")
							user.SocialSecurityType = row.Cells[52].String()
						}

						user.RegisteredResidence = row.Cells[53].String()
						user.RegisteredType = row.Cells[54].String()
						user.BirthAddress = row.Cells[55].String()
						user.PresentAddress = row.Cells[56].String()
						user.EmergencyContact = row.Cells[57].String()
						user.Relationship = row.Cells[58].String()
						user.ContactInformation = row.Cells[59].String()
						user.AttendanceNum = row.Cells[60].String()
						user.NatureOfWork = row.Cells[61].String()
						user.Password = uitl.Md5PWD("123456")
						user.CreateTime = tim
						user.UpdateTime = tim
						user.CompanyId = companyId
						user.Superior = 0

						users = append(users, user)
					}

				}

			}
			break
		}

	}
	if flag {

		user1 := models.User{}

		if len(users) > 0 {

			b, msg := user1.AddByExcel(users)
			if b {

				//最后都要删除这个文件
				//查询所有在职，已转正的员工，筛选出还未入年假表的数据，初始化年假，并入库
				formalUsers := user1.SelectOfficialormalUsers(companyId)
				formal := make([]models.AnnualLeave, 0)
				for _, v := range formalUsers {
					anl := models.AnnualLeave{}
					anl.UserId = v.Id
					annualLeave := anl.SelectByUserId()
					if annualLeave == nil {
						//初始化计算个人的年假
						userAnnualLeave := models.MakeUserAnnualLeave(v)
						formal = append(formal, userAnnualLeave)
					}
				}
				if len(formal) > 0 {
					an1 := models.AnnualLeave{}
					_, err = an1.AddList(formal)
					if err != nil {
						logs.Error("userAnnualUserAddByExcelLeave err,", err)
					}
				}

				fmt.Println(h.Filename)
				res := &uitl.RtMsg{0, msg, 0, nil}
				u.Data["json"] = res
				u.ServeJSON()
				return
			} else {
				res := &uitl.RtMsg{1, msg, 0, nil}
				u.Data["json"] = res
				u.ServeJSON()
				return
			}
		} else {
			res := &uitl.RtMsg{1, "请检查表格数据是否是最新的", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}
	} else {
		res := &uitl.RtMsg{1, msgs, 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

}

/*
通过岗位属性获取,职级
auth: ttc
date: 2018-08-30
*/
func (u *UserController) GetRankByType() {
	types := u.GetString("type", "")
	if types == "技术" {
		dates := models.SelectAllTRank()
		res := &uitl.RtMsg{0, "获取数据成功！", 0, dates} // 获取成功， 返回对于的JSON数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else if types == "专业" {
		dates := models.SelectAllPRank()
		res := &uitl.RtMsg{0, "获取数据成功！", 0, dates} // 获取成功， 返回对于的JSON数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else if types == "管理" {
		dates := models.SelectAllMRank()
		res := &uitl.RtMsg{0, "获取数据成功！", 0, dates} // 获取成功， 返回对于的JSON数据
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	res := &uitl.RtMsg{1, "获取数据失败！", 0, nil} // 获取失败， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

/*
通过部门获区相关职位信息
auth: ttc
date: 2018-08-30
*/
func (u *UserController) GetRoleByDepartId() {
	departId, err := u.GetInt("depart_id") // 获取部门ID
	if err != nil {
		u.Abort("404") // 获取ID失败,返回404
	}
	dates := models.GetRoleByDepartId(departId) // 获取岗位数据
	res := &uitl.RtMsg{0, "获取数据成功！", 0, dates}  // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

func (u *UserController) GetUsersByDepartId() {
	companyId := u.GetSession("companyId").(int)
	departId, err := u.GetInt("departId") // 获取部门ID
	if err != nil {
		u.Abort("404")
	}
	filter := map[string]interface{}{}
	filter["department_id"] = departId
	filter["company_id"] = companyId
	filter["incumbency"] = "在职"
	users := models.SelectUserByFilter(filter, "", 0, 0)
	res := &uitl.RtMsg{0, "获取数据成功！", 0, users} // 添加成功， 返回对于的JSON数据
	u.Data["json"] = res
	u.ServeJSON()
	return
}

/*
导出数据到excel表格中
auth:ttc
date: 2018-08-31
*/
func (u *UserController) OutputUserExcel() {
	companyId := u.GetSession("companyId").(int) // 公司ID
	xlFile := xlsx.NewFile()
	titleList := []string{
		"序号", "员工编号", "部门", "员工性质", "地区", "合同编号", "姓名", "业务线", "任职岗位", "岗位属性",
		"状态", "招聘方式", "企业邮箱", "QQ号", "手机号", "合同性质", "合同期限", "入职时间", "转正日期", "实习截止",
		"合同截至日", "身份证号", "出生日期", "年龄", "性别", "民族", "籍贯", "毕业学院", "所学专业", "最高学历", "毕业时间",
		"政治面貌", "婚姻状况", "外语水平", "计算机水平", "参加工作时间", "入职前工作单位", "银行卡信息", "银行卡号", "职级",
		"实习工资", "试用期基本工资", "试用期绩效工资", "转正后基本工资", "转正后绩效工资", "基本养老保险基数", "失业保险基数", "基本医疗保险基数", "公积金缴纳基数",
		"缴纳月份", "税后补贴", "其他补贴", "社保类型", "户口所在地", "户口性质", "出生地址", "现居地址", "紧急联系人", "紧急联系关系",
		"紧急联系人电话", "考勤机号码", "工作性质"}
	var userList [][]models.User
	userList = append(userList, models.GetAllUsersByStatus("在职", companyId))
	userList = append(userList, models.GetAllUsersByStatus("离职", companyId))
	userList = append(userList, models.GetAllUsersByStatus("病休", companyId))
	xlFile.AddSheet("在职")
	xlFile.AddSheet("离职")
	xlFile.AddSheet("病休")
	for s, sheet := range xlFile.Sheets {
		users := userList[s]
		//fmt.Println(users)
		for r := 0; r < len(users)+2; r++ {
			fmt.Println(r)
			if r == 0 {
				sheet.AddRow().AddCell().SetValue("CPX员工信息表")
			}
			if r == 1 {
				raw := sheet.AddRow()
				for _, v := range titleList {
					raw.AddCell().SetValue(v)
				}
			}
			if r > 1 {
				var raw *xlsx.Row
				raw = sheet.AddRow()
				user := users[r-2]
				raw.AddCell().SetValue(user.Id)                            // 序号
				raw.AddCell().SetValue(user.EmployeeNum)                   // 员工编号
				depart, err := models.GetDepartmentById(user.DepartmentId) // 部门
				if err != nil {
					raw.AddCell().SetValue("")
				} else {
					raw.AddCell().SetValue(depart.DepartmentName)
				}
				raw.AddCell().SetValue(user.EmployeeNature)  // 员工性质
				area, err := models.GetAreaById(user.AreaId) // 地区
				if err != nil {
					raw.AddCell().SetValue("")
				} else {
					raw.AddCell().SetValue(area.AreaName)
				}
				raw.AddCell().SetValue(user.ContractNum)     // 合同编号
				raw.AddCell().SetValue(user.Name)            // 名字
				raw.AddCell().SetValue(user.BusinessStr)     // 业务线
				role, err := models.GetRoleById(user.RoleId) // 岗位
				if err != nil {
					raw.AddCell().SetValue("")
				} else {
					raw.AddCell().SetValue(role.RoleName)
				}
				raw.AddCell().SetValue(user.PostAttributes) // 岗位属性
				raw.AddCell().SetValue(user.Incumbency)     // 职位状态
				raw.AddCell().SetValue(user.RecruitMethod)  // 招聘方式
				raw.AddCell().SetValue(user.Email)          // 企业邮箱
				raw.AddCell().SetValue(user.QQNum)          // QQ号
				raw.AddCell().SetValue(user.PhoneNumber)    // 电话
				raw.AddCell().SetValue(user.ContractNature) // 合同性质
				if user.ContractNature == "合同制" {
					raw.AddCell().SetValue(user.ContractPeriod)
				} else if user.ContractNature == "实习" {
					raw.AddCell().SetValue(user.ProbationPeriod)
				} else {
					raw.AddCell().SetValue("0")
				}
				raw.AddCell().SetValue(user.TimeOfEntry.Format("2006-01-02"))     // 入职时间
				raw.AddCell().SetValue(user.RegularTime.Format("2006-01-02"))     // 转正时间
				raw.AddCell().SetValue(user.PracticeEndTime.Format("2006-01-02")) // 实习结束时间
				raw.AddCell().SetValue(user.ContractEndTime.Format("2006-01-02")) // 合同结束时间
				raw.AddCell().SetValue(user.IDCard)                               // 身份证号
				raw.AddCell().SetValue(user.Birthday.Format("2006-01-02"))        // 生日
				raw.AddCell().SetValue(user.Age)                                  // 年龄
				raw.AddCell().SetValue(user.Sex)                                  // 性别
				raw.AddCell().SetValue(user.Nation)                               // 民族
				raw.AddCell().SetValue(user.NativePlace)                          // 籍贯
				raw.AddCell().SetValue(user.GraduateSchool)                       // 毕业院校
				raw.AddCell().SetValue(user.Major)                                // 专业
				raw.AddCell().SetValue(user.Education)                            // 学历
				raw.AddCell().SetValue(user.GraduateTime.Format("2006-01"))       // 毕业时间
				raw.AddCell().SetValue(user.PoliticalOutlook)                     // 政治面貌
				raw.AddCell().SetValue(user.MaritalStatus)                        // 婚姻状态
				raw.AddCell().SetValue(user.LanguageLevel)                        // 外语等级
				raw.AddCell().SetValue(user.ComputerLevel)                        // 计算机技能等级
				raw.AddCell().SetValue(user.WorkingHours.Format("2006-01"))       // 参加工作时间
				raw.AddCell().SetValue(user.WorkUnit)                             // 入职前工作单位
				raw.AddCell().SetValue(user.BankCardInfo)                         // 银行卡信息
				raw.AddCell().SetValue(user.BankCardNum)                          // 银行卡号
				raw.AddCell().SetValue(user.PostRank)                             // 职级
				raw.AddCell().SetValue(user.InternshipSalary)                     // 实习薪资
				raw.AddCell().SetValue(user.ProbationBasicSalary)                 // 试用期基本薪资
				raw.AddCell().SetValue(user.ProbationAchieveSalary)               // 试用期绩效薪资
				raw.AddCell().SetValue(user.RegularBasicSalary)                   // 转正基本薪资
				raw.AddCell().SetValue(user.RegularAchieveSalary)                 // 转正绩效薪资
				raw.AddCell().SetValue(user.NumOfInsurance)                       // 基本养老保险基数
				raw.AddCell().SetValue(user.NumOfUnempLoymentInsurance)           // 失业保险基数
				raw.AddCell().SetValue(user.NumOfMedicalInsurance)                // 基本医疗保险基数
				raw.AddCell().SetValue(user.AccumulationFundBase)                 // 公积金基准点
				raw.AddCell().SetValue(user.PaymentMonth.Format("2006-01"))       // 社保开始缴纳月份
				raw.AddCell().SetValue(user.TaxSubsidy)                           // 税后补贴
				raw.AddCell().SetValue(user.OtherSubsidies)                       // 其他补贴
				raw.AddCell().SetValue(user.SocialSecurityType)                   // 社保类型
				raw.AddCell().SetValue(user.RegisteredResidence)                  // 户口所在地
				raw.AddCell().SetValue(user.RegisteredType)                       // 户口类型
				raw.AddCell().SetValue(user.BirthAddress)                         // 出生地址
				raw.AddCell().SetValue(user.PresentAddress)                       // 现居地址
				raw.AddCell().SetValue(user.EmergencyContact)                     // 紧急联系人
				raw.AddCell().SetValue(user.Relationship)                         // 紧急联系人关系
				raw.AddCell().SetValue(user.ContactInformation)                   // 紧急联系人电话
				raw.AddCell().SetValue(user.AttendanceNum)                        // 考勤机号
				raw.AddCell().SetValue(user.NatureOfWork)                         // 工作性质
			}
			if len(users) == r-1 {
				break
			}
		}
		if len(userList) == s {
			break
		}
	}
	filePath := "/ERPFile/TEMP/user_infos.xlsx"
	err := xlFile.Save(filePath)
	if err != nil {
		logs.Error(err)
	}
	u.Ctx.Output.Download(filePath, "user_infos.xlsx")
}

//员工管理 ----- end -----

//部门管理 ----- start -----
func (u *UserController) DepartMentAddHtml() {
	u.TplName = "user_info/user_department_add.html"
}

//添加部门
func (u *UserController) DepartMentDoAdd() {
	name := u.GetString("departmentName")
	b, _ := models.Department{}.GetDepartmentByName(name)
	if b {
		res := &uitl.RtMsg{1, "部门已存在！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {

		depart := models.Department{DepartmentName: name}
		_, err := models.AddDepartment(&depart)
		if err != nil {
			fmt.Println("add department faild", err)
			res := &uitl.RtMsg{1, "新增失败！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "新增成功！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}

	}
}

//获取所有通用部门信息
func (u *UserController) DepartMentList() {
	page, err := u.GetInt("page")
	if err != nil {
		return
	}
	limit, err := u.GetInt("limit")
	if err != nil {
		return
	}
	depart := models.Department{}

	pageData := depart.FinadAllByPage(page, limit)
	res := &uitl.RtMsg{0, "提交成功！！", pageData.TotalCount, pageData.Data}
	u.Data["json"] = res
	u.ServeJSON()
	return

}

//进入部门修改界面
func (u *UserController) DepartMentUpdateHtml() {
	id := u.Ctx.Input.Param(":id")
	i, err := strconv.Atoi(id)
	if err != nil {
		return
	}
	department, err := models.GetDepartmentById(i)
	if err != nil {
		logs.Error(err)
		return
	}
	u.Data["depart"] = department
	u.TplName = "user_info/user_department_update.html"
}

//修改部门
func (u *UserController) DepartMentDoUpdate() {
	id, _ := u.GetInt("departmentId")
	name := u.GetString("departmentName")
	b, _ := models.Department{}.GetDepartmentByName(name)
	if b {
		res := &uitl.RtMsg{1, "部门已存在！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {

		depart := models.Department{DepartmentId: id, DepartmentName: name}
		err := models.UpdateDepartmentById(&depart)
		if err != nil {
			fmt.Println("update department faild", err)
			res := &uitl.RtMsg{1, "修改失败！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "修改成功！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}

	}
}

//进入设置页面
func (u *UserController) DepartMentSetHtml() {
	id := u.Ctx.Input.Param(":id")
	i, err := strconv.Atoi(id)
	if err != nil {
		return
	}
	department, err := models.GetDepartmentById(i)
	if err != nil {
		fmt.Println(err)
		return
	}
	u.Data["depart"] = department
	company := models.Company{}
	companies := company.GetAll()
	u.Data["companies"] = companies
	u.TplName = "user_info/user_department_set.html"
}

//设置部门
func (u *UserController) DepartMentDoSet() {
	departmenId, _ := u.GetInt("departmentId")
	companyId, _ := u.GetInt("companyId")
	userId, _ := u.GetInt("userId")
	department := models.Department{}
	b := department.AddDepartmentSet(departmenId, companyId, userId)
	if b {
		res := &uitl.RtMsg{0, "设置成功！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "设置失败！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

}

//获取已设置的部门相关信息集合
func (u *UserController) DepartComUserList() {
	page, err := u.GetInt("page")
	if err != nil {
		return
	}
	limit, err := u.GetInt("limit")
	if err != nil {
		return
	}
	d := models.Department{}
	newaPage := d.GetDepartComUserListByPage(page, limit)
	res := &uitl.RtMsg{0, "修改成功！", newaPage.TotalCount, newaPage.Data}
	u.Data["json"] = res
	u.ServeJSON()
	return

}

//根据公司id获取员工信息
func (u *UserController) CompanyUserList() {
	companyId, _ := u.GetInt("companyId")
	user := models.User{}
	users := user.GetUserByCompany(companyId)
	res := &uitl.RtMsg{0, "修改成功！", 0, users}
	u.Data["json"] = res
	u.ServeJSON()
	return
}

//根据公司id和部门id获取员工信息
func (u *UserController) CompanyDepartmentUserList() {
	companyId := u.GetSession("companyId").(int)
	id, _ := u.GetInt("id")

	user := models.User{}
	users := user.GetByComIdAndDepartId(companyId, id)
	res := &uitl.RtMsg{0, "修改成功！", 0, users}
	u.Data["json"] = res
	u.ServeJSON()
	return
}

//删除已设置的某条部门信息
func (u *UserController) DepartComUserDel() {
	departmenId, _ := u.GetInt("departmentId")
	companyId, _ := u.GetInt("companyId")
	userId, _ := u.GetInt("userId")
	depart := models.Department{}
	b := depart.DepartComUserDel(departmenId, companyId, userId)
	if b {
		res := &uitl.RtMsg{0, "删除成功！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "删除失败！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
}

//部门管理 ----- end -----

//年假查询 ------start-----
/*
进入员工年假查询界面
*/
func (u *UserController) AnnualLeaveListHtml() {
	u.TplName = "user_info/user_annual_leave.html"
}

/*
分页查询员工年假数据
*/
func (u *UserController) AnnualLeaveList() {
	companyId := u.GetSession("companyId").(int)
	page, err := u.GetInt("page")
	if err != nil {
		return
	}
	limit, err := u.GetInt("limit")
	if err != nil {
		return
	}
	an := models.AnnualLeave{}
	byPage := an.SelectByCompanyIdByPage(companyId, page, limit)
	res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
	u.Data["json"] = res
	u.ServeJSON()
	return
}

/*
导出年假表格
*/
func (u *UserController) ExportAnnualLeave() {
	companyId := u.GetSession("companyId").(int)
	an := models.AnnualLeave{}
	annualLeaves := an.SelectALLByCompanyId(companyId)
	xlFile := xlsx.NewFile()
	titleList := []string{"ID", "用户ID", "员工编号", "姓名", "剩余年假天数", "已使用年假天数",
		"一月使用年假天数", "二月使用年假天数", "三月使用年假天数",
		"四月使用年假天数", "五月使用年假天数", "六月使用年假天数",
		"七月使用年假天数", "八月使用年假天数", "九月使用年假天数",
		"十月使用年假天数", "十一月使用年假天数", "十二月使用年假天数"}
	xlFile.AddSheet("员工年假信息")
	for _, sheet := range xlFile.Sheets {

		for r := 0; r < len(annualLeaves)+2; r++ {
			fmt.Println(r)
			if r == 0 {
				sheet.AddRow().AddCell().SetValue("员工当年年假信息")
			}
			if r == 1 {
				raw := sheet.AddRow()
				for _, v := range titleList {
					raw.AddCell().SetValue(v)
				}
			}
			if r > 1 {
				var raw *xlsx.Row
				raw = sheet.AddRow()
				per := (annualLeaves)[r-2]
				raw.AddCell().SetValue(per.Id)
				raw.AddCell().SetValue(per.UserId)
				raw.AddCell().SetValue(per.EmployeeNum)
				raw.AddCell().SetValue(per.UserName)
				raw.AddCell().SetValue(per.AnnualLeaveDays)
				raw.AddCell().SetValue(per.UsedAnnualLeaveDays)
				raw.AddCell().SetValue(per.January)
				raw.AddCell().SetValue(per.February)
				raw.AddCell().SetValue(per.March)
				raw.AddCell().SetValue(per.April)
				raw.AddCell().SetValue(per.May)
				raw.AddCell().SetValue(per.June)
				raw.AddCell().SetValue(per.July)
				raw.AddCell().SetValue(per.August)
				raw.AddCell().SetValue(per.September)
				raw.AddCell().SetValue(per.October)
				raw.AddCell().SetValue(per.November)
				raw.AddCell().SetValue(per.December)
			}
			if len(annualLeaves) == r-1 {
				break
			}
		}
	}
	filePath := "/ERPFile/TEMP/员工当年年假信息.xlsx"
	err := xlFile.Save(filePath)
	if err != nil {
		logs.Error(err)
	}
	u.Ctx.Output.Download(filePath, "员工当年年假信息.xlsx")
}

/*
导入年假表格，根据表格修改年假数据
*/
func (u *UserController) ImportAnnualLeave() {
	f, h, err := u.GetFile("excl")
	if err != nil {
		logs.Error("getfile err ", err)
	}
	defer f.Close()
	filePath := beego.AppConfig.String("fileUpPath") + "TEMP/" + h.Filename
	u.SaveToFile("excl", filePath)
	//开始解析excel文件
	xlFile, err := xlsx.OpenFile(filePath)
	if err != nil {
		logs.Error("read excel err ,", err)
		return
	}
	as := make([]models.AnnualLeave, 0)
	for _, sheet := range xlFile.Sheets {
		if sheet.Name == "员工年假信息" {
			for k, row := range sheet.Rows {
				if k > 1 {
					al1 := models.AnnualLeave{}
					//先用身份证查询员工，如果存在丢弃这条信息，没有就开始组装信息，准备入库
					id, _ := row.Cells[0].Int()
					al1.Id = id
					al := al1.SelectById()
					userId, _ := row.Cells[1].Int()
					al.UserId = userId
					al.EmployeeNum = row.Cells[2].String()
					al.UserName = row.Cells[3].String()
					annualDays, _ := row.Cells[4].Float()
					al.AnnualLeaveDays = annualDays
					usedAnnualDays, _ := row.Cells[5].Float()
					al.UsedAnnualLeaveDays = usedAnnualDays
					januart, _ := row.Cells[6].Float()
					al.January = januart
					february, _ := row.Cells[7].Float()
					al.February = february
					march, _ := row.Cells[8].Float()
					al.March = march
					april, _ := row.Cells[9].Float()
					al.April = april
					may, _ := row.Cells[10].Float()
					al.May = may
					june, _ := row.Cells[11].Float()
					al.June = june
					july, _ := row.Cells[12].Float()
					al.July = july
					august, _ := row.Cells[13].Float()
					al.August = august
					sep, _ := row.Cells[14].Float()
					al.September = sep
					oct, _ := row.Cells[15].Float()
					al.October = oct
					nov, _ := row.Cells[16].Float()
					al.November = nov
					dec, _ := row.Cells[17].Float()
					al.December = dec
					as = append(as, *al)
				}

			}

		}
		break
	}
	j := 0
	for _, v := range as {
		b := v.UpdateByUserId()
		if b {
			j++
		}
	}

	if j == len(as) {
		//最后都要删除这个文件

		res := &uitl.RtMsg{0, "导入成功", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "数据未完全成功，请检查", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

}

//年假查询 ------end-----

//员工工资界面
func (u *UserController) PayrollListHtml() {
	companyId := u.GetSession("companyId").(int)
	user := models.User{}
	users := user.GetUserByCompany(companyId)
	u.Data["users"] = users
	u.TplName = "user_info/user_payroll.html"
}

//员工工资数据
func (u *UserController) PayrollList() {
	companyId := u.GetSession("companyId").(int)
	page, err := u.GetInt("page")
	if err != nil {
		return
	}
	limit, err := u.GetInt("limit")
	if err != nil {
		return
	}
	datas := u.GetString("datas")
	maps := make(map[string]string)
	err = json.Unmarshal([]byte(datas), &maps)
	if err != nil {
		fmt.Println("json to map ", err)
	}
	//根据map和公司id查询工资条数据
	payroll := models.Payroll{}
	byPage := payroll.SelectByPage(page, limit, companyId, maps)
	if byPage != nil {
		res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
}

//计算工资
func (u *UserController) CalculatePay() {
	companyId := u.GetSession("companyId").(int)
	paymonth := uitl.StrToMonth(u.GetString("pay_month"))
	att := models.Attendance{}
	attendances := att.SelectAll(companyId, paymonth)
	payRolls := make([]models.Payroll, 0)
	us := models.User{}
	soc := models.SocialSecurityFund{}
	soc.CompanyId = companyId
	fund := soc.Select()
	per := models.Performance{}
	for _, v := range attendances {
		per.UserId = v.UserId
		payroll := models.Payroll{}
		user := us.GetByUserId(v.UserId)
		performance := per.SelectByUserIdAndMonth(paymonth.Format("2006-01-02"))
		payroll.EmployeeNum = user.EmployeeNum
		payroll.CompanyId = companyId
		payroll.UserId = user.Id
		payroll.UserName = user.Name
		payroll.PostRank = user.PostRank
		payroll.Age = user.Age
		payroll.PayMonth = paymonth
		payroll.CompletionRate = performance.CompletionRate
		payroll.ShowAttitude = performance.ShowAttitude
		payroll.Overall = performance.Overall
		payroll.ShowExplain = performance.ShowExplain

		payroll = *caluateAttendance(v, &payroll, *user)
		payroll = *caluateBasic(&payroll, *user, *fund)
		payroll = *caluateActual(&payroll, *user, *fund)

		payRolls = append(payRolls, payroll)
	}
	pr := models.Payroll{}
	payr, _ := pr.SelectByMonth(paymonth, companyId)
	var flag bool
	if len(*payr) > 0 {
		flag = true
	} else {
		flag = false
	}
	b := pr.AddList(payRolls, companyId, paymonth, flag)
	if b {
		res := &uitl.RtMsg{0, "计算完成", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "计算有误！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
}

//计算考勤
func caluateAttendance(attendance models.Attendance, payroll *models.Payroll, user models.User) *models.Payroll {
	if user.NatureOfWork == "实习" {
		var daypay = uitl.Decimal(user.InternshipSalary/21.75, "2")
		var hourpay = uitl.Decimal(user.InternshipSalary/(21.75*8), "2")
		payroll.OvertimePay = uitl.Decimal((attendance.OvertimePeacetime*1.5*hourpay)+(attendance.OvertimeFestival*2*hourpay)+(attendance.OvertimeGeneralHoliday*3*hourpay), "2")
		payroll.SickLeaveCutPayment = uitl.Decimal(daypay*attendance.SickLeave, "2")
		payroll.PersonalLeaveCutPayment = uitl.Decimal(daypay*attendance.PersonalLeave, "2")
		payroll.AbsenteeismCutPayment = uitl.Decimal(daypay*attendance.Absenteeism*2, "2")
		payroll.EntryNotFullCutPayment = uitl.Decimal(daypay*attendance.EntryNotFull, "2")
		payroll.QuitDeductionCutPayment = uitl.Decimal(daypay*attendance.QuitDeduction, "2")
		payroll.LateCutPayment = uitl.Decimal(2*(attendance.Late0To10+attendance.Late10To30+attendance.Late30To60+attendance.Late60To120), "2")
		payroll.AttendanceTotalCutPayment = uitl.Decimal(math.Abs(payroll.Overall-payroll.SickLeaveCutPayment+payroll.PersonalLeaveCutPayment+payroll.AbsenteeismCutPayment+
			payroll.EntryNotFullCutPayment+payroll.QuitDeductionCutPayment+payroll.LackOfCard), "2")
		payroll.LackOfCard = attendance.OvertopLackOfCard
	}
	if user.NatureOfWork == "试用" {
		var daypay = uitl.Decimal((user.ProbationBasicSalary+user.ProbationAchieveSalary)/21.75, "2")
		var hourpay = uitl.Decimal((user.ProbationBasicSalary+user.ProbationAchieveSalary)/(21.75*8), "2")
		var achieveSalaryDayPay = uitl.Decimal((user.ProbationAchieveSalary)/(21.75), "2")
		payroll.OvertimePay = uitl.Decimal((attendance.OvertimePeacetime*1.5*hourpay)+(attendance.OvertimeFestival*2*hourpay)+(attendance.OvertimeGeneralHoliday*3*hourpay), "2")
		payroll.SickLeaveCutPayment = uitl.Decimal(achieveSalaryDayPay*attendance.SickLeave, "2")
		payroll.PersonalLeaveCutPayment = uitl.Decimal(daypay*attendance.PersonalLeave, "2")
		payroll.AbsenteeismCutPayment = uitl.Decimal(daypay*attendance.Absenteeism*2, "2")
		payroll.EntryNotFullCutPayment = uitl.Decimal(daypay*attendance.EntryNotFull, "2")
		payroll.QuitDeductionCutPayment = uitl.Decimal(daypay*attendance.QuitDeduction, "2")
		payroll.LateCutPayment = uitl.Decimal(2*(attendance.Late0To10+attendance.Late10To30+attendance.Late30To60+attendance.Late60To120), "2")
		payroll.AttendanceTotalCutPayment = uitl.Decimal(math.Abs(payroll.OvertimePay-payroll.SickLeaveCutPayment-payroll.PersonalLeaveCutPayment-payroll.AbsenteeismCutPayment-
			payroll.EntryNotFullCutPayment-payroll.QuitDeductionCutPayment+payroll.LateCutPayment), "2")
		payroll.LackOfCard = attendance.OvertopLackOfCard
	}
	if user.NatureOfWork == "转正" {
		var daypay = uitl.Decimal((user.RegularBasicSalary+user.RegularAchieveSalary)/21.75, "2")
		var hourpay = uitl.Decimal((user.RegularBasicSalary+user.RegularAchieveSalary)/(21.75*8), "2")
		var achieveSalaryDayPay = uitl.Decimal((user.RegularAchieveSalary)/(21.75), "2")
		payroll.OvertimePay = uitl.Decimal((attendance.OvertimePeacetime*1.5*hourpay)+(attendance.OvertimeFestival*2*hourpay)+(attendance.OvertimeGeneralHoliday*3*hourpay), "2")
		payroll.SickLeaveCutPayment = uitl.Decimal(achieveSalaryDayPay*attendance.SickLeave, "2")
		payroll.PersonalLeaveCutPayment = uitl.Decimal(daypay*attendance.PersonalLeave, "2")
		payroll.AbsenteeismCutPayment = uitl.Decimal(daypay*attendance.Absenteeism*2, "2")
		payroll.EntryNotFullCutPayment = uitl.Decimal(daypay*attendance.EntryNotFull, "2")
		payroll.QuitDeductionCutPayment = uitl.Decimal(daypay*attendance.QuitDeduction, "2")
		payroll.LateCutPayment = uitl.Decimal(2*(attendance.Late0To10+attendance.Late10To30+attendance.Late30To60+attendance.Late60To120), "2")
		payroll.AttendanceTotalCutPayment = uitl.Decimal(math.Abs(payroll.OvertimePay-payroll.SickLeaveCutPayment-payroll.PersonalLeaveCutPayment-payroll.AbsenteeismCutPayment-
			payroll.EntryNotFullCutPayment-payroll.QuitDeductionCutPayment+payroll.LateCutPayment), "2")
		payroll.LackOfCard = attendance.OvertopLackOfCard
	}

	return payroll
}

//填入基本工资和计算绩效，五险一金
func caluateBasic(payroll *models.Payroll, user models.User, fund models.SocialSecurityFund) *models.Payroll {
	if user.NatureOfWork == "实习" {
		payroll.BasicSalary = 0
		payroll.AchieveSalary = 0
		payroll.UnempLoymentInsurance = 0
		payroll.NumOfMedicalInsurance = 0
		payroll.AccumulationFund = 0
	}
	if user.NatureOfWork == "试用" {
		payroll.BasicSalary = user.ProbationBasicSalary
		payroll.AchieveSalary = uitl.Decimal(user.ProbationAchieveSalary*payroll.Overall, "2")
		payroll.Insurance = uitl.Decimal(user.NumOfInsurance*fund.PercentageOfInsurance, "2")
		payroll.UnempLoymentInsurance = uitl.Decimal(user.NumOfUnempLoymentInsurance*fund.PercentageOfUnempLoymentInsurance, "2")
		payroll.NumOfMedicalInsurance = uitl.Decimal(user.NumOfMedicalInsurance*fund.PercentageOfMedicalInsurance, "2")
		payroll.AccumulationFund = uitl.Decimal(user.AccumulationFundBase*fund.PercentageOfFunc, "2")
	}
	if user.NatureOfWork == "转正" {
		payroll.BasicSalary = user.RegularBasicSalary
		payroll.AchieveSalary = uitl.Decimal(user.RegularAchieveSalary*payroll.Overall, "2")
		payroll.Insurance = uitl.Decimal(user.NumOfInsurance*fund.PercentageOfInsurance, "2")
		payroll.UnempLoymentInsurance = uitl.Decimal(user.NumOfUnempLoymentInsurance*fund.PercentageOfUnempLoymentInsurance, "2")
		payroll.NumOfMedicalInsurance = uitl.Decimal(user.NumOfMedicalInsurance*fund.PercentageOfMedicalInsurance, "2")
		payroll.AccumulationFund = uitl.Decimal(user.AccumulationFundBase*fund.PercentageOfFunc, "2")
	}

	return payroll
}

//税后及实得工资计算
func caluateActual(payroll *models.Payroll, user models.User, fund models.SocialSecurityFund) *models.Payroll {
	if user.NatureOfWork == "实习" {
		payroll.AfterTaxSubsidy = user.InternshipSalary
		var beforeTaxTotal = uitl.Decimal(payroll.AfterTaxSubsidy+payroll.OtherSubsidy-payroll.AttendanceTotalCutPayment-payroll.Insurance-payroll.UnempLoymentInsurance-
			payroll.NumOfMedicalInsurance-payroll.AccumulationFund-payroll.PersonalOtherInsurance, "2")
		//var dValue=uitl.Decimal(beforeTaxTotal-fund.ExemptionAmount,"2")
		//var afterTaxTotal float64
		//if dValue<=1500{
		//
		//}else if dValue>1500 && dValue<=4500{
		//	afterTaxTotal=uitl.Decimal(beforeTaxTotal*0.03-0,"2")
		//}else if dValue>1500 && dValue<=4500{
		//	afterTaxTotal=uitl.Decimal(beforeTaxTotal*0.1-105,"2")
		//}else if dValue>4500 && dValue<=9000{
		//	afterTaxTotal=uitl.Decimal(beforeTaxTotal*0.2-555,"2")
		//}else if dValue>9000 && dValue<=35000{
		//	afterTaxTotal=uitl.Decimal(beforeTaxTotal*0.25-1005,"2")
		//}else if dValue>35000 && dValue<=55000 {
		//	afterTaxTotal=uitl.Decimal(beforeTaxTotal*0.30-2755,"2")
		//}else if dValue>55000 && dValue<=80000 {
		//	afterTaxTotal=uitl.Decimal(beforeTaxTotal*0.35-5505,"2")
		//}else {
		//	afterTaxTotal=uitl.Decimal(beforeTaxTotal*0.45-13505,"2")
		//}
		//payroll.PersonalIncomeTax=uitl.Decimal(beforeTaxTotal-afterTaxTotal,"2")
		payroll.FinalPay = uitl.Decimal(payroll.ComputerSubsidy+payroll.FullAttendance+beforeTaxTotal, "2")

	}
	if user.NatureOfWork == "试用" {
		var beforeTaxTotal = uitl.Decimal(payroll.BasicSalary+payroll.AchieveSalary+payroll.QuarterlyBonus-payroll.AttendanceTotalCutPayment-payroll.Insurance-payroll.UnempLoymentInsurance-
			payroll.NumOfMedicalInsurance-payroll.AccumulationFund-payroll.PersonalOtherInsurance+payroll.OtherSubsidy, "2")

		if beforeTaxTotal > 3500 {
			var afterTaxTotal float64
			var dValue = uitl.Decimal(beforeTaxTotal-fund.ExemptionAmount, "2")
			if dValue <= 1500 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.03-0), "2")
			} else if dValue > 1500 && dValue <= 4500 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.1-105), "2")
			} else if dValue > 4500 && dValue <= 9000 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.2-555), "2")
			} else if dValue > 9000 && dValue <= 35000 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.25-1005), "2")
			} else if dValue > 35000 && dValue <= 55000 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.30-2755), "2")
			} else if dValue > 55000 && dValue <= 80000 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.35-5505), "2")
			} else {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.45-13505), "2")
			}
			payroll.PersonalIncomeTax = uitl.Decimal(beforeTaxTotal-afterTaxTotal, "2")
			payroll.FinalPay = uitl.Decimal(afterTaxTotal+payroll.ComputerSubsidy+payroll.FullAttendance+payroll.AfterTaxSubsidy, "2")
		} else {
			payroll.PersonalIncomeTax = 0
			payroll.FinalPay = uitl.Decimal(beforeTaxTotal+payroll.ComputerSubsidy+payroll.FullAttendance+payroll.AfterTaxSubsidy, "2")
		}
	}
	if user.NatureOfWork == "转正" {
		var beforeTaxTotal = uitl.Decimal(payroll.BasicSalary+payroll.AchieveSalary+payroll.QuarterlyBonus-payroll.AttendanceTotalCutPayment-payroll.Insurance-payroll.UnempLoymentInsurance-
			payroll.NumOfMedicalInsurance-payroll.AccumulationFund-payroll.PersonalOtherInsurance+payroll.OtherSubsidy, "2")

		if beforeTaxTotal > 3500 {
			var afterTaxTotal float64
			var dValue = uitl.Decimal(beforeTaxTotal-fund.ExemptionAmount, "2")
			if dValue <= 1500 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.03-0), "2")
			} else if dValue > 1500 && dValue <= 4500 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.1-105), "2")
			} else if dValue > 4500 && dValue <= 9000 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.2-555), "2")
			} else if dValue > 9000 && dValue <= 35000 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.25-1005), "2")
			} else if dValue > 35000 && dValue <= 55000 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.30-2755), "2")
			} else if dValue > 55000 && dValue <= 80000 {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.35-5505), "2")
			} else {
				afterTaxTotal = uitl.Decimal(beforeTaxTotal-(dValue*0.45-13505), "2")
			}
			payroll.PersonalIncomeTax = uitl.Decimal(beforeTaxTotal-afterTaxTotal, "2")
			payroll.FinalPay = uitl.Decimal(afterTaxTotal+payroll.ComputerSubsidy+payroll.FullAttendance+payroll.AfterTaxSubsidy, "2")
		} else {
			payroll.PersonalIncomeTax = 0
			payroll.FinalPay = uitl.Decimal(beforeTaxTotal+payroll.ComputerSubsidy+payroll.FullAttendance+payroll.AfterTaxSubsidy, "2")
		}

	}

	return payroll
}

//设置奖金及其它数据-页面
func (u *UserController) SetPayRollOtherHtml() {
	i := u.Ctx.Input.Param(":id")
	id, err := strconv.Atoi(i)
	if err != nil {
		return
	}
	payroll := models.Payroll{}
	payroll = *payroll.SelectById(id)
	u.Data["id"] = id
	u.Data["pay"] = payroll
	u.TplName = "user_info/user_set_payroll.html"
}

//设置奖金及其它数据
func (u *UserController) SetPayRollOther() {

	payroll := models.Payroll{}
	err := u.ParseForm(&payroll)
	if err != nil {
		fmt.Println("notice formData err", err)
	}
	b := payroll.UpdateById()
	if !b {
		res := &uitl.RtMsg{1, "系统异常！！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

	companyId := u.GetSession("companyId").(int)

	us := models.User{}
	payroll.SelectById(payroll.Id)
	user := us.GetByUserId(payroll.UserId)
	soc := models.SocialSecurityFund{}
	soc.CompanyId = companyId
	fund := soc.Select()
	caluateActual(&payroll, *user, *fund)

	b = payroll.Upate()
	if b {
		res := &uitl.RtMsg{0, "设置完成", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
}
