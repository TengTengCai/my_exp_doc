package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"os"
	"strconv"
	"strings"
	"time"
)

type NoiceController struct {
	beego.Controller
}

/*
录入通知页面
*/
func (c *NoiceController) NoticeAddHtml() {
	c.TplName = "notice/notice_add.html"
}

/*
录入通知
*/
func (c *NoiceController) NoticeDoAdd() {
	companyId := c.GetSession("companyId").(int)
	fileName := c.GetString("filename")
	notice := models.Notice{}
	err := c.ParseForm(&notice)
	if err != nil {
		logs.Error("notice formData err", err)
	}
	if fileName != "" {
		var fileUrl string = "" // 文件路径
		if len(fileName) > 0 {
			if !uitl.MoveFileFromTemp(fileName, uitl.NOTICE) {
				res := &uitl.RtMsg{1, "添加失败,服务器文件未找到!", 0, nil} // 返回的对应的相应数据
				c.Data["json"] = res
				c.ServeJSON()
				return
			}
			fileUrl = "/file/" + uitl.NOTICE + fileName
		}
		fileNameSlice1 := strings.Split(fileName, "_")
		fileNameSlice2 := strings.Split(fileName, ".")

		notice.FileUrl = fileUrl
		notice.FileName = fileNameSlice1[0] + "." + fileNameSlice2[1]

	}

	notice.CompanyId = companyId
	notice.CeoExamineStatus = 0
	notice.CreateTime = time.Now()
	b := notice.Add()
	if b {
		res := &uitl.RtMsg{0, "添加成功！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
所有通知数据
*/
func (c *NoiceController) NoticeList() {
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	companyId := c.GetSession("companyId").(int)
	notice := models.Notice{}
	selectAll := notice.SelectAll(companyId, page, limit)
	res := &uitl.RtMsg{0, "", selectAll.TotalCount, selectAll.Data}
	fmt.Println(selectAll.Data)
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
审核通知页面
*/

func (c *NoiceController) NoticeExamineHtml() {
	c.TplName = "notice/notice_examine.html"
}

/*
查询待审核的通知，按时间排序，最新的最前
*/
func (c *NoiceController) NoticeExamineList() {
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	companyId := c.GetSession("companyId").(int)
	notice := models.Notice{}
	selectAll := notice.SelectExamineAll(companyId, page, limit)
	res := &uitl.RtMsg{0, "", selectAll.TotalCount, selectAll.Data}
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
审核通知，修改ceo审核状态
*/
func (c *NoiceController) NoticeDoExamine() {
	companyId := c.GetSession("companyId").(int)
	noticeId, _ := c.GetInt("Id")
	authitStatus, _ := c.GetInt("AuditStatus")

	notice := models.Notice{}
	notice.NoticeId = noticeId
	notice.CeoExamineStatus = authitStatus

	if authitStatus == 2 {
		remark := c.GetString("Remarks")
		if remark != "" {
			notice.Remark = remark
		}
	}
	b, status := notice.UpdateExamineStatus()
	if b {
		if status == 1 {
			not := notice.SelectById()
			user := models.User{}
			selectNotOfficialUsers := user.SelectNotOfficialUsers()
			emails := make([]string, 0)
			us := make([]models.User, 0)

			for _, v := range selectNotOfficialUsers {
				if v.CompanyId == companyId {
					us = append(us, v)
				}
			}
			for _, v := range us {
				emails = append(emails, v.Email)
			}
			go uitl.SendEmail(emails, "新通知提醒！", "dear all:<br> 公司在ERP发布了最新的《"+not.Title+"》，请大家及时前往查阅！")
		}
		res := &uitl.RtMsg{0, "已审核", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
通知修改页面
*/

func (c *NoiceController) NoticeUpdateHtml() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		logs.Error(err)
	}
	notice := models.Notice{}
	notice.NoticeId = id
	not := notice.SelectById()
	c.Data["notice"] = not
	c.TplName = "notice/notice_update.html"
}

/*
通知修改操作，修改后需在审核
*/

func (c *NoiceController) NoticeDoUpdate() {
	fileName := c.GetString("filename")
	notice := models.Notice{}
	err := c.ParseForm(&notice)
	if err != nil {
		logs.Error("notice formData err", err)
	}
	not := notice.SelectById()
	if fileName != "" {
		var fileUrl string = "" // 文件路径
		if len(fileName) > 0 {
			if !uitl.MoveFileFromTemp(fileName, uitl.NOTICE) {
				res := &uitl.RtMsg{1, "添加失败,服务器文件未找到!", 0, nil} // 返回的对应的相应数据
				c.Data["json"] = res
				c.ServeJSON()
				return
			}
			fileUrl = "/file/" + uitl.NOTICE + fileName
		}
		fileNameSlice1 := strings.Split(fileName, "_")
		fileNameSlice2 := strings.Split(fileName, ".")

		notice.FileUrl = fileUrl
		notice.FileName = fileNameSlice1[0] + "." + fileNameSlice2[1]

	} else {
		notice.FileUrl = not.FileUrl
		notice.FileName = not.FileName
	}
	notice.CeoExamineStatus = 0
	notice.UpdateTime = time.Now()
	notice.Remark = "修改"

	b := notice.Update()
	if b {
		if fileName != "" && not.FileName != "" {
			oldFilePath := beego.AppConfig.String("fileUpPath") + not.FileUrl[len("/file/"):]
			err := os.Remove(oldFilePath)
			if err != nil {
				logs.Error("del file err,", err)
			}
		}

		res := &uitl.RtMsg{0, "修改成功！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
通知删除操作
*/

func (c *NoiceController) NoticeDoDel() {
	id, err := c.GetInt("Id")
	if err != nil {
		logs.Error("get id err,", err)
		return
	}
	notice := models.Notice{}
	notice.NoticeId = id
	not := notice.SelectById()
	b := notice.Delete()
	if b {
		if not.FileName != "" {
			oldFilePath := beego.AppConfig.String("fileUpPath") + not.FileUrl[len("/file/"):]
			err := os.Remove(oldFilePath)
			if err != nil {
				logs.Error("del file err,", err)
			}
		}

		res := &uitl.RtMsg{0, "已删除！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "系统异常！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
删除附件操作
*/

func (c *NoiceController) NoticeDoDelFile() {
	id, err := c.GetInt("Id")
	if err != nil {
		logs.Error("get id err,", err)
		return
	}
	notice := models.Notice{}
	notice.NoticeId = id
	not := notice.SelectById()

	if not.FileName != "" {
		oldFilePath := beego.AppConfig.String("fileUpPath") + not.FileUrl[len("/file/"):]
		err := os.Remove(oldFilePath)
		if err != nil {
			logs.Error("del file err,", err)
			res := &uitl.RtMsg{1, "系统异常！！", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		} else {
			not.FileName = ""
			not.FileUrl = ""
			not.UpdateTime = time.Now()
			not.CeoExamineStatus = 0
			not.Remark = "删除附件"
			b := not.Update()
			if b {
				res := &uitl.RtMsg{0, "已删除！！", 0, nil}
				c.Data["json"] = res
				c.ServeJSON()
				return
			} else {
				res := &uitl.RtMsg{1, "系统异常！！", 0, nil}
				c.Data["json"] = res
				c.ServeJSON()
				return
			}

		}
	} else {
		res := &uitl.RtMsg{1, "系统异常！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}
