package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"github.com/tealeg/xlsx"
	"strconv"
	"time"
)

type AttendanceController struct {
	beego.Controller
}

/*
进入年假记录查询页面
*/
func (c *AttendanceController) AnnualHtml() {
	c.TplName = "attendance/attendance_annual.html"
}

/*
进入年假记录查询页面
*/
func (c *AttendanceController) AnnualList() {
	companyId := c.GetSession("companyId").(int)
	page, err := c.GetInt("page")
	if err != nil {
		logs.Error(err)
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		logs.Error(err)
		return
	}
	an := models.AnnualLeave{}
	byPage := an.SelectByCompanyIdByPage(companyId, page, limit)
	if byPage != nil {
		res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
导出当前公司年假记录
*/
func (c *AttendanceController) AnnualLeaveExportExcel() {
	companyId := c.GetSession("companyId").(int)
	an := models.AnnualLeave{}
	annualLeaves := an.SelectALLByCompanyId(companyId)
	xlFile := xlsx.NewFile()
	titleList := []string{"员工编号", "姓名", "是否转正", "转正时间", "工龄年假天数", "当年年假剩余天数", "当年已使用年假天数"}
	xlFile.AddSheet("员工年假信息")
	for _, sheet := range xlFile.Sheets {

		for r := 0; r < len(annualLeaves)+2; r++ {
			fmt.Println(r)
			if r == 0 {
				sheet.AddRow().AddCell().SetValue("员工年假记录")
			}
			if r == 1 {
				raw := sheet.AddRow()
				for _, v := range titleList {
					raw.AddCell().SetValue(v)
				}
			}
			if r > 1 {
				var raw *xlsx.Row
				raw = sheet.AddRow()
				per := (annualLeaves)[r-2]
				raw.AddCell().SetValue(per.EmployeeNum)
				raw.AddCell().SetValue(per.UserName)
				raw.AddCell().SetValue("是")
				raw.AddCell().SetValue(per.RegularTime.Format("2006-01-02"))
				raw.AddCell().SetValue(per.HaveAnnualLeaveDays)
				raw.AddCell().SetValue(per.AnnualLeaveDays)
				raw.AddCell().SetValue(per.UsedAnnualLeaveDays)
			}
			if len(annualLeaves) == r-1 {
				break
			}
		}
	}
	filePath := "/ERPFile/TEMP/员工年假记录表.xlsx"
	err := xlFile.Save(filePath)
	if err != nil {
		logs.Error(err)
	}
	c.Ctx.Output.Download(filePath, "员工年假记录表.xlsx")
}

/*
进入考勤上传文件界面
*/
func (c *AttendanceController) AttendanceFileUploadHtml() {
	c.TplName = "attendance/attendance_file_upload.html"
}

/*
导入考勤记录，入库
*/
func (c *AttendanceController) AttendanceFileUpload() {
	companyId := c.GetSession("companyId").(int)
	month := c.GetString("month")
	monthTime := uitl.StrToMonth(month)
	fmt.Println(month)
	f, h, err := c.GetFile("excl")
	if err != nil {
		logs.Error("getfile err ", err)
	}
	defer f.Close()
	filePath := beego.AppConfig.String("fileUpPath") + "TEMP/" + h.Filename
	c.SaveToFile("excl", filePath)
	//开始解析excel文件
	xlFile, err := xlsx.OpenFile(filePath)
	if err != nil {
		logs.Error("read excel err ,", err)
		return
	}
	attendances := make([]models.Attendance, 0)
	for _, sheet := range xlFile.Sheets {
		if sheet.Name == "考勤汇总表" {
			for k, row := range sheet.Rows {
				if k > 2 {
					if month != row.Cells[4].String() {
						res := &uitl.RtMsg{1, "所属月份和选择月份不一致", 0, nil}
						c.Data["json"] = res
						c.ServeJSON()
						return
					}
					//读取每行数据存入对象预备入库，如果已存在这个月份的数据，先删除，在入库
					attendance := models.Attendance{}
					area := models.Area{}
					_, ar := area.GetAreaByName(row.Cells[1].String())
					attendance.AreaId = ar.AreaId
					attendance.AreaName = ar.AreaName
					attendance.CompanyId = companyId
					user := models.User{}
					user.Name = row.Cells[2].String()
					user.EmployeeNum = row.Cells[3].String()
					user.CompanyId = companyId
					user = *user.SelectByNameEmCom()
					if user.DepartmentId != 0 {
						attendance.UserId = user.Id
						attendance.UserName = user.Name
						attendance.EmployeeNum = user.EmployeeNum
					} else {
						res := &uitl.RtMsg{1, "人员信息有误请核对！", 0, nil}
						c.Data["json"] = res
						c.ServeJSON()
						return
					}
					dep := models.Department{}
					b, department := dep.GetDepartmentByName(row.Cells[5].String())
					if b {
						attendance.DepartmentId = department.DepartmentId
						attendance.DepartmentName = department.DepartmentName
					} else {
						res := &uitl.RtMsg{1, "人员信息有误请核对！", 0, nil}
						c.Data["json"] = res
						c.ServeJSON()
						return
					}
					attendance.Month = monthTime
					fullAttendanceDays, _ := row.Cells[6].Float()
					attendance.FullAttendanceDays = fullAttendanceDays

					attendanceDays, _ := row.Cells[7].Float()
					attendance.AttendanceDays = attendanceDays

					businessTravel, _ := row.Cells[8].Float()
					attendance.BusinessTravel = businessTravel

					annualLeave, _ := row.Cells[9].Float()
					attendance.AnnualLeave = annualLeave

					personalLeave, _ := row.Cells[10].Float()
					attendance.PersonalLeave = personalLeave

					sickLeave, _ := row.Cells[11].Float()
					attendance.SickLeave = sickLeave

					absenteeism, _ := row.Cells[12].Float()
					attendance.Absenteeism = absenteeism

					takeWorkingDaysOff, _ := row.Cells[13].Float()
					attendance.TakeWorkingDaysOff = takeWorkingDaysOff

					maritalLeave, _ := row.Cells[14].Float()
					attendance.MaritalLeave = maritalLeave

					funeralLeave, _ := row.Cells[15].Float()
					attendance.FuneralLeave = funeralLeave

					breastfeedingLeave, _ := row.Cells[16].Float()
					attendance.BreastfeedingLeave = breastfeedingLeave

					maternityLeave, _ := row.Cells[17].Float()
					attendance.MaternityLeave = maternityLeave

					prenatalLeave, _ := row.Cells[18].Float()
					attendance.PrenatalLeave = prenatalLeave

					paternityLeave, _ := row.Cells[19].Float()
					attendance.PaternityLeave = paternityLeave

					entryNotFull, _ := row.Cells[20].Float()
					attendance.EntryNotFull = entryNotFull

					quitDeduction, _ := row.Cells[21].Float()
					attendance.QuitDeduction = quitDeduction

					late0To10, _ := row.Cells[22].Float()
					attendance.Late0To10 = late0To10

					late10To30, _ := row.Cells[23].Float()
					attendance.Late10To30 = late10To30

					late30To60, _ := row.Cells[24].Float()
					attendance.Late30To60 = late30To60

					late60To120, _ := row.Cells[25].Float()
					attendance.Late60To120 = late60To120

					early0To10, _ := row.Cells[26].Float()
					attendance.Early0To10 = early0To10

					early10To30, _ := row.Cells[27].Float()
					attendance.Early10To30 = early10To30

					early30To60, _ := row.Cells[28].Float()
					attendance.Early30To60 = early30To60

					early60To120, _ := row.Cells[29].Float()
					attendance.Early60To120 = early60To120

					overtopLackOfCard, _ := row.Cells[30].Float()
					attendance.OvertopLackOfCard = overtopLackOfCard

					overtimePeacetime, _ := row.Cells[31].Float()
					attendance.OvertimePeacetime = overtimePeacetime

					overtimeGeneralHoliday, _ := row.Cells[32].Float()
					attendance.OvertimeGeneralHoliday = overtimeGeneralHoliday

					overtimeFestival, _ := row.Cells[33].Float()
					attendance.OvertimeFestival = overtimeFestival

					attendances = append(attendances, attendance)
				}

			}

		}
		break
	}

	att := models.Attendance{}
	atts, _ := att.SelectByMonth(monthTime, companyId)
	var flag bool
	if len(*atts) > 0 {
		flag = true
	} else {
		flag = false
	}
	b := att.AddList(attendances, monthTime, flag, companyId)
	if b {
		res := &uitl.RtMsg{0, "导入成功", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "人员信息有误请核对！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
进入考勤查询页面
*/
func (c *AttendanceController) AttendanceListHtml() {
	c.TplName = "attendance/attendance_list.html"
}

/*
考勤查询数据
*/
func (c *AttendanceController) AttendanceList() {
	companyId := c.GetSession("companyId").(int)
	month := c.GetString("month")
	fmt.Println("month=====", month)
	var monthTime time.Time
	if month == "" {
		monthTime = uitl.StrToMonth(time.Now().Format("2006-01"))
	} else {
		monthTime = uitl.StrToMonth(month)

	}

	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	att := models.Attendance{}
	byPage := att.SelectByPage(companyId, page, limit, monthTime)
	if byPage != nil {
		res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
补卡申请页面
*/
func (c *AttendanceController) SupplementApplyHtml() {
	user := c.GetSession("CPXERP").(models.User)
	c.Data["user"] = user
	c.TplName = "attendance/supplement_apply.html"
	return
}

/*
补卡审核页面
*/
func (c *AttendanceController) SupplementVerifyHtml() {
	c.TplName = "attendance/supplement_verify.html"
	return
}

/*
补卡记录查看页面
*/
func (c *AttendanceController) SupplementListHtml() {
	c.TplName = "attendance/supplement_list.html"
	return
}

/*
补卡申请添加行为
*/
func (c *AttendanceController) SupplementApplyDoAdd() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	supDateStr := c.GetString("SupDate")
	slotTime := c.GetString("SlotTime")
	reason := c.GetString("Reason")
	supDate, err := time.ParseInLocation("2006-01-02", supDateStr, time.Local)
	supplement := models.Supplement{}
	supplement.Applier = user.Id
	supplement.CompanyId = companyId
	supplement.SupDate = supDate
	supplement.Reason = reason
	supplement.SlotTime = slotTime
	_, err = models.AddSupplement(&supplement)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "添加补卡申请成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
补卡个人记录查询
*/
func (c *AttendanceController) SupplementSelectByUser() {
	user := c.GetSession("CPXERP").(models.User)
	filter := map[string]interface{}{}
	filter["applier"] = user.Id
	filter["company_id"] = user.CompanyId
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	data, err := models.SelectSupplementByFilter(filter, page, limit, orm.NewOrm())
	count, err := models.GetSupplementCountByFilter(filter, orm.NewOrm())
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "数据获取成功成功！", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
个人补卡记录查询
*/
func (c *AttendanceController) SupplementSelectVerify() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	if !(myModule["persionnel1_examine"] || myModule["persionnel2_examine"]) {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	filter := map[string]interface{}{}
	filter["person_status"] = 0
	filter["company_id"] = companyId
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	o := orm.NewOrm()
	data, err := models.SelectSupplementByFilter(filter, page, limit, o)
	count, err := models.GetSupplementCountByFilter(filter, o)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "数据获取成功！", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
补卡审核行为
*/
func (c *AttendanceController) SupplementDoVerify() {
	user := c.GetSession("CPXERP").(models.User)
	suppleId, err := c.GetInt(":id")
	action, err := c.GetInt("action", 1)
	if err != nil {
		logs.Error(err)
		c.Abort("302")
	}
	supple, err := models.GetSupplementById(suppleId)
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	if !(myModule["persionnel1_examine"] || myModule["persionnel2_examine"]) {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	supple.PersonStatus = int8(action)
	supple.Auditor = user.Id
	msg := "通过"
	if action == 2 {
		reason := c.GetString("reason")
		supple.RefuseReason = reason
		msg = "不通过"
	}
	err = models.UpdateSupplementById(supple)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "审核" + msg + "成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
补卡审核通过的记录
*/
func (c *AttendanceController) SupplementSelectHadPass() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	date := c.GetString("Date")

	if len(date) <= 0 {
		year := strconv.FormatInt(int64(time.Now().Year()), 10)
		mouth := strconv.FormatInt(int64(time.Now().Month()-1), 10)
		date = year + "-" + mouth
	}
	tDate, _ := time.ParseInLocation("2006-01-02", date+"-01", time.Local)
	year := strconv.FormatInt(int64(tDate.Year()), 10)
	sMouth := strconv.FormatInt(int64(tDate.Month()), 10)
	eMouth := strconv.FormatInt(int64(tDate.Month())+1, 10)
	beginDate := year + "-" + sMouth + "-01 00:00:00"
	endDate := year + "-" + eMouth + "-01 00:00:00"

	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	if !(myModule["persionnel1_examine"] || myModule["persionnel2_examine"]) {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

	filter := map[string]interface{}{}
	filter["person_status"] = 1
	filter["company_id"] = companyId
	filter["sup_date__le"] = endDate
	filter["sup_date__ge"] = beginDate

	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}

	o := orm.NewOrm()
	data, err := models.SelectSupplementByFilter(filter, page, limit, o)
	count, err := models.GetSupplementCountByFilter(filter, o)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "数据获取成功！", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}
