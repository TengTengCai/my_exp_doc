/*
加班申请模块
auth:ttc
date:2018-09-12
 */
package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"github.com/tealeg/xlsx"
	"strconv"
	"time"
)

// WorkOvertimeController operations for WorkOvertime
type WorkOvertimeController struct {
	beego.Controller
}

/*
加班申请页面
 */
func (c *WorkOvertimeController) WorkOvertimeApplyHtml() {
	user := c.GetSession("CPXERP").(models.User)
	depart := models.SelectAllDepartment()
	c.Data["user"] = user
	c.Data["depart"] = depart
	c.TplName = "work_overtime/work_overtime_apply.html"
}

/*
加班记录备案页面
 */
func (c *WorkOvertimeController) WorkOvertimeListHtml() {
	depart := models.SelectAllDepartment()
	c.Data["depart"] = depart
	c.TplName = "work_overtime/work_overtime_list.html"
}

/*
加班申请审核页面
 */
func (c *WorkOvertimeController) WorkOvertimeVerifyHtml() {
	c.TplName = "work_overtime/work_overtime_verify.html"
}

/*
加班申请添加行为
 */
func (c *WorkOvertimeController) WorkOvertimeDoAdd() {
	user := c.GetSession("CPXERP").(models.User)
	startTime := c.GetString("StartTime", "")
	endTime := c.GetString("EndTime", "")
	reason := c.GetString("Reason", "")
	workType := c.GetString("WorkType", "")
	sTime, _ := time.ParseInLocation("2006-01-02 15:04:05", startTime, time.Local)
	eTime, _ := time.ParseInLocation("2006-01-02 15:04:05", endTime, time.Local)

	subH := eTime.Sub(sTime)
	work := models.WorkOvertime{}

	work.Applier = user.Id
	work.Leader = user.Superior
	work.Depart = user.DepartmentId
	work.WorkType = workType
	work.StartTime = sTime
	work.EndTime = eTime
	work.TotalTime = subH.Hours()
	work.Reason = reason
	work.CompanyId = user.CompanyId

	_, err := models.AddWorkOvertime(&work)
	if err != nil {
		res := &uitl.RtMsg{1, "添加失败，数据库操作失败！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "添加成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
通过申请人查找对应的记录
 */
func (c *WorkOvertimeController) WorkOvertimeSelectByUser() {
	o := orm.NewOrm()
	o.Begin()
	user := c.GetSession("CPXERP").(models.User)
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	filter := map[string]interface{}{}
	filter["company_id"] = user.CompanyId
	filter["applier"] = user.Id

	datas, err := models.SelectWorkOvertimeByFilter(filter, page, limit, o)
	count, err := models.GetWorkOvertimeCountByFilter(filter, o)
	o.Commit()
	if err != nil {
		res := &uitl.RtMsg{1, "添加失败，数据库操作失败！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "获取数据成功！", count, datas} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
加班申请待审核查询
 */
func (c *WorkOvertimeController) WorkOvertimeSelectVerify() {
	o := orm.NewOrm()
	o.Begin()
	user := c.GetSession("CPXERP").(models.User)
	role, _ := models.GetRoleById(user.RoleId)
	_, myModule := role.GetModuleMaps(user.RoleId)
	companyId := c.GetSession("companyId")
	if !(myModule["deppart_examine"] || myModule["ceo_examine"] || myModule["coo_examine"] || myModule["superior_examine"] || myModule["persionnel2_examine"]) {
		res := &uitl.RtMsg{1, "权限不足!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	filter := map[string]interface{}{}
	filter["company_id"] = companyId
	filter["leader"] = user.Id
	filter["depart_status"] = 0
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	datas, err := models.SelectWorkOvertimeByFilter(filter, page, limit, o)
	count, err := models.GetWorkOvertimeCountByFilter(filter, o)
	if err != nil {
		res := &uitl.RtMsg{1, "数据获取失败!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	o.Commit()
	res := &uitl.RtMsg{0, "数据获取成功!", count, datas} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return

}

/*
加班申请审核行为
 */
func (c *WorkOvertimeController) WorkOvertimeDoVerify() {
	workId, err := c.GetInt(":id")
	workOvertime, err := models.GetWorkOvertimeById(workId)
	if err != nil {
		c.Abort("404")
	}
	action, err := c.GetInt("action")
	workOvertime.DepartStatus = int8(action)
	if action == 2 {
		reason := c.GetString("reason")
		workOvertime.Reason = reason
	}
	err = models.UpdateWorkOvertimeById(workOvertime)
	if err != nil {
		res := &uitl.RtMsg{1, "审核操作失败！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "审核成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
加班申请通过备案查询
 */
func (c *WorkOvertimeController) WorkOvertimeSelectHadPass() {
	o := orm.NewOrm()
	o.Begin()
	companyId := c.GetSession("companyId")
	departId, err := c.GetInt("DepartId", 0)
	applier, err := c.GetInt("Applier", 0)
	workType := c.GetString("WorkType")
	date := c.GetString("Date")
	if err != nil {
		c.Abort("304")
	}

	filter := map[string]interface{}{}
	if len(date) > 0 {
		tDate, _ := time.ParseInLocation("2006-01-02", date+"-01", time.Local)
		fmt.Println(tDate.Year())
		year := strconv.FormatInt(int64(tDate.Year()), 10)
		sMouth := strconv.FormatInt(int64(tDate.Month()), 10)
		eMouth := strconv.FormatInt(int64(tDate.Month()) + 1, 10)
		beginDate := year + "-" + sMouth + "-01 00:00:00"
		endDate := year + "-" + eMouth + "-01 00:00:00"
		filter["start_time__gt"] = beginDate
		filter["end_time__lt"] = endDate
	}

	if departId > 0 {
		filter["depart"] = departId
	}

	if applier > 0 {
		filter["applier"] = applier
	}

	if len(workType) > 0 {
		filter["work_type"] = workType
	}

	filter["company_id"] = companyId
	filter["depart_status"] = 1

	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	data, err := models.SelectWorkOvertimeByFilter(filter, page, limit, o)
	count, err := models.GetWorkOvertimeCountByFilter(filter, o)
	if err != nil {
		res := &uitl.RtMsg{1, "添加失败，数据库操作失败！", count, data} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	o.Commit()
	res := &uitl.RtMsg{0, "获取成功！", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
加班申请记录导出excel数据
 */
func (c *WorkOvertimeController)OutputWorkOvertime() {
	companyId := c.GetSession("companyId").(int) // 公司ID
	date := c.GetString("Date")
	o := orm.NewOrm()
	if len(date) <= 0 {
		year := strconv.FormatInt(int64(time.Now().Year()), 10)
		mouth := strconv.FormatInt(int64(time.Now().Month()-1), 10)
		date = year + "-" + mouth
	}
	tDate, _ := time.ParseInLocation("2006-01-02", date+"-01", time.Local)
	year := strconv.FormatInt(int64(tDate.Year()), 10)
	sMouth := strconv.FormatInt(int64(tDate.Month()), 10)
	eMouth := strconv.FormatInt(int64(tDate.Month()) + 1, 10)
	beginDate := year + "-" + sMouth + "-01 00:00:00"
	endDate := year + "-" + eMouth + "-01 00:00:00"

	xlFile := xlsx.NewFile()
	titleList := []string{"员工编号", "姓名", "开始时间", "结束时间", "小计(单位小时)"}
	sheetList := []string{"平时", "公休", "节日"}
	userList := models.GetAllUsersByStatus("在职", companyId)
	for _, v := range sheetList {
		xlFile.AddSheet(v)
	}
	for s, sheet := range xlFile.Sheets {
		sheet.AddRow().AddCell().SetValue(date + "员工加班详情表")
		row := sheet.AddRow()
		for _, v := range titleList {
			row.AddCell().SetValue(v)
		}
		for _, user := range userList {
			filter := map[string]interface{}{}
			filter["applier"] = user.Id
			filter["start_time__ge"] = beginDate
			filter["end_time__le"] = endDate
			filter["work_type"] = sheetList[s]
			filter["company_id"] = companyId
			works, _ := models.SelectWorkOvertimeByFilter(filter, 0, 0, o)
			for _, work := range works {
				row := sheet.AddRow()
				row.AddCell().SetValue(work["employee_num"])
				row.AddCell().SetValue(work["user_name"])
				startTime, _ := time.ParseInLocation("2006-01-02T15:04:05+08:00", work["start_time"].(string), time.Local)
				row.AddCell().SetValue(startTime.Format("2006-01-02 15:04:05"))
				endTime, _ := time.ParseInLocation("2006-01-02T15:04:05+08:00", work["end_time"].(string), time.Local)
				row.AddCell().SetValue(endTime.Format("2006-01-02 15:04:05"))
				row.AddCell().SetValue(work["total_time"])
			}
		}
	}
	filePath := "/ERPFile/TEMP/work_overtime.xlsx"
	err := xlFile.Save(filePath)
	if err != nil {
		logs.Error(err)
	}
	c.Ctx.Output.Download(filePath, date+"员工加班详情表.xlsx")
}
