/*
招聘模块控制器
auth: ttc
date: 2018-09-10
 */
package controllers

import (
						"github.com/astaxie/beego"
	"cpxerp/models"
	"cpxerp/util"
)

// RecruitmentController operations for Recruitment
type RecruitController struct {
	beego.Controller
}

/*
招聘需求申请添加页面
 */
func (c *RecruitController) RecruitAddHtml()  {
	c.Data["Business"] = models.SelectAllBusiness()
	c.TplName = "recruit/recruit_add.html"
}

/*
招聘需求审核页面
 */
func (c *RecruitController) RecruitVerifyHtml() {
	c.TplName = "recruit/recruit_verify.html"
}

/*
招聘需求审核通过备案页面
 */
func (c *RecruitController) RecruitListHtml() {
	c.TplName = "recruit/recruit_list.html"
}

/*
招聘需求详情页面
 */
func (c *RecruitController) RecruitDetailHtml() {
	recruitId, err := c.GetInt(":id")
	recruit, err := models.GetRecruitmentById(recruitId)
	if err != nil {
		c.Abort("404")
	}
	c.Data["Business"] = models.SelectAllBusiness()
	c.Data["DutyTime"] = recruit.DutyTime.Format("2006-01-02")
	c.Data["recruit"] = recruit
	c.TplName = "recruit/recruit_detail.html"
}

/*
招聘需求申请行为
 */
func (c *RecruitController) RecruitDoAdd() {
	user := c.GetSession("CPXERP").(models.User)
	companyId  := c.GetSession("companyId").(int)
	recruit := models.Recruitment{}
	if err := c.ParseForm(&recruit); err != nil {
		res := &uitl.RtMsg{1, "添加失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	recruit.CreateUserId = user.Id
	recruit.CompanyId = companyId
	_, err := models.AddRecruitment(&recruit)
	if err != nil{
		res := &uitl.RtMsg{1, "添加失败，数据库添加错误！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "添加数据成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
通过申请人查找对应的申请记录
 */
func (c *RecruitController) RecruitSelectByCreateUser() {
	user := c.GetSession("CPXERP").(models.User)
	companyId  := c.GetSession("companyId").(int)
	page, err := c.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		limit = 10
	}

	filter := map[string]interface{}{}
	filter["create_user_id"] = user.Id
	filter["company_id"] = companyId

	pageDate := models.SelectRecruitByFilter(filter, "", page, limit)
	count := models.GetRecruitCountByFilter(filter)
	res := &uitl.RtMsg{0, "添加数据成功！", count, pageDate} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
招聘申请待审核数据查询
 */
func (c *RecruitController) RecruitSelectByVerify() {
	user := c.GetSession("CPXERP").(models.User)
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	companyId := c.GetSession("companyId").(int)
	if err != nil {
		c.Abort("404")
	}
	order := c.GetString("order", "-r.create_time")		// 对是否招聘完成进行排序,
	page, err := c.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		limit = 10
	}

	filter := map[string]interface{}{}
	if myModule["persionnel2_examine"] {
		filter["personnel_is_pass"] = 0
		filter["ceo_is_pass"] = 0
	}else if myModule["ceo_examine"] {
		filter["personnel_is_pass"] = 1
		filter["ceo_is_pass"] = 0
	}else {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

	filter["company_id"] = companyId

	pageDate := models.SelectRecruitByFilter(filter, order, page, limit)
	count := models.GetRecruitCountByFilter(filter)
	res := &uitl.RtMsg{0, "查询成功！", count, pageDate} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
招聘申请审核行为
 */
func (c *RecruitController) RecruitDoVerify()  {
	user := c.GetSession("CPXERP").(models.User)
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	recruitId, err := c.GetInt(":id")
	isPass, err := c.GetInt("isPass", 0)
	recruit, err := models.GetRecruitmentById(recruitId)
	if err != nil {
		c.Abort("404")
	}
	if myModule["persionnel2_examine"] {
		recruit.PersonnelIsPass = isPass
	} else if myModule["ceo_examine"] {
		recruit.CeoIsPass = isPass
		recruit.IsOk = isPass
	} else {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	if isPass == 2 {
		recruit.IsOk = isPass
	}

	err = models.UpdateRecruitmentById(recruit)
	if err != nil {
		res := &uitl.RtMsg{1, "审核数据失败！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "审核数据成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

func (c *RecruitController) RecruitSelectHadPass(){
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	if err != nil {
		c.Abort("404")
	}
	page, err := c.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		limit = 10
	}
	order := c.GetString("order", "-r.create_time")		// 对是否招聘完成进行排序,

	filter := map[string]interface{}{}
	if !(myModule["persionnel2_examine"] || myModule["ceo_examine"]) {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	filter["is_ok"] = 1
	filter["company_id"] = companyId

	pageDate := models.SelectRecruitByFilter(filter, order, page, limit)
	count := models.GetRecruitCountByFilter(filter)
	res := &uitl.RtMsg{0, "查询成功！", count, pageDate} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
招聘需求已招聘
 */
func (c *RecruitController) RecruitHadDo() {
	recruitId, err := c.GetInt(":id")
	recruit, err := models.GetRecruitmentById(recruitId)
	if err != nil {
		c.Abort("404")
	}
	recruit.IsHadRecruit = 1
	err = models.UpdateRecruitmentById(recruit)
	if err != nil {
		res := &uitl.RtMsg{1, "完成招聘状态变更失败！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "完成招聘状态变更！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
招聘需求是否允许內推
 */
func (c *RecruitController) RecruitDoInternal() {
	recruitId, err := c.GetInt(":id")
	recruit, err := models.GetRecruitmentById(recruitId)
	isInternal, err := c.GetInt("isInternal", 1)
	if err != nil {
		c.Abort("404")
	}
	recruit.IsInternal = isInternal
	err = models.UpdateRecruitmentById(recruit)
	if err != nil {
		res := &uitl.RtMsg{1, "内推状态变更失败！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "内推状态变更成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

