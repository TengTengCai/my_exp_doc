package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"strconv"
	"strings"
)

type SetController struct {
	beego.Controller
}

//权限设置 ----- start -----
//进入授权界面
func (u *SetController) AuthorizationHtml() {
	role := models.Role{}
	module := models.Module{}
	roles := role.GetAll()
	modules := module.GetAll()

	companyId := u.GetSession("companyId")
	user := models.User{}
	users := user.GetUserByCompany(companyId.(int))
	u.Data["users"] = users
	u.Data["roles"] = roles
	u.Data["modules"] = modules
	u.TplName = "set_up/set_authorization.html"
}

//根据roleId获取权限模块
func (u *SetController) ModulesByRoleId() {
	id, _ := u.GetInt("id")
	role := models.Role{}
	err, modules := role.GetModuleList(id)
	if err != nil {
		logs.Error("select modules by roleId err,", err)
		return
	}
	res := &uitl.RtMsg{0, "系统异常！", 0, modules}
	u.Data["json"] = res
	u.ServeJSON()
	return
}

//设置角色权限
func (u *SetController) RoleModuleDoUpdate() {
	modulesIds := u.GetString("modulesIds")
	roleId, _ := u.GetInt("roleId")
	ids := strings.Split(modulesIds, ",")
	role := models.Role{}
	b := role.AddModules(strconv.Itoa(roleId), ids)
	if b {
		res := &uitl.RtMsg{0, "修改成功！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	res := &uitl.RtMsg{1, "修改失败！", 0, nil}
	u.Data["json"] = res
	u.ServeJSON()
	return
}

//更新用户权限，更新roleId
func (u *SetController) UserRoleDoUpate() {
	roleId, _ := u.GetInt("roleId")
	userId, _ := u.GetInt("userId")
	user := models.User{}
	b := user.UpdateRoleIdByUserId(userId, roleId)
	if b {
		res := &uitl.RtMsg{0, "修改成功！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	res := &uitl.RtMsg{1, "修改失败！", 0, nil}
	u.Data["json"] = res
	u.ServeJSON()
	return
}

//权限设置 ----- end -----

//业务线管理 ----- start -----
func (u *SetController) BusinessAddHtml() {
	u.TplName = "set_up/set_business_add.html"
}

func (u *SetController) BusinessDoAdd() {
	name := u.GetString("businessName")
	business := models.Business{}
	b, _ := business.GetBusinessByName(name)
	if b {
		res := &uitl.RtMsg{1, "业务已存在！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {

		business := models.Business{BusinessName: name, BusinessStatus: 0}
		_, err := models.AddBusinss(&business)
		if err != nil {
			logs.Error("add business faild", err)
			res := &uitl.RtMsg{1, "新增失败！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "新增成功！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}

	}
}

func (u *SetController) BusinessList() {
	page, err := u.GetInt("page")
	if err != nil {
		return
	}
	limit, err := u.GetInt("limit")
	if err != nil {
		return
	}
	business := models.Business{}

	pageData := business.FinadAllByPage(page, limit)
	res := &uitl.RtMsg{0, "提交成功！！", pageData.TotalCount, pageData.Data}
	u.Data["json"] = res
	u.ServeJSON()
	return

}

func (u *SetController) BusinessUpdateHtml() {
	id := u.Ctx.Input.Param(":id")
	i, err := strconv.Atoi(id)
	if err != nil {
		return
	}
	business, err := models.GetBusinssById(i)
	if err != nil {
		logs.Error(err)
		return
	}
	u.Data["business"] = business
	u.TplName = "set_up/set_business_update.html"
}

//修改业务线名字
func (u *SetController) BusinessDoUpdate() {
	id, _ := u.GetInt("​businessId")
	name := u.GetString("businessName")
	business := models.Business{}
	b, _ := business.GetBusinessByName(name)
	if b {
		res := &uitl.RtMsg{1, "业务已存在！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {

		b := business.UpdateBusinessId(name, -1, id)
		if !b {
			fmt.Println("update business faild")
			res := &uitl.RtMsg{1, "修改失败！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "修改成功！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}

	}
}

//修改业务线状态
func (u *SetController) BusinessDoUpdateStatus() {
	id, _ := u.GetInt("BusinessId")
	business := models.Business{}
	b := business.UpdateBusinessId("", 1, id)
	if !b {
		fmt.Println("update business faild")
		res := &uitl.RtMsg{1, "修改失败！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "修改成功！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

}

//业务线管理 ----- end -----

//岗位管理 ----- start -----
func (u *SetController) RoleAddHtml() {
	department := models.Department{}
	departments := department.FinddAll()
	u.Data["deparments"] = departments
	u.TplName = "set_up/set_role_add.html"
}

func (u *SetController) RoleDoAdd() {
	name := u.GetString("roleName")
	level, err := u.GetInt("level")
	if err != nil {
		return
	}
	departmentId, err := u.GetInt("departmentId")
	if err != nil {
		return
	}
	role := models.Role{}
	b, _ := role.GetRoleByName(name)
	if b {
		res := &uitl.RtMsg{1, "岗位已存在！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		role := models.Role{RoleName: name, RoleLevel: level, DepartmentId: departmentId}
		_, err := models.AddRole(&role)
		if err != nil {
			logs.Error("add role faild", err)
			res := &uitl.RtMsg{1, "新增失败！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "新增成功！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}

	}
}

func (u *SetController) RoleList() {
	page, err := u.GetInt("page")
	if err != nil {
		return
	}
	limit, err := u.GetInt("limit")
	if err != nil {
		return
	}
	role := models.Role{}

	pageData := role.FinadAllByPage(page, limit)
	res := &uitl.RtMsg{0, "提交成功！！", pageData.TotalCount, pageData.Data}
	u.Data["json"] = res
	u.ServeJSON()
	return

}

func (u *SetController) RoleUpdateHtml() {
	id := u.Ctx.Input.Param(":id")
	i, err := strconv.Atoi(id)
	if err != nil {
		return
	}
	role, err := models.GetRoleById(i)
	if err != nil {
		logs.Error(err)
		return
	}
	department := models.Department{}
	departments := department.FinddAll()
	for i := 0; i < len(departments); i++ {
		if departments[i].DepartmentId == role.DepartmentId {
			departments[i].Flag = true
		} else {
			departments[i].Flag = false
		}
	}
	u.Data["deparments"] = departments
	u.Data["role"] = role
	u.TplName = "set_up/set_role_update.html"
}

func (u *SetController) RoleDoUpdate() {
	id, _ := u.GetInt("​roleId")
	name := u.GetString("roleName")
	level, err := u.GetInt("level")
	if err != nil {
		return
	}
	departmentId, err := u.GetInt("departmentId")
	if err != nil {
		return
	}
	role := models.Role{}
	b, rol := role.GetRoleByName(name)
	if b && level == rol.RoleLevel && departmentId == rol.DepartmentId {
		res := &uitl.RtMsg{1, "岗位已存在！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {

		role1 := models.Role{RoleId: id, RoleName: name, RoleLevel: level, DepartmentId: departmentId}
		err := models.UpdateRoleById(&role1)
		if err != nil {
			logs.Error("update role faild", err)
			res := &uitl.RtMsg{1, "修改失败！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "修改成功！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}

	}
}

//岗位管理 ----- end -----

//区域管理 ----- start -----
func (u *SetController) AreaAddHtml() {

	u.TplName = "set_up/set_area_add.html"
}

func (u *SetController) AreaDoAdd() {
	name := u.GetString("areaName")

	area := models.Area{}
	b, _ := area.GetAreaByName(name)
	if b {
		res := &uitl.RtMsg{1, "区域已存在！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		area1 := models.Area{AreaName: name}
		_, err := area1.Add()
		if err != nil {
			logs.Error("add area faild", err)
			res := &uitl.RtMsg{1, "新增失败！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "新增成功！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}

	}
}

func (u *SetController) AreaList() {
	page, err := u.GetInt("page")
	if err != nil {
		return
	}
	limit, err := u.GetInt("limit")
	if err != nil {
		return
	}
	area := models.Area{}

	pageData := area.FinadAllByPage(page, limit)
	res := &uitl.RtMsg{0, "提交成功！！", pageData.TotalCount, pageData.Data}
	u.Data["json"] = res
	u.ServeJSON()
	return

}

func (u *SetController) AreaUpdateHtml() {
	id := u.Ctx.Input.Param(":id")
	i, err := strconv.Atoi(id)
	if err != nil {
		return
	}
	area := models.Area{}
	area1 := area.GetAreaById(i)
	if area1 == nil {
		return
	}
	u.Data["area"] = area1
	u.TplName = "set_up/set_area_update.html"
}

func (u *SetController) AreaDoUpdate() {
	id, _ := u.GetInt("​areaId")
	name := u.GetString("areaName")

	area := models.Area{}

	b, _ := area.GetAreaByName(name)
	if b {
		res := &uitl.RtMsg{1, "区域已存在！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {

		area1 := models.Area{AreaId: id, AreaName: name}
		b, err := area1.Update()
		if err != nil && !b {
			logs.Error("update role faild", err)
			res := &uitl.RtMsg{1, "修改失败！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{0, "修改成功！", 0, nil}
			u.Data["json"] = res
			u.ServeJSON()
			return
		}

	}
}

//区域管理 ----- end -----

//职级管理 ----- start -----
func (u *SetController) RankAddHtml() {

	u.TplName = "set_up/set_rank_add.html"
}

func (u *SetController) RankDoAdd() {
	name := u.GetString("rankName")
	var flag bool
	if name == "P" {
		p := models.ProfessionalRank{}
		flag = p.Add()
	}
	if name == "T" {
		t := models.TechnicalRank{}
		flag = t.Add()
	}
	if name == "M" {
		m := models.ManagementRank{}
		flag = m.Add()
	}
	if flag {
		res := &uitl.RtMsg{0, "新增成功！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "新增失败！", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

}

func (u *SetController) RankList() {
	page, err := u.GetInt("page")
	if err != nil {
		return
	}
	limit, err := u.GetInt("limit")
	if err != nil {
		return
	}
	name := u.GetString("rankName")
	if name == "P" {
		p := models.ProfessionalRank{}
		pageData := p.Select(page, limit)
		res := &uitl.RtMsg{0, "", pageData.TotalCount, pageData.Data}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	if name == "T" {
		t := models.TechnicalRank{}
		pageData := t.Select(page, limit)
		res := &uitl.RtMsg{0, "", pageData.TotalCount, pageData.Data}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	if name == "M" {
		m := models.ManagementRank{}
		pageData := m.Select(page, limit)
		res := &uitl.RtMsg{0, "", pageData.TotalCount, pageData.Data}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}
	if name == "" {
		res := &uitl.RtMsg{0, "", 0, nil}
		u.Data["json"] = res
		u.ServeJSON()
		return
	}

}

//职级管理 ----- end -----
