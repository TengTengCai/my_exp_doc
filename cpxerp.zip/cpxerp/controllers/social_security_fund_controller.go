package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
)

type SocialSecurityFundController struct {
	beego.Controller
}

//进入设置社保公积金基数设置页面
func (s *SocialSecurityFundController) SSFHtml() {
	companyId := s.GetSession("companyId").(int) // 公司ID
	ssf := models.SocialSecurityFund{}
	ssf.CompanyId = companyId
	ssf.Select()
	b := false
	if ssf.PercentageOfInsurance == 0 {
		b = false
	} else {
		b = true
	}
	s.Data["ssf"] = ssf
	s.Data["b"] = b
	s.TplName = "set_up/set_SSF.html"
}

//新增基数
func (s *SocialSecurityFundController) SSFDoAdd() {
	companyId := s.GetSession("companyId").(int)
	ssf := models.SocialSecurityFund{}
	err := s.ParseForm(&ssf)
	if err != nil {
		logs.Error("ssf add formdata err,", err)
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		s.Data["json"] = res
		s.ServeJSON()
		return
	}
	ssf.CompanyId = companyId
	b := ssf.Insert()
	if b {
		res := &uitl.RtMsg{0, "添加成功！！", 0, nil}
		s.Data["json"] = res
		s.ServeJSON()
	} else {
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		s.Data["json"] = res
		s.ServeJSON()
		return
	}
}

//修改基数
func (s *SocialSecurityFundController) SSFDoUpdate() {
	companyId := s.GetSession("companyId").(int)
	ssf := models.SocialSecurityFund{}
	err := s.ParseForm(&ssf)
	if err != nil {
		logs.Error("ssf add formdata err,", err)
		res := &uitl.RtMsg{1, "修改失败！！", 0, nil}
		s.Data["json"] = res
		s.ServeJSON()
		return
	}
	ssf.CompanyId = companyId
	b := ssf.Update()
	if b {
		res := &uitl.RtMsg{0, "修改成功！！", 0, nil}
		s.Data["json"] = res
		s.ServeJSON()
	} else {
		res := &uitl.RtMsg{1, "修改失败！！", 0, nil}
		s.Data["json"] = res
		s.ServeJSON()
		return
	}
}

//进入社保公积金查询页面
func (s *SocialSecurityFundController) SSFSelectHtml() {
	s.TplName = "social_security_fund/social_security_fund.html"
}

//查询社保公积金计算后的数据
func (s *SocialSecurityFundController) SSFSelect() {
	page, err := s.GetInt("page")
	if err != nil {
		return
	}
	limit, err := s.GetInt("limit")
	if err != nil {
		return
	}
	companyId := s.GetSession("companyId").(int)
	user := models.User{}
	pages := user.SelectOfficialUsers(companyId, page, limit)
	ssfus := []models.SocialSecurityFundForUser{}
	sf := models.SocialSecurityFund{}
	sf.CompanyId = companyId
	sf.Select()
	users := pages.Data.(*[]models.User)
	for _, v := range *users {
		ssf := models.SocialSecurityFundForUser{}
		ssf.EmployeeNum = v.EmployeeNum
		ssf.Name = v.Name
		ssf.NatureOfWork = v.NatureOfWork
		if v.NatureOfWork == "试用" {
			ssf.BasicSalary = v.ProbationBasicSalary
		}
		if v.NatureOfWork == "转正" {
			ssf.BasicSalary = v.RegularBasicSalary
		}
		basi := ssf.BasicSalary
		ssf.NumOfInsurance = v.NumOfInsurance
		ssf.Insurance = uitl.Decimal(basi*sf.PercentageOfInsurance, "2")
		ssf.NumOfUnempLoymentInsurance = v.NumOfUnempLoymentInsurance
		ssf.UnempLoymentInsurance = uitl.Decimal(basi*sf.PercentageOfUnempLoymentInsurance, "2")
		ssf.NumOfMedicalInsurance = v.NumOfMedicalInsurance
		ssf.MedicalInsurance = uitl.Decimal(basi*sf.PercentageOfMedicalInsurance, "2")
		ssf.PercentageOfFunc = sf.PercentageOfFunc
		ssf.Func = uitl.Decimal(v.AccumulationFundBase*sf.PercentageOfFunc, "2")
		ssf.Other = 0

		ssfus = append(ssfus, ssf)
	}
	res := &uitl.RtMsg{0, "", pages.TotalCount, ssfus}
	s.Data["json"] = res
	s.ServeJSON()
	return
}
