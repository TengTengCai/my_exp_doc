/*
报销相关控制器
Auth: TTC
Date: 2018-08-21
*/
package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"encoding/json"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
		"os"
	"strconv"
	"strings"
	"time"
)

type ReimburseController struct {
	beego.Controller
}

/*
普通报销申请页面
*/
func (c *ReimburseController) OrdReimburseApplyHtml() {
	user := c.GetSession("CPXERP").(models.User)
	depart, _ := models.GetDepartmentById(user.DepartmentId)
	c.Data["department"] = depart.DepartmentName
	c.TplName = "reimburse/ord_reimburse_apply.html"
}

/*
差旅报销申请页面
*/
func (c *ReimburseController) TraReimburseApplyHtml() {
	user := c.GetSession("CPXERP").(models.User)
	depart, _ := models.GetDepartmentById(user.DepartmentId)
	c.Data["department"] = depart.DepartmentName
	c.TplName = "reimburse/tra_reimburse_apply.html"
}

/*
报销查询页面
*/
func (c *ReimburseController) ReimburseListHtml() {
	c.TplName = "reimburse/reimburse_list.html"
}

/*
报销审核页面
*/
func (c *ReimburseController) ReimburseVerifyHtml() {
	c.TplName = "reimburse/reimburse_verify.html"
}

/*
报销付款状态改变页面
*/
func (c *ReimburseController) ReimbursePaymentHtml() {
	c.TplName = "reimburse/reimburse_payment.html"
}

/*
普通报销申请添加数据行为
*/
func (c *ReimburseController) OrdReimburseDoApply() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	timeStr := c.GetString("apply_time") + " 00:00:00" // 时间需要处理
	applyTime, err := time.Parse("2006-01-02 15:04:05", timeStr)
	if err != nil {
		res := &uitl.RtMsg{1, "申请失败，参数错误！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	currency := c.GetString("currency")
	applyPrice := c.GetString("apply_price")
	capitals := c.GetString("capitals")

	fileName := c.GetString("filename")
	var fileUrl string = "" // 文件路径
	if len(fileName) > 0 {
		if !uitl.MoveFileFromTemp(fileName, uitl.ORD_REIMBURSE) {
			res := &uitl.RtMsg{1, "添加失败,服务器文件未找到!", 0, nil} // 返回的对应的相应数据
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
		fileUrl = "/file/" + uitl.ORD_REIMBURSE + fileName
	}
	ordReimburse := models.OrdinaryReimburse{}
	ordReimburse.Applyer = user.Id
	ordReimburse.ApplyTime = applyTime
	ordReimburse.ApplyDepart = user.DepartmentId
	ordReimburse.CurType = currency
	ordReimburse.Capitals = capitals
	ordReimburse.FileUrl = fileUrl
	ordReimburse.ApplyPrice, err = strconv.ParseFloat(applyPrice, 64)
	if err != nil {
		res := &uitl.RtMsg{1, "申请失败，金额参数解析错误！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	ordReimburse.CompanyId = companyId
	fmt.Println(ordReimburse)
	num, err := models.AddOrdinaryReimburse(&ordReimburse)
	if err != nil {
		logs.Info(err)
		res := &uitl.RtMsg{1, "数据库错误,添加数据失败", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

	reimburseStr := c.GetString("reimburse_list", "")
	if len(reimburseStr) > 0 {
		reimburseList := make([]models.OrdReimburseDetail, 1) // 返点列表Json解析为Rebate数组
		err = json.Unmarshal([]byte(reimburseStr), &reimburseList)
		if err != nil {
			models.DeleteContract(int(num))                               // 列表添加失败删除对应合同,让他重新添加合同
			res := &uitl.RtMsg{1, "添加失败,报销详细信息解析失败,请重新上传报销详细数据!", 0, nil} // 返回的对应的相应数据
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
		// 遍历添加数据带到数据库中
		for _, x := range reimburseList {
			x.OrdReimburseId = int(num)
			models.AddOrdReimburseDetail(&x)
		}
	}
	res := &uitl.RtMsg{0, fmt.Sprintf("申请成功！Id为%d", num), 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
获取普通报销列表数据
*/
func (c *ReimburseController) GetOrdReimburseList() {
	var (
		order string
		page  int
		limit int
		err   error
	)
	user := c.GetSession("CPXERP").(models.User) // 获取用户身份
	filter := map[string]interface{}{}
	filter["applyer"] = user.Id
	page, err = c.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err = c.GetInt("limit")
	if err != nil {
		limit = 10
	}
	order = c.GetString("order", "")
	pageData := models.SelectOrdReimburse(filter, order, page, limit)
	count := models.GetSelectOrdReimburseCount(filter)
	res := &uitl.RtMsg{0, "获取数据成功！！", count, pageData}
	c.Data["json"] = res
	c.ServeJSON()
}

/*
打开详情页面，报销单id
*/
func (c *ReimburseController) SelectOrdDetailsHtml() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		fmt.Println(err)
	}
	//traReimburse := models.GetOneTraReimburseById(id)
	//departStatus := traReimburse.DepartStatus
	//financialStatus := traReimburse.FinancialStatus
	//ceoStatus := traReimburse.CeoStatus
	//var isEdit bool
	//if  departStatus == 2  || financialStatus == 2 || ceoStatus == 2{
	//	isEdit = true
	//}else {
	//	isEdit = false
	//}
	//c.Data["isEdit"] = isEdit
	//c.Data["data"] = traReimburse
	c.Data["id"] = id
	c.TplName = "reimburse/ord_reimburse_info.html"
}

/*
通过报销单id，查询报销详情列表
*/
func (c *ReimburseController) SelectOrdDetails() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		fmt.Println(err)
	}
	details, num := models.SelectByOrdId(id)
	res := &uitl.RtMsg{0, "", num, details} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
普通报销审核列表数据
*/
func (c *ReimburseController) OrdReimburseExamineData() {
	user := c.GetSession("CPXERP").(models.User) // 获取用户身份
	companyId := c.GetSession("companyId").(int) // 获取公司当前id
	page, err := c.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		limit = 10
	}
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	if err != nil {
		res := &uitl.RtMsg{1, "获取数据失败!,角色不明!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

	filter := map[string]interface{}{}
	filter["company_id"] = companyId

	if myModule["deppart_examine"] {
		filter["apply_depart"] = user.DepartmentId
		filter["depart_status"] = 0
	} else if myModule["finance_examine"] {
		filter["depart_status"] = 1
		filter["financial_status"] = 0
	} else if myModule["ceo_examine"] {
		filter["depart_status"] = 1
		filter["financial_status"] = 1
		filter["ceo_status"] = 0
	} else {
		res := &uitl.RtMsg{1, "获取数据失败!,权限不足", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	data := models.SelectOrdReimburse(filter, "", page, limit)
	count := models.GetSelectOrdReimburseCount(filter)
	res := &uitl.RtMsg{0, "获取数据成功!", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
	//roleLevel := role.RoleLevel
	//var data []orm.Params
	//var count int
	//if roleLevel == 1 {
	//	res := &uitl.RtMsg{1, "获取数据失败!,权限不足", 0, nil} // 返回的对应的相应数据
	//	c.Data["json"] = res
	//	c.ServeJSON()
	//	return
	//} else if roleLevel == 2 {
	//	filter["apply_depart"] = user.DepartmentId
	//	filter["depart_status"] = 0
	//	data = models.SelectOrdReimburse(filter, "", page, limit)
	//	count = models.GetSelectOrdReimburseCount(filter)
	//} else if roleLevel == 3 {
	//	index := strings.Index(role.RoleName, "财务")
	//	if index >= 0 {
	//		// 这是财务的过滤条件
	//		filter["depart_status"] = 1
	//		filter["financial_status"] = 0
	//		// 查数据 赋值给data
	//		data = models.SelectOrdReimburse(filter, "", page, limit)
	//		count = models.GetSelectOrdReimburseCount(filter)
	//	} else {
	//		// 这是CEO的过滤条件,有两个
	//		// 这得写两个filter,复制基础map, 一个是财务审核过的,一个是未接手财务的
	//		// 查两个数据,进行数组拼接,赋值给data
	//		filter["depart_status"] = 1
	//		filter["financial_status"] = 1
	//		filter["ceo_status"] = 0
	//		data = models.SelectOrdReimburse(filter, "", page, limit)
	//		count = models.GetSelectOrdReimburseCount(filter)
	//
	//	}
	//}
	//res := &uitl.RtMsg{0, "获取数据成功!", count, data} // 返回的对应的相应数据
	//c.Data["json"] = res
	//c.ServeJSON()
	//return
}

/*
普通报销审核行为
*/
func (c *ReimburseController) OrdReimburseDoExamine() {
	user := c.GetSession("CPXERP").(models.User)
	ordReimburseid, err := c.GetInt("Id")
	authitStatus, err := c.GetInt("AuditStatus")
	if err != nil {
		res := &uitl.RtMsg{1, "参数错误!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	role, err := models.GetRoleById(user.RoleId)
	if err != nil {
		res := &uitl.RtMsg{1, "权限不足!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	ordReimburse, err := models.GetOrdinaryReimburseById(ordReimburseid)
	if err != nil {
		c.Abort("404")
	}
	if role.RoleLevel == 2 {
		ordReimburse.DepartStatus = int8(authitStatus)
	} else if role.RoleLevel == 3 {
		index := strings.Index(role.RoleName, "财务")
		if index >= 0 {
			// 这是财务的过滤条件
			ordReimburse.FinancialStatus = int8(authitStatus)
			// 查数据 赋值给data
		} else {
			// 这是CEO的过滤条件,有两个
			// 这得写两个filter,复制基础map, 一个是财务审核过的,一个是未接手财务的
			// 查两个数据,进行数组拼接,赋值给data
			ordReimburse.CeoStatus = int8(authitStatus)
		}
	}
	err = models.UpdateOrdinaryReimburseById(ordReimburse)
	if err != nil {
		res := &uitl.RtMsg{1, "修改权限失败!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "审核成功!", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
普通报销支付数据
*/
func (c *ReimburseController) OrdReimbursePayData() {
	user := c.GetSession("CPXERP").(models.User)
	page, err := c.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		limit = 10
	}
	role, err := models.GetRoleById(user.RoleId)
	if err != nil {
		res := &uitl.RtMsg{1, "数据获取失败,无法识别角色", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	if role.RoleId != 6 {
		res := &uitl.RtMsg{1, "角色权限不足!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	filter := map[string]interface{}{}
	filter["depart_status"] = 1
	filter["financial_status"] = 1
	filter["ceo_status"] = 1
	//filter["pay_status"] = 0
	datas := models.SelectOrdReimburse(filter, "", page, limit)
	count := models.GetSelectOrdReimburseCount(filter)
	res := &uitl.RtMsg{0, "数据请求成功", count, datas} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
普通报销更改支付状态行为
*/
func (c *ReimburseController) OrdReimburseDoPay() {
	user := c.GetSession("CPXERP").(models.User)
	Id, _ := c.GetInt("Id")
	ordReimburse, err := models.GetOrdinaryReimburseById(Id)
	if err != nil {
		c.Abort("404")
	}
	if user.RoleId != 6 {
		res := &uitl.RtMsg{1, "权限不足,无法修改支付状态", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	ordReimburse.PayStatus = 1
	err = models.UpdateOrdinaryReimburseById(ordReimburse)
	if err != nil {
		res := &uitl.RtMsg{1, "数据库错误,无法修改状态!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "付款成功!", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
普通报销更新相关文件的行为
*/
func (c *ReimburseController) OrdReimburseUploadById() {
	ordId, err := c.GetInt(":id")
	if err != nil {
		c.Abort("404")
	}
	f, h, err := c.GetFile("uploadName") // 文件获取
	if err != nil {
		//log.Fatal("getfile err ", err)
		res := &uitl.RtMsg{1, "上传文件失败!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
	}
	defer f.Close()                                                        // 文件流的关闭
	filepath, filename := uitl.GetFilePath(h.Filename, uitl.ORD_REIMBURSE) // uuid文件名生成,路径生成
	c.SaveToFile("uploadName", filepath)
	ordReimburse, err := models.GetOrdinaryReimburseById(ordId)
	fileUrl := "/file/" + uitl.ORD_REIMBURSE + filename
	ordReimburse.FileUrl = fileUrl
	err = models.UpdateOrdinaryReimburseById(ordReimburse)
	if err != nil {
		os.Remove(filepath)
		res := &uitl.RtMsg{1, "上传文件失败,数据库读写错误!", 0, filename} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
	}
	res := &uitl.RtMsg{0, "上传文件成功!", 0, filename} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
}

/*
差旅报销数据录入
*/
func (c *ReimburseController) TraReimburseDoApply() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	fileName := c.GetString("filename")
	var fileUrl string = "" // 文件路径
	if len(fileName) > 0 {
		if !uitl.MoveFileFromTemp(fileName, uitl.TRA_REIMBURSE) {
			res := &uitl.RtMsg{1, "添加失败,服务器文件未找到!", 0, nil} // 返回的对应的相应数据
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
		fileUrl = "/file/" + uitl.TRA_REIMBURSE + fileName
	}

	aTime := c.GetString("ApplyTime") + " 00:00:00"

	applyTime, err := time.Parse("2006-01-02 15:04:05", aTime)
	if err != nil {
		logs.Error("string to time err,", err)
	}
	osTime := c.GetString("OutStartTime")
	outStartTime, err := time.Parse("2006-01-02 15:04:05", osTime)
	if err != nil {
		logs.Error("string to time err,", err)
	}
	oeTime := c.GetString("OutEndTime")
	outEndTime, err := time.Parse("2006-01-02 15:04:05", oeTime)
	if err != nil {
		logs.Error("string to time err,", err)
	}
	travelReimburse := models.TravelReimburse{}
	err = c.ParseForm(&travelReimburse)
	if err != nil {
		logs.Error("customer formData err", err)
	}

	travelReimburse.FileUrl = fileUrl
	travelReimburse.CompanyId = companyId
	travelReimburse.ApplyerId = user.Id
	travelReimburse.ApplyDepartId = user.DepartmentId
	travelReimburse.CeoStatus = 0
	travelReimburse.DepartStatus = 0
	travelReimburse.FinancialStatus = 0
	travelReimburse.PayStatus = 0
	travelReimburse.ApplyTime = applyTime
	travelReimburse.OutStartTime = outStartTime
	travelReimburse.OutEndTime = outEndTime

	details := c.GetString("details")
	traReimburseDetails := []models.TraReimburseDetail{}
	err = json.Unmarshal([]byte(details), &traReimburseDetails)
	if err != nil {
		logs.Error("reimburse_controller", err)
	}
	flag := travelReimburse.Add(traReimburseDetails)
	if flag {
		res := &uitl.RtMsg{0, "添加成功！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
差旅报销查询接口,谁申请谁查询
*/
func (c *ReimburseController) TraReimburseData() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	travelReimburse := models.TravelReimburse{}
	newPage := travelReimburse.SelectBySelf(page, limit, user, companyId)
	res := &uitl.RtMsg{0, "", newPage.TotalCount, newPage.Data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
差旅报销审核查询接口
*/
func (c *ReimburseController) TraReimburseExamineData() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	role := models.Role{}
	_, modules := role.GetModuleMaps(user.RoleId)
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	travelReimburse := models.TravelReimburse{}
	newPage := travelReimburse.SelectExamineData(page, limit, modules, user, companyId)
	if newPage != nil {
		res := &uitl.RtMsg{0, "", newPage.TotalCount, newPage.Data} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
打开详情页面，报销单id
*/
func (c *ReimburseController) SelectTraDetailsHtml() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		fmt.Println(err)
	}
	//traReimburse := models.GetOneTraReimburseById(id)
	//departStatus := traReimburse.DepartStatus
	//financialStatus := traReimburse.FinancialStatus
	//ceoStatus := traReimburse.CeoStatus
	//var isEdit bool
	//if  departStatus == 2  || financialStatus == 2 || ceoStatus == 2{
	//	isEdit = true
	//}else {
	//	isEdit = false
	//}
	//c.Data["isEdit"] = isEdit
	//c.Data["data"] = traReimburse
	c.Data["id"] = id
	c.TplName = "reimburse/tra_reimburse_info.html"
}

/*
通过报销单id，查询报销详情列表
*/
func (c *ReimburseController) SelectTraDetails() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		logs.Error(err)
	}
	detail := models.TraReimburseDetail{}
	details := detail.SelectByTraId(id)
	res := &uitl.RtMsg{0, "", len(*details), details} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
审核差旅报销信息，部门-财务-公司领导
*/
func (c *ReimburseController) TravelReimburseDoExamine() {
	user := c.GetSession("CPXERP").(models.User)
	travelReimburseId, _ := c.GetInt("Id")
	role := models.Role{}
	_, modules := role.GetModuleMaps(user.RoleId)
	authitStatus, _ := c.GetInt("AuditStatus")
	if user.RoleId == 2 || user.RoleId == 6 || user.RoleId == 8 {
		tra := models.TravelReimburse{}
		flag := tra.UpdateStatus(modules, user, authitStatus, travelReimburseId)
		if flag {
			res := &uitl.RtMsg{0, "已审核", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{-1, "系统异常！！", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
	} else {
		res := &uitl.RtMsg{-1, "权限不足！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return

	}
}

/*
查询差旅报销待放款的数据
*/
func (c *ReimburseController) TravelReimbursePayData() {
	companyId := c.GetSession("companyId").(int)
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	tra := models.TravelReimburse{}
	newPage := tra.SelectByStatus(page, limit, companyId)
	res := &uitl.RtMsg{0, "", newPage.TotalCount, newPage.Data}
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
操作差旅报销放款，修改放款状态
*/
func (c *ReimburseController) TravelReimburseDoPay() {
	borrowId, _ := c.GetInt("Id")
	tra := models.TravelReimburse{}
	flag := tra.UpdatePayStatus(borrowId)
	if flag {
		res := &uitl.RtMsg{0, "已放款", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{-1, "系统异常！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}
func (c *ReimburseController) TraReimburseUploadById() {
	ordId, err := c.GetInt(":id")
	if err != nil {
		c.Abort("404")
	}
	f, h, err := c.GetFile("uploadName") // 文件获取
	if err != nil {
		//log.Fatal("getfile err ", err)
		res := &uitl.RtMsg{1, "上传文件失败!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
	}
	defer f.Close()                                                        // 文件流的关闭
	filepath, filename := uitl.GetFilePath(h.Filename, uitl.TRA_REIMBURSE) // uuid文件名生成,路径生成
	c.SaveToFile("uploadName", filepath)
	ordReimburse, err := models.GetOrdinaryReimburseById(ordId)
	fileUrl := "/file/" + uitl.TRA_REIMBURSE + filename
	ordReimburse.FileUrl = fileUrl
	err = models.UpdateOrdinaryReimburseById(ordReimburse)
	if err != nil {
		os.Remove(filepath)
		res := &uitl.RtMsg{1, "上传文件失败,数据库读写错误!", 0, filename} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
	}
	res := &uitl.RtMsg{0, "上传文件成功!", 0, filename} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
}
