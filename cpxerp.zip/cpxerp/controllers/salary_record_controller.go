package controllers

import (
	"github.com/astaxie/beego"
	"cpxerp/models"
	"cpxerp/util"
)

// SalaryRecordController operations for SalaryRecord
type SalaryRecordController struct {
	beego.Controller
}

/*
薪资记录查看页面
 */
func (c *SalaryRecordController) SalaryRecordHtml() {
	userId, err := c.GetInt(":id")
	user, err := models.GetUserById(userId)
	if err != nil {
		c.Abort("404")
	}
	c.Data["Id"] = user.Id
	c.Data["Name"] = user.Name
	c.Data["EmployeeNum"] = user.EmployeeNum
	c.TplName = "record/user_salary_record.html"
}

/*
通过员工ID查询相关薪资更新记录
 */
func (c *SalaryRecordController) GetSalaryRecordById() {
	userId, err := c.GetInt(":id")
	if err != nil {
		c.Abort("404")
	}
	page, err := c.GetInt("page")
	if err != nil {
		page = 0
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		limit = 0
	}
	filter := map[string]interface{}{}
	filter["user_id"] = userId
	dates := models.GetSalaryRecordByFilter(filter, page, limit)
	count := models.GetSalaryRecordCountByFilter(filter)
	res := &uitl.RtMsg{0, "数据获取成功！", count, dates} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}
