package controllers

/*
合同控制器
Auth: TTC
Date: 2018-8-13
 */

import (
	"github.com/astaxie/beego"
	"cpxerp/models"
	"cpxerp/util"
	"time"
	"encoding/json"
	"strings"
	"github.com/astaxie/beego/orm"
	"strconv"
	"os"
)

type ContractController struct {
	beego.Controller
}

/*
合同新建页面
 */
func (c *ContractController) ContractAddHtml() {
	user := c.GetSession("CPXERP").(models.User) // 从session获取用户信息
	companyId := c.GetSession("companyId").(int) // 从session获取当前公司ID
	company, _ := models.GetCompanyById(companyId)

	role := models.Role{}         // 角色
	role.GetRoleById(user.RoleId) // 获取当前角色

	customers := models.GetPassCustomer(companyId, role.RoleLevel, user) // 顾客获取过滤

	business := models.SelectAllBusiness() // 商业线获取

	// 页面渲染参数
	c.Data["company"] = company
	c.Data["customers"] = customers
	c.Data["business"] = business
	c.TplName = "contract/contract_add.html"
}

/*
采购合同查询页面
 */
func (c *ContractController) ContractPurchaseHtml() {
	user := c.GetSession("CPXERP").(models.User) // 用户身份
	companyId := c.GetSession("companyId").(int) // 当前公司id

	role := models.Role{} // 角色
	role.GetRoleById(user.RoleId)

	customers := models.GetPassCustomer(companyId, role.RoleLevel, user) // 顾客获取过滤

	business := models.SelectAllBusiness()
	// 页面数据渲染
	c.Data["customers"] = customers
	c.Data["business"] = business
	c.TplName = "contract/contract_purchase.html"
}

/*
销售合同查询页面
 */
func (c *ContractController) ContractSalesHtml() {
	user := c.GetSession("CPXERP").(models.User) // 当前用户身份
	companyId := c.GetSession("companyId").(int) // 公司id

	role := models.Role{} // 角色
	role.GetRoleById(user.RoleId)

	customers := models.GetPassCustomer(companyId, role.RoleLevel, user) // 顾客获取过滤

	business := models.SelectAllBusiness() // 业务线列表数据
	// 渲染页面数据
	c.Data["customers"] = customers
	c.Data["business"] = business
	c.TplName = "contract/contract_sales.html"
}

/*
 合同单条合同详情页面
 */
func (c *ContractController) ContractDetailHtml() {
	contract_id, err := c.GetInt(":id")                  // 合同Id
	contract, err := models.GetContractById(contract_id) // 合同对象
	if err != nil {
		c.Abort("404") // 返回404页面
	}

	user := c.GetSession("CPXERP").(models.User) // 用户身份
	companyId := c.GetSession("companyId").(int) // 公司ID
	c.SetSession("isChangeFile", false)          // 未改变文件的状态

	//company, _ := models.GetCompanyById(companyId)

	role := models.Role{} // 角色
	role.GetRoleById(user.RoleId)
	customers := models.GetPassCustomer(companyId, role.RoleLevel, user) // 顾客获取过滤

	company, _ := models.GetCompanyById(companyId) //获取当前公司

	business := models.SelectAllBusiness() // 商业线

	fileUrl := contract.FileUrl // 文件的URL
	index := strings.LastIndex(fileUrl, "/")
	var fileName string
	if index == -1 {
		fileName = "未上传文件"
		c.SetSession("fileUrl", "") // 暂存fileUrl
	} else {
		fileName = fileUrl[index+1:]
		c.SetSession("fileUrl", fileUrl)
	}

	startTime := contract.StartTime.Format("2006-01-02") // 时间格式化
	endTime := contract.EndTime.Format("2006-01-02")
	// 渲染数据初始化
	channels := []string{"GOOGLE", "FACEBOOK", "TWITTER", "其他"}
	ptypes := []string{"CPA", "CPC", "CPL"}
	payMethod := []string{"现结", "后付款", "预付款"}
	payCurrency := []string{"USD", "RMB", "EUR"}
	// 页面渲染数据加载
	c.Data["customers"] = customers
	c.Data["business"] = business
	c.Data["contract"] = contract
	c.Data["company"] = company
	c.Data["channels"] = channels
	c.Data["ptypes"] = ptypes
	c.Data["payMethod"] = payMethod
	c.Data["payCurrency"] = payCurrency
	c.Data["fileName"] = fileName
	c.Data["startTime"] = startTime
	c.Data["endTime"] = endTime
	c.TplName = "contract/contract_detail.html"
}

/*
合同审核页面
 */
func (c *ContractController) ContractVerifyHtml() {
	user := c.GetSession("CPXERP").(models.User) // 用户身份
	role := models.Role{}                        // 角色
	role.GetRoleById(user.RoleId)
	roleLevel := role.RoleLevel // 角色等级
	c.Data["roleLevel"] = roleLevel
	c.TplName = "contract/contract_verify.html"
}

/*
添加合同的方法
 */
func (c *ContractController) ContractDoAdd() {
	contract := models.Contract{}
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId")
	// 解析表单
	if err := c.ParseForm(&contract); err != nil {
		res := &uitl.RtMsg{1, "添加失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	fileName := c.GetString("filename") // 文件名
	var fileUrl string = ""             // 文件路径
	if len(fileName) > 0 {
		if !uitl.MoveFileFromTemp(fileName, uitl.CONTRACT) {
			res := &uitl.RtMsg{1, "添加失败,服务器文件未找到!", 0, nil} // 返回的对应的相应数据
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
		fileUrl = "/file/" + uitl.CONTRACT + fileName
	}

	timestr := time.Now()                                                          // 获取当前时间戳
	startTime := c.GetString("StartTime") + " 00:00:00"                            // 开始时间
	endTime := c.GetString("EndTime") + " 00:00:00"                                // 结束时间
	start, _ := time.Parse("2006-01-02 15:04:05", startTime) 					// 解析为时间戳
	end, _ := time.Parse("2006-01-02 15:04:05", endTime)   					// 解析为时间戳
	contract.CreateUser = user.Id                                                  // 用户ID
	contract.Party = companyId.(int)                                               // 公司
	contract.DepartmenId = user.DepartmentId                                       // 部门
	contract.FileUrl = fileUrl                                                     // 文件URL
	contract.UpdateTime = timestr                                                  // 更新时间
	contract.CreateTime = timestr                                                  // 创建时间
	contract.StartTime = start                                                     // 合同开始时间
	contract.EndTime = end                                                         // 合同结束时间

	c_id, err := models.AddContract(&contract) // 添加合同返回合同ID
	if err != nil {
		res := &uitl.RtMsg{1, "添加失败,数据库错误", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	var temp string
	temp = c.GetString("RebateList", "") // 返点列表数据添加
	//rebate := c.Ctx.Input.Param("RebateList")
	if len(temp) > 0 {
		var rebateList []models.Rebate // 返点列表Json解析为Rebate数组
		err = json.Unmarshal([]byte(temp), &rebateList)
		if err != nil {
			models.DeleteContract(int(c_id))                            // 列表添加失败删除对应合同,让他重新添加合同
			res := &uitl.RtMsg{1, "添加失败,代理返点数据解析失败,请重新上传合同数据!", 0, nil} // 返回的对应的相应数据
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
		// 遍历添加数据带到数据库中
		for _, x := range rebateList {
			x.ContractId = int(c_id)
			models.AddRebate(&x)
		}
	}

	res := &uitl.RtMsg{0, "添加成功", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
上传合同文件的方法
 */
func (c *ContractController) ContractUpload() {
	f, h, err := c.GetFile("uploadName") // 文件获取
	if err != nil {
		//log.Fatal("getfile err ", err)
		res := &uitl.RtMsg{1, "上传文件失败!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
	}
	defer f.Close()                                               // 文件流的关闭
	filepath, filename := uitl.GetFilePath(h.Filename, uitl.TEMP) // uuid文件名生成,路径生成
	c.SetSession("isChangeFile", true)                            // 修改文件状态为true
	c.SaveToFile("uploadName", filepath)
	res := &uitl.RtMsg{0, "上传文件成功!", 0, filename} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
}

/*
上传指定合同的文件
 */
func (c *ContractController) ContractUploadById() {
	id, err := c.GetInt(":id")           // 获取合同ID
	f, h, err := c.GetFile("uploadName") // 获取文件
	if err != nil {
		//log.Fatal("getfile err ", err)
		res := &uitl.RtMsg{1, "上传文件失败!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
	}
	defer f.Close()                                                   // 文件i/o流关必
	filepath, filename := uitl.GetFilePath(h.Filename, uitl.CONTRACT) // 生成uuid文件名和文件路径
	c.SaveToFile("uploadName", filepath)
	fileUrl := "/file/" + uitl.CONTRACT + filename
	models.UpdateContractFileUrl(id, fileUrl)
	res := &uitl.RtMsg{0, "上传添加文件成功!", 0, filename} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
}

/*
多条件查询语句,通过map来形成键值对,过滤查询
 */
func (c *ContractController) ContractSelectAll() {
	var err interface{}
	var (
		types               string
		partnner            int
		cooperative_project int
		is_ok               int
		start_time          string
		end_time            string
		keyword             string
		page                int
		limit               int
	)
	user := c.GetSession("CPXERP").(models.User) // 获取用户身份
	companyId := c.GetSession("companyId")       // 获取公司id

	types = c.GetString("Type")          // 合同类型
	partnner, err = c.GetInt("partnner") // 合作方
	if err != nil {
		partnner = 0
	}
	cooperative_project, err = c.GetInt("cooperative_project") // 合作项目
	if err != nil {
		cooperative_project = 0
	}
	is_ok, err = c.GetInt("is_ok") // 审核状态
	if err != nil {
		is_ok = -1
	}
	start_time = c.GetString("start_time") // 开始时间
	end_time = c.GetString("end_time")     // 结束时间
	keyword = c.GetString("keyword")       // 合同编号关键字

	filter := map[string]interface{}{} // 查询条件的设置

	role := models.Role{} // 角色
	role.GetRoleById(user.RoleId)

	if role.RoleLevel == 1 {
		filter["create_user"] = user.Id // 创建合同的用户
	} else if role.RoleLevel == 2 {
		/*
		有待商榷的地方, 部门是否需要过滤商业线
		 */
		//filter["cooperative_project"] = user.BusinessId
		filter["departmen_id"] = user.DepartmentId // 部门
	}
	filter["party"] = companyId // 公司Id

	if len(types) > 0 {
		filter["type"] = types
	}
	if partnner > 0 {
		filter["partnner"] = partnner
	}
	if cooperative_project > 0 {
		filter["cooperative_project"] = cooperative_project
	}
	if is_ok >= 0 {
		filter["is_ok"] = is_ok
	}
	if len(start_time) > 0 {
		filter["start_time__ge"] = start_time
	}
	if len(end_time) > 0 {
		filter["end_time__le"] = end_time
	}
	page, err = c.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err = c.GetInt("limit")
	if err != nil {
		limit = 10
	}
	pageData := models.SelectContract(filter, keyword, page, limit)
	count := models.GetSelectContractCount(filter, keyword)
	res := &uitl.RtMsg{0, "获取数据成功！！", int(count), pageData}
	c.Data["json"] = res
	c.ServeJSON()
}


/*
通过id更新合同的方法
 */
func (c *ContractController) ContractUpdateById() {
	id, err := c.GetInt(":id")                  // 合同id
	contract, err := models.GetContractById(id) // 合同数据对象
	if err != nil {
		c.Abort("404")
	}
	//contract := &models.Contract{}
	user := c.GetSession("CPXERP").(models.User) // 用户身份
	companyId := c.GetSession("companyId")       // 公司ID
	// 解析表单
	if err := c.ParseForm(contract); err != nil {
		res := &uitl.RtMsg{1, "添加失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	fileName := c.GetString("filename")          // 文件名
	isChangeFile := c.GetSession("isChangeFile") // 是否提交修改过文件
	var fileUrl string = ""                      // 文件路径
	if isChangeFile == true { // 修改过,将文件加入文件夹
		if len(fileName) > 0 {
			if !uitl.MoveFileFromTemp(fileName, uitl.CONTRACT) {
				res := &uitl.RtMsg{1, "更新失败,服务器文件未找到!", 0, nil} // 返回的对应的相应数据
				c.Data["json"] = res
				c.ServeJSON()
				return
			}
			fileUrl = "/file/" + uitl.CONTRACT + fileName // 文件的URL
		}
	} else {
		fileUrl = c.GetSession("fileUrl").(string) // 文件的URL没有发生改变
	}
	c.DelSession("isChangeFile") // 删除session
	c.DelSession("fileUrl")      // 删除session
	contract.Id = id
	timestr := time.Now()                                                          // 获取当前时间戳
	startTime := c.GetString("StartTime") + " 00:00:00"                            // 开始时间
	endTime := c.GetString("EndTime") + " 00:00:00"                                // 结束时间
	start, _ := time.Parse("2006-01-02 15:04:05", startTime) // 解析为时间戳
	end, _ := time.Parse("2006-01-02 15:04:05", endTime)     // 解析为时间戳
	contract.CreateUser = user.Id                                                  // 用户ID
	contract.Party = companyId.(int)                                               // 公司
	contract.DepartmenId = user.DepartmentId                                       // 部门
	contract.FileUrl = fileUrl                                                     // 文件URL
	contract.UpdateTime = timestr                                                  // 更新时间
	contract.StartTime = start                                                     // 合同开始时间
	contract.EndTime = end

	// 初始化审核状态
	contract.LeaderIspass = 0
	contract.FinancialIsIntervention = 0
	contract.FinancialIspass = 0
	contract.CeoIspass = 0
	contract.IsOk = 0

	if err := models.UpdateContractById(contract); err != nil {
		res := &uitl.RtMsg{1, "更新失败,数据库错误", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

	rebate := c.GetString("RebateList") // 返点列表数据添加

	// 清空之前的数据,重新添加
	if rebates, _, err := models.GetRebateByConId(id); err == nil {
		for _, x := range rebates {
			models.DeleteRebate(x.Id)
		}
	}
	if len(rebate) > 0 {
		rebateList := []models.Rebate{} // 返点列表Json解析为Rebate数组
		err = json.Unmarshal([]byte(rebate), &rebateList)
		if err != nil {
			models.DeleteContract(int(id))                              // 列表添加失败删除对应合同,让他重新添加合同
			res := &uitl.RtMsg{1, "添加失败,代理返点数据解析失败,请重新上传合同数据!", 0, nil} // 返回的对应的相应数据
			c.Data["json"] = res
			c.ServeJSON()
			return
		}
		// 遍历添加数据带到数据库中
		for _, x := range rebateList {
			x.ContractId = int(id)
			models.AddRebate(&x)
		}
	}

	res := &uitl.RtMsg{0, "更新数据成功, 合同将被重新审核!", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
删除合同的方法
需要有权限
 */
func (c *ContractController) ContractDeleteById() {
	id, err := c.GetInt(":id")							// 合同ID
	contract, err := models.GetContractById(id)				// 合同数据对象
	if err != nil {
		c.Abort("404")
	}
	/*
	相关文件也应该删除
	 */
	filePath := uitl.GetFilePathByUrl(contract.FileUrl, uitl.CONTRACT)
	user := c.GetSession("CPXERP").(models.User)		// 用户身份
	role, _ := models.GetRoleById(user.RoleId)				//角色
	if !(contract.CreateUser == user.Id || role.RoleLevel == 3) {
		res := &uitl.RtMsg{1, "删除数据失败, 你没有该权限!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	// 删除关联的数据
	if rebates, c, err := models.GetRebateByConId(id); err == nil {
		if c != 0 {
			for _, x := range rebates {
				models.DeleteRebate(x.Id)
			}
		}
	}
	// 删除合同
	if err := models.DeleteContract(id); err != nil {
		res := &uitl.RtMsg{1, "删除数据失败, 数据库错误!", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	os.Remove(filePath)
	res := &uitl.RtMsg{0, "删除数据成功!", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
获取带审核列表
不同的用户权限看到的审核数据不同
 */
func (c *ContractController) ContractGetCheckList() {
	user := c.GetSession("CPXERP").(models.User)		// 用户身份
	companyId := c.GetSession("companyId").(int)		// 公司ID
	role := models.Role{}				// 角色
	role.GetRoleById(user.RoleId)
	ctype := c.GetString("cType")		// 合同类型

	page, err := c.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		limit = 10
	}

	var data []orm.Params
	var count int

	filter := map[string]interface{}{}
	filter["party"] = companyId
	filter["type"] = ctype
	if role.RoleLevel == 1 {
		res := &uitl.RtMsg{1, "获取失败,权限不足！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
	} else if role.RoleLevel == 2 {
		/*
		有待商榷的地方, 部门是否需要过滤商业线
		 */
		//filter["cooperative_project"] = user.BusinessId
		filter["departmen_id"] = user.DepartmentId
		filter["leader_ispass"] = 0
		// 查数据 赋值给data
		data = models.SelectContract(filter, "", page, limit)
		count = models.GetSelectContractCount(filter, "")
	} else if role.RoleLevel == 3 {
		index := strings.Index(role.RoleName, "财务")
		if index >= 0 {
			// 这是财务的过滤条件
			filter["leader_ispass"] = 1
			filter["financial_is_intervention"] = 1
			filter["financial_ispass"] = 0
			// 查数据 赋值给data
			data = models.SelectContract(filter, "", page, limit)
			count = models.GetSelectContractCount(filter, "")
		} else {
			// 这是CEO的过滤条件,有两个
			// 这得写两个filter,复制基础map, 一个是财务审核过的,一个是未接手财务的
			// 查两个数据,进行数组拼接,赋值给data
			filter["leader_ispass"] = 1
			filter["ceo_ispass"] = 0

			filter2 := uitl.CopyMap(filter)
			// 财务审核过的数据条件
			filter["financial_is_intervention"] = 1
			filter["financial_ispass"] = 1
			// 不需要财务审核的数据条件
			filter2["financial_is_intervention"] = 0
			data1 := models.SelectContract(filter, "", page, limit)
			count1 := models.GetSelectContractCount(filter, "")
			data2 := models.SelectContract(filter2, "", page, limit)
			count2 := models.GetSelectContractCount(filter2, "")
			data = append(data1, data2...)
			count = count1 + count2
		}
	}
	res := &uitl.RtMsg{0, "获取数据成功!", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
审核通过的方法
 */
func (c *ContractController) ContractDoCheckPass() {
	user := c.GetSession("CPXERP").(models.User)	// 用户身份
	role := models.Role{}								// 角色
	role.GetRoleById(user.RoleId)
	c_id, err := c.GetInt(":id")
	contract, err := models.GetContractById(c_id)   //合同id
	if err != nil {
		c.Abort("404")
	}
	if role.RoleLevel == 1 {		// 普通员工不能操作
		res := &uitl.RtMsg{1, "通过失败,权限不足！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
	} else if role.RoleLevel == 2 {  	// 部门领导
		// 部门领导的操作
		isIntervention, err := c.GetInt("IsIntervention")
		if err != nil {
			isIntervention = 0
		}
		contract.LeaderIspass = 1
		contract.FinancialIsIntervention = int8(isIntervention)
		contract.FinancialIspass = 0
		contract.LeaderId = user.Id
	} else {							// ceo和财务
		index := strings.Index(role.RoleName, "财务")
		if index >= 0 {
			// 这是财务的过滤条件
			contract.FinancialIspass = 1
			contract.FinancialId = user.Id
		} else {
			// CEO的操作
			contract.CeoIspass = 1
			contract.IsOk = 1
			contract.CeoId = user.Id
		}
	}
	// 数据库更新
	if err := models.UpdateContractById(contract); err != nil {
		res := &uitl.RtMsg{1, "通过失败,数据库更新失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
	}
	res := &uitl.RtMsg{0, "通过成功！！", 0, nil}
	c.Data["json"] = res
	c.ServeJSON()
}

/*
审核不通过的方法
 */
func (c *ContractController) ContractDoCheckNotPass() {
	user := c.GetSession("CPXERP").(models.User)		// 用户身份
	role := models.Role{}									//角色
	role.GetRoleById(user.RoleId)
	c_id, err := c.GetInt(":id")
	contract, err := models.GetContractById(c_id)
	if err != nil {
		c.Abort("404")
	}
	var refusal = c.GetString("refusal")
	if role.RoleLevel == 1 {
		res := &uitl.RtMsg{1, "不通过失败,权限不足！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
	} else if role.RoleLevel == 2 {
		// 部门领导的操作
		contract.LeaderIspass = 2
		contract.LeaderId = user.Id
		contract.IsOk = 2
		contract.RefuseInfo = refusal
	} else {
		index := strings.Index(role.RoleName, "财务")
		if index >= 0 {
			// 这是财务的过滤条件
			contract.FinancialIspass = 2
			contract.FinancialId = user.Id
			contract.IsOk = 2
			contract.RefuseInfo = refusal
		} else {
			// CEO的操作
			contract.CeoIspass = 2
			contract.IsOk = 2
			contract.CeoId = user.Id
			contract.RefuseInfo = refusal
		}
	}
	if err := models.UpdateContractById(contract); err != nil {
		res := &uitl.RtMsg{1, "不通过失败,数据库更新失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
	}
	res := &uitl.RtMsg{0, "操作成功！！", 0, nil}
	c.Data["json"] = res
	c.ServeJSON()

}

// Delete ...
// @Title Delete
// @Description delete the Contract
// @Param	id		path 	string	true		"The id you want to delete"
// @Success 200 {string} delete success!
// @Failure 403 id is empty
// @router /:id [delete]
// 修改,需要最高权限进行删除
func (c *ContractController) Delete() {
	idStr := c.Ctx.Input.Param(":id")
	id, _ := strconv.Atoi(idStr)
	if err := models.DeleteContract(id); err == nil {
		c.Data["json"] = "OK"
	} else {
		c.Data["json"] = err.Error()
	}
	c.ServeJSON()
}
