/*
报销详细数据获取控制器
该控制器页面几乎没有,多为js接口
Auth: TTC
Date: 2018-08-21
 */
package controllers

import "github.com/astaxie/beego"

type ReimburseDetailController struct {
	beego.Controller
}
