/*
异动模块控制器
Auth:ttc
Date:2018-09-05
 */
package controllers

import (
	"github.com/astaxie/beego"
	"cpxerp/models"
	"cpxerp/util"
)

// AbnormalChangeController operations for AbnormalChange
type AbnormalChangeController struct {
	beego.Controller
}

/*
申请异动改变
 */
func (c *AbnormalChangeController) AbnormalChangeApplyHtml() {
	user := c.GetSession("CPXERP").(models.User)
	depart := models.SelectAllDepartment()
	c.Data["user"] = user
	c.Data["depart"] = depart
	c.Data["EntryTime"] = user.TimeOfEntry.Format("2006-01-02")
	c.Data["RegularTime"] = user.RegularTime.Format("2006-01-02")
	c.Data["PracticeEndTime"] = user.PracticeEndTime.Format("2006-01-02")
	c.TplName = "abn_change/abnormal_change_apply.html"
}

/*
异动审核页面
 */
func (c *AbnormalChangeController) AbnormalChangeVerifyHtml() {
	c.TplName = "abn_change/abn_change_verify.html"
}

/**
异动审核通过备份信息页面
 */
func (c *AbnormalChangeController) AbnormalChangeListHtml() {
	c.TplName = "abn_change/abn_change_list.html"
}

/**
异动申请添加行为
 */
func (c *AbnormalChangeController) AbnormalChangeApplyDoAdd() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	abnChange := models.AbnormalChange{}
	if err := c.ParseForm(&abnChange); err != nil {
		res := &uitl.RtMsg{1, "添加失败，表单解析错误！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

	abnChange.Applyer = user.Id
	abnChange.CompanyId = companyId
	abnChange.LeaderId = user.Superior
	// 初始化,各种异动操作能够修改的信息有哪些
	if abnChange.ApplyType == "转正" {
		abnChange.IsChangeInfo = 1
		abnChange.IsChangePost = 0
		abnChange.IsChangeSalary = 1
	} else if abnChange.ApplyType == "调薪" {
		abnChange.IsChangeInfo = 1
		abnChange.IsChangePost = 1
		abnChange.IsChangeSalary = 0
	} else if abnChange.ApplyType == "实习转试用" {
		abnChange.IsChangeInfo = 0
		abnChange.IsChangePost = 0
		abnChange.IsChangeSalary = 0
	} else if abnChange.ApplyType == "晋升" {
		abnChange.IsChangeInfo = 1
		abnChange.IsChangePost = 0
		abnChange.IsChangeSalary = 0
	} else if abnChange.ApplyType == "转正延期" || abnChange.ApplyType == "实习延期" {
		abnChange.IsChangeInfo = 1
		abnChange.IsChangePost = 1
		abnChange.IsChangeSalary = 1
	}
	role, err := models.GetRoleById(user.RoleId)
	_, myModule := role.GetModuleMaps(user.RoleId)
	if myModule["deppart_examine"] {		// 如果是部门审核人员的提交需求,部门审核跳过
		abnChange.DepartStatus = 1
	}
	if myModule["persionnel1_examine"] {	// 如果是人事员工提交的需求,部门审核成功,流转到人事
		abnChange.DepartStatus = 1
	}
	if myModule["persionnel2_examine"] {	// 如果是人事经理提交的需求,由CEO进行审核
		abnChange.DepartStatus = 1
		abnChange.PersonnelStatus = 1
	}
	abnChange.LeaderId = user.Superior
	_, err = models.AddAbnormalChange(&abnChange)
	if err != nil {
		res := &uitl.RtMsg{1, "添加失败，数据库错误！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	res := &uitl.RtMsg{0, "添加成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
用户异动申请记录
 */
func (c *AbnormalChangeController) AbnormalChangeSelectByUser() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	filter := map[string]interface{}{}
	filter["applyer"] = user.Id
	filter["company_id"] = companyId
	dates := models.SelectAbnormalChangeByFilter(filter, page, limit)
	count := models.GetAbnormalChangeCountByFilter(filter)
	res := &uitl.RtMsg{0, "查询成功！", count, dates} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
异动待审核申请信息查询
 */
func (c *AbnormalChangeController) AbnormalChangeSelectVerify() {
	user := c.GetSession("CPXERP").(models.User)
	role, err := models.GetRoleById(user.RoleId)
	companyId := c.GetSession("companyId").(int)
	if err != nil {
		c.Abort("404")
	}
	filter := map[string]interface{}{}
	filter["company_id"] = companyId
	filter["is_ok"] = 0
	_, myModule := role.GetModuleMaps(role.RoleId)
	if myModule["deppart_examine"] {
		filter["depart_status"] = 0
		filter["personnel_status"] = 0
		filter["ceo_status"] = 0
		filter["depart_id"] = user.DepartmentId
		filter["leader_id"] = user.Id
	} else if myModule["persionnel1_examine"] || myModule["persionnel2_examine"]{
		filter["depart_status"] = 1
		filter["personnel_status"] = 0
		filter["ceo_status"] = 0
	}  else if myModule["ceo_examine"] {
		filter["depart_status"] = 1
		filter["personnel_status"] = 1
		filter["ceo_status"] = 0
	} else {
		res := &uitl.RtMsg{0, "查询失败,权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	filter["is_ok"] = 0
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	dates := models.SelectAbnormalChangeByFilter(filter, page, limit)
	count := models.GetAbnormalChangeCountByFilter(filter)
	res := &uitl.RtMsg{0, "查询成功！", count, dates} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
异动审核行为
 */
func (c *AbnormalChangeController) AbnormalChangeDoVerify() {
	user := c.GetSession("CPXERP").(models.User)
	role, err := models.GetRoleById(user.RoleId)
	abnChangeId, err := c.GetInt(":id")
	abnChange, err := models.GetAbnormalChangeById(abnChangeId)
	if err != nil {
		c.Abort("404")
	}
	active, err := c.GetInt("active", 1)			// 审核行为,1为通过, 2为不通过
	if err != nil {
		active = 1
	}
	_, myModule := role.GetModuleMaps(role.RoleId)
	if myModule["deppart_examine"] {
		abnChange.DepartStatus = int8(active)
	} else if myModule["persionnel1_examine"] || myModule["persionnel2_examine"] {
		abnChange.PersonnelStatus = int8(active)
	} else if myModule["ceo_examine"] {
		abnChange.CeoStatus = int8(active)
	} else {
		res := &uitl.RtMsg{1, "审核失败,权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	var msg string
	if active == 2 {
		abnChange.IsOk = 2
		msg = "不通过"
	} else {
		msg = "通过"
	}
	if abnChange.DepartStatus == 1 && abnChange.PersonnelStatus == 1 && abnChange.CeoStatus == 1 {
		abnChange.IsOk = 1
	}
	err = models.UpdateAbnormalChangeById(abnChange)
	if err != nil {
		res := &uitl.RtMsg{1, "审核" + msg + "失败！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

	res := &uitl.RtMsg{0, "审核" + msg + "成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
异动通过的备案查询
 */
func (c *AbnormalChangeController) AbnormalChangeSelectHadPass() {
	companyId := c.GetSession("companyId").(int)		// 公司ID
	filter := map[string]interface{}{}						// 过滤条件
	filter["company_id"] = companyId
	filter["is_ok"] = 1
	page, err := c.GetInt("page", 1)				// 页数
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)			// 每页多少行
	if err != nil {
		limit = 10
	}
	dates := models.SelectAbnormalChangeByFilter(filter, page, limit)
	count := models.GetAbnormalChangeCountByFilter(filter)
	res := &uitl.RtMsg{0, "查询成功", count, dates} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}