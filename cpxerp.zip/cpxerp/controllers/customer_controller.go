package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"encoding/json"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"strconv"
	"time"
)

type CustomerController struct {
	beego.Controller
}

/*
打开客户新建页面
*/
func (c *CustomerController) CustomerNewHtml() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	users := user.GetByComIdAndDepartId(companyId, user.DepartmentId)

	buses := models.Business{}
	allBues := buses.FinadAll()
	c.Data["users"] = users
	c.Data["buess"] = allBues
	c.TplName = "customer/customer_new.html"
}

/*
打开客户审核页面
*/
func (c *CustomerController) CustomerExamineHtml() {
	c.TplName = "customer/customer_examine.html"
}

/*
打开客户列表页面
*/
func (c *CustomerController) CustomerSelectHtml() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	role := models.Role{}
	role.GetRoleById(user.RoleId)

	bus := models.Business{}
	cus := models.Customer{}
	businesss := bus.FinadAll()

	customers := cus.GetAllCustomer(companyId, role.RoleLevel, user)
	followUsers := cus.GetAllFollowUser(companyId, role.RoleLevel, user)
	c.Data["businesss"] = businesss
	c.Data["customers"] = customers
	c.Data["followUsers"] = followUsers

	c.TplName = "customer/customer_select.html"
}

/*
查看联系人界面
*/
func (c *CustomerController) ContactsHtml() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		logs.Error(err)
	}
	status, err := strconv.Atoi(c.Ctx.Input.Param(":status"))
	if err != nil {
		logs.Error(err)
	}
	c.Data["id"] = id
	c.Data["status"] = status
	c.TplName = "customer/customer_contacts_list.html"
}

/*
联系人修改界面
*/
func (c *CustomerController) ContactsUpdateHtml() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		fmt.Println(err)
	}
	cus := models.Customer{}
	contact := cus.GetContactsByContactId(id)
	c.Data["contact"] = contact
	c.TplName = "customer/customer_contacts_update.html"
}

/*
提交客户资料数据
*/
func (c *CustomerController) CustomerDoAdd() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	comp := models.Company{}
	company := comp.SelectById(companyId)

	customer := models.Customer{}
	err := c.ParseForm(&customer)
	if err != nil {
		logs.Error("customer formData err", err)
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	startTime := c.GetString("StartTime") + " 00:00:00"
	stime, err := time.Parse("2006-01-02 15:04:05", startTime)
	if err != nil {
		logs.Error("string to time err,", err)
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	customer.StartTime = stime
	customer.CreateTime = time.Now()
	customer.CompanyId = company.Id
	customer.CreateUserId = user.Id
	customer.AuditDepartmentId = user.DepartmentId
	customer.Remarks = "新增"
	contacts := []models.Contact{}
	ss := c.GetString("Contacts")
	err = json.Unmarshal([]byte(ss), &contacts)
	if err != nil {
		logs.Error("json to struct err, ", err)
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return

	}
	customer.Contacts = contacts
	b, err := customer.Add()
	if err != nil {
		fmt.Println("insert customer Data err,", err)
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	if b {
		res := &uitl.RtMsg{0, "添加成功！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "添加失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
修改客户页面
*/
func (c *CustomerController) CustomerUpdateHtml() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	users := user.GetByComIdAndDepartId(companyId, user.DepartmentId)
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		logs.Error(err)
		return
	}
	buses := models.Business{}
	allBues := buses.FinadAll()
	customer := models.Customer{Id: id}
	customer.GetCustomerById()

	allBues1 := checkBusinesssBypSteId(*allBues, customer)
	allBues2 := checkBusinesssByProId(*allBues, customer)

	fmt.Println(allBues)
	fmt.Println(allBues1)
	fmt.Println(allBues2)

	c.Data["users"] = users
	c.Data["buess1"] = allBues1
	c.Data["buess2"] = allBues2
	c.Data["customer"] = customer
	c.TplName = "customer/customer_update.html"
}

func checkBusinesssByProId(business []models.Business, customer models.Customer) []models.Business {
	busis := make([]models.Business, 0)
	for _, v := range business {
		if customer.ProductTypesId == v.BusinessId {
			v.Flag = true
			busis = append(busis, v)
		} else {
			v.Flag = false
			busis = append(busis, v)
		}
	}
	return busis
}
func checkBusinesssBypSteId(business []models.Business, customer models.Customer) []models.Business {
	busis := make([]models.Business, 0)
	for _, v := range business {
		if customer.StepId == v.BusinessId {
			v.Flag = true
			busis = append(busis, v)
		} else {
			v.Flag = false
			busis = append(busis, v)
		}
	}
	return busis
}

/*
修改客户信息
*/
func (c *CustomerController) CustomerDoUpdate() {
	customer := models.Customer{}
	err := c.ParseForm(&customer)
	if err != nil {
		logs.Error("customer formData err", err)
		res := &uitl.RtMsg{1, "修改失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	customer.Remarks = "修改"
	fmt.Println(customer)
	b := customer.UpdateCustomer()
	if b {
		res := &uitl.RtMsg{0, "修改成功！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "修改失败！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
待审核客户数据，分页查询
*/
func (c *CustomerController) CustomerExamineData() {
	companyId := c.GetSession("companyId").(int)
	user := c.GetSession("CPXERP").(models.User)
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	role := models.Role{}
	role.GetRoleById(user.RoleId)

	cus := models.Customer{}
	byPage := cus.GetExamine(page, limit, companyId, role.RoleLevel, user)
	fmt.Println(byPage.Data)
	res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
	c.Data["json"] = res
	c.ServeJSON()
	return

}

/*
审核客户资料
*/
func (c *CustomerController) CustomerDoExamine() {
	user := c.GetSession("CPXERP").(models.User)
	customer := models.Customer{}
	err := c.ParseForm(&customer)
	if err != nil {
		logs.Error("customer formData err", err)
		res := &uitl.RtMsg{1, "系统异常！！", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	customer.AuditUserId = user.Id
	customer.AuditDepartmentId = user.DepartmentId
	if customer.AuditStatus == 1 {
		customer.Remarks = "审核通过"
		b := customer.UpdateAuditStatusById()
		if b {
			res := &uitl.RtMsg{0, "审核通过", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{1, "系统异常", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		}

	}
	if customer.AuditStatus == 2 {
		if customer.Remarks == "" {
			customer.Remarks = "审核未通过"
		}
		b := customer.UpdateAuditStatusById()

		if b {
			res := &uitl.RtMsg{0, "审核未通过", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		} else {
			res := &uitl.RtMsg{1, "系统异常", 0, nil}
			c.Data["json"] = res
			c.ServeJSON()
			return
		}

	}

}

/*
客户资料分页查询，根据权限数据不同，条件查询如此
*/
func (c *CustomerController) GetDatas() {
	companyId := c.GetSession("companyId").(int)
	user := c.GetSession("CPXERP").(models.User)
	page, err := c.GetInt("page")
	if err != nil {
		return
	}
	limit, err := c.GetInt("limit")
	if err != nil {
		return
	}
	datas := c.GetString("datas")
	role := models.Role{}
	role.GetRoleById(user.RoleId)
	if datas == "" {
		cus := models.Customer{}
		byPage := cus.GetAllByPage(page, limit, companyId, role.RoleLevel, user, nil)
		fmt.Println(byPage.Data)
		res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		maps := make(map[string]interface{})
		err := json.Unmarshal([]byte(datas), &maps)
		if err != nil {
			fmt.Println("json to map ", err)
		}
		cus := models.Customer{}
		byPage := cus.GetAllByPage(page, limit, companyId, role.RoleLevel, user, maps)
		fmt.Println(byPage.Data)
		res := &uitl.RtMsg{0, "", byPage.TotalCount, byPage.Data}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
查看客户联系人
*/
func (c *CustomerController) GetContacts() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		logs.Error(err)
	}
	cus := models.Customer{}
	contacts := cus.GetContactsByCustomerId(id)
	res := &uitl.RtMsg{0, "", 0, contacts}
	c.Data["json"] = res
	c.ServeJSON()
	return
}

/*
 删除客户联系人
*/
func (c *CustomerController) DoDelContact() {
	id, err := c.GetInt("id")
	if err != nil {
		logs.Error(err)
	}
	cus := models.Customer{}
	b := cus.DelContactById(id)
	if b {
		res := &uitl.RtMsg{0, "删除成功", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "删除失败", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}

}

/*
修改联系人
*/
func (c *CustomerController) DoUpdateContact() {
	contact := models.Contact{}
	err := c.ParseForm(&contact)
	if err != nil {
		logs.Error("contact form data err,", err)
	}
	cus := models.Customer{}
	b := cus.UpdateContactById(contact)
	if b {
		res := &uitl.RtMsg{0, "修改成功", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "修改失败", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}

/*
新增联系人界面
*/
func (c *CustomerController) ContactsAddHtml() {
	id, err := strconv.Atoi(c.Ctx.Input.Param(":id"))
	if err != nil {
		logs.Error(err)
	}
	c.Data["customerId"] = id
	c.TplName = "customer/customer_contacts_addnew.html"
}

/*
新增联系人
*/
func (c *CustomerController) ContactsDoAdd() {
	contact := models.Contact{}
	err := c.ParseForm(&contact)
	if err != nil {
		logs.Error("contact formData err", err)
	}
	cus := models.Customer{}
	b := cus.AddContact(contact)
	if b {
		res := &uitl.RtMsg{0, "新增成功", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{1, "新增失败", 0, nil}
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
}
