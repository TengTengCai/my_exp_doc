package controllers

import (
	"github.com/astaxie/beego"
	"cpxerp/models"
	"cpxerp/util"
	"fmt"
	"time"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"strings"
)

// PurchaseController operations for Purchase
type PurchaseController struct {
	beego.Controller
}

func (c *PurchaseController) PurchaseApplyHtml() {
	user := c.GetSession("CPXERP").(models.User)
	depart := models.SelectAllDepartment()
	c.Data["user"] = user
	c.Data["depart"] = depart
	c.TplName = "purchase/purchase_apply.html"
}

func (c *PurchaseController) PurchaseExamineHtml() {
	c.TplName = "purchase/purchase_examine.html"
}

func (c *PurchaseController) PurchaseListHtml() {
	c.TplName = "purchase/purchase_list.html"
}

func (c *PurchaseController) PurchaseApplyDoAdd() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	departId, err := c.GetInt("depart")
	applyTime := c.GetString("applyTime")
	depart, err := models.GetDepartmentById(departId)
	fmt.Println(departId, applyTime)
	f, h, err := c.GetFile("uploadName") // 文件获取
	if err != nil {
		//log.Fatal("getfile err ", err)
		logs.Error(err)
		c.Abort("400")
	}
	if f != nil {
		defer f.Close() // 文件流的关闭
	}
	index := strings.LastIndex(h.Filename, ".")
	suffix := h.Filename[index:]
	fileName := applyTime + depart.DepartmentName + user.Name + "采购单" + suffix
	filePath, uFileName := uitl.GetFilePath(fileName, uitl.TEMP) // uuid文件名生成,路径生成
	c.SetSession("isChangeFile", true)                           // 修改文件状态为true
	c.SaveToFile("uploadName", filePath)
	fileUrl := "/file/" + uitl.TEMP + uFileName
	purchase := models.Purchase{}
	purchase.Applier = user.Id
	purchase.FileUrl = fileUrl
	purchase.ApplyTime, _ = time.ParseInLocation("2006-01", applyTime, time.Local)
	purchase.DepartId = departId
	purchase.FilePath = filePath
	purchase.CompanyId = companyId
	purchase.FileName = fileName
	//purchase.UFileName = uFileName
	_, err = models.AddPurchase(&purchase)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "添加申请成功！", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

func (c *PurchaseController) PurchaseSelectByUser() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	filter := map[string]interface{}{}
	filter["applier"] = user.Id
	filter["company_id"] = companyId
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	data, err := models.SelectPurchaseByFilter(filter, page, limit, orm.NewOrm())
	count, err := models.GetPurchaseCountByFilter(filter, orm.NewOrm())
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "数据获取成功！", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

func (c *PurchaseController) PurchaseSelectExamine() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	if err != nil {
		logs.Error(err)
		c.Abort("400")
	}
	if !(myModule["persionnel1_examine"] || myModule["persionnel2_examine"]) {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	filter := map[string]interface{}{}
	filter["company_id"] = companyId
	filter["examine_status"] = 0
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	data, err := models.SelectPurchaseByFilter(filter, page, limit, orm.NewOrm())
	count, err := models.GetPurchaseCountByFilter(filter, orm.NewOrm())
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "数据获取成功！", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

func (c *PurchaseController) PurchaseDoExamine() {
	user := c.GetSession("CPXERP").(models.User)
	action, err := c.GetInt("action")
	purchaseId, err := c.GetInt(":id")
	purchase, err := models.GetPurchaseById(purchaseId)
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	if err != nil {
		logs.Error(err)
		c.Abort("400")
	}
	if !(myModule["persionnel1_examine"] || myModule["persionnel2_examine"]) {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	var msg = "通过"
	if action == 2 {
		reason := c.GetString("reason")
		purchase.RefuseReason = reason
		msg = "不通过"
	}
	if action == 1 {
		filePath := purchase.FilePath
		index := strings.LastIndex(filePath, "/")
		uFileName := filePath[index+1:]
		filePath = "/CPXERP/" + uitl.PURCHASE + uFileName
		fileUrl := "/file/" + uitl.PURCHASE + uFileName
		uitl.MoveFileFromTemp(uFileName, uitl.PURCHASE)
		purchase.FilePath = filePath
		purchase.FileUrl = fileUrl
	}
	purchase.ExamineStatus = int8(action)
	purchase.Personnel = user.Name
	err = models.UpdatePurchaseById(purchase)
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "审核"+msg+"操作成功!", 0, nil} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}

func (c *PurchaseController) PurchaseSelectHadPass() {
	user := c.GetSession("CPXERP").(models.User)
	companyId := c.GetSession("companyId").(int)
	applyTime := c.GetString("ApplyTime")
	role, err := models.GetRoleById(user.RoleId)
	err, myModule := role.GetModuleMaps(role.RoleId)
	if err != nil {
		logs.Error(err)
		c.Abort("400")
	}
	if !(myModule["persionnel1_examine"] || myModule["persionnel2_examine"]) {
		res := &uitl.RtMsg{1, "权限不足！", 0, nil} // 返回的对应的相应数据
		c.Data["json"] = res
		c.ServeJSON()
		return
	}
	if len(applyTime) <= 0 {
		applyTime = time.Now().Format("2006-01") + "-01"
	}else {
		applyTime += "-01"
	}
	filter := map[string]interface{}{}
	filter["company_id"] = companyId
	filter["apply_time"] = applyTime
	filter["examine_status"] = 1
	page, err := c.GetInt("page", 1)
	if err != nil {
		page = 1
	}
	limit, err := c.GetInt("limit", 10)
	if err != nil {
		limit = 10
	}
	data, err := models.SelectPurchaseByFilter(filter, page, limit, orm.NewOrm())
	count, err := models.GetPurchaseCountByFilter(filter, orm.NewOrm())
	if err != nil {
		logs.Error(err)
		c.Abort("500")
	}
	res := &uitl.RtMsg{0, "数据获取成功!", count, data} // 返回的对应的相应数据
	c.Data["json"] = res
	c.ServeJSON()
	return
}
