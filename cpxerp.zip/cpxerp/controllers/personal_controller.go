package controllers

import (
	"cpxerp/models"
	"cpxerp/util"
	"github.com/astaxie/beego"
	"time"
)

type PersonalController struct {
	beego.Controller
}

/*
个人模块中通知页面
*/
func (p *PersonalController) NoticeHtml() {
	p.TplName = "personal/personal_notice.html"
}

/*
个人模块中查询公司现有通知，按时间排序，最新的在前
*/
func (p *PersonalController) NoticeList() {
	page, err := p.GetInt("page")
	if err != nil {
		return
	}
	limit, err := p.GetInt("limit")
	if err != nil {
		return
	}
	companyId := p.GetSession("companyId").(int)
	notice := models.Notice{}
	selectAll := notice.SelectExamineOKAll(companyId, page, limit)
	res := &uitl.RtMsg{0, "", selectAll.TotalCount, selectAll.Data}
	p.Data["json"] = res
	p.ServeJSON()
	return
}

func (p *PersonalController) InternalHtml() {
	p.TplName = "personal/internal_recruit.html"
}

func (p *PersonalController) InternalSelect() {
	companyId := p.GetSession("companyId")
	page, err := p.GetInt("page")
	if err != nil {
		page = 1
	}
	limit, err := p.GetInt("limit")
	if err != nil {
		limit = 10
	}
	filter := map[string]interface{}{}
	filter["ceo_is_pass"] = 1
	filter["is_had_recruit"] = 0
	filter["is_internal"] = 1
	filter["company_id"] = companyId
	dates := models.SelectRecruitByFilter(filter, "create_time", page, limit)
	count := models.GetRecruitCountByFilter(filter)
	res := &uitl.RtMsg{0, "加载数据成功!", count, dates}
	p.Data["json"] = res
	p.ServeJSON()
	return
}

/*
个人年假查询页面
*/
func (p *PersonalController) AnnualLeaveHtml() {
	p.TplName = "personal/personal_annual_leave.html"
}

/*
个人年假查询数据
*/
func (p *PersonalController) AnnualLeave() {
	user := p.GetSession("CPXERP").(models.User)
	leave := models.AnnualLeave{}
	leave.UserId = user.Id
	annualLeave := leave.SelectByUserId()
	if annualLeave != nil {
		as := [1]models.AnnualLeave{}
		as[0] = *annualLeave
		res := &uitl.RtMsg{0, "", 1, as}
		p.Data["json"] = res
		p.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	}

}

//个人工资条查询页面
func (p *PersonalController) PayrollHtml() {
	p.TplName = "personal/personal_payroll.html"
}

//个人工资条
func (p *PersonalController) Payroll() {
	companyId := p.GetSession("companyId").(int)
	user := p.GetSession("CPXERP").(models.User)
	paymonth := p.GetString("pay_month")
	if paymonth == "" {
		paymonth = time.Now().Format("2006-01")
	}
	payroll := models.Payroll{}
	payroll.UserId = user.Id
	pay := payroll.SelectBySelf(companyId, paymonth)
	if pay != nil {
		res := &uitl.RtMsg{0, "", 1, pay}
		p.Data["json"] = res
		p.ServeJSON()
		return
	} else {
		res := &uitl.RtMsg{0, "", 0, nil}
		p.Data["json"] = res
		p.ServeJSON()
		return
	}
}
