package main

import (
	"cpxerp/models"
	_ "cpxerp/routers"
	"cpxerp/timerTask"
	util "cpxerp/util"
	"crypto/md5"
	"encoding/json"
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/context"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"github.com/astaxie/beego/plugins/cors"
	"strings"
)

func init() {

	dbAlias := beego.AppConfig.String("db_alias")
	dbUser := beego.AppConfig.String("mysqlsuer")
	dbPwd := beego.AppConfig.String("mysqlpass")
	dbName := beego.AppConfig.String("musqldb")
	dbUrl := beego.AppConfig.String("mysqlurls")
	dbPort := beego.AppConfig.String("dbport")
	//重新运行时是否覆盖原表创建,false:不会删除原表,修改表信息时将会在原来的基础上修改，true删除原表重新创建
	coverDb, _ := beego.AppConfig.Bool("cover_db")

	orm.RegisterDriver("mysql", orm.DRMySQL)

	dataSource := util.StringsJoin(dbUser, ":", dbPwd, "@tcp(", dbUrl, ":", dbPort, ")", "/", dbName, "?charset=", "utf8&parseTime=true&loc=Local")
	orm.RegisterDataBase(dbAlias, "mysql", dataSource)
	orm.RegisterModel(new(models.User))
	//自动建表
	orm.RunSyncdb(dbAlias, coverDb, true)
}

func main() {
	ignoreCheck()
	//打开日志记录
	beego.BConfig.Log.AccessLogs = true
	orm.Debug = true

	config := make(map[string]interface{})
	config["filename"] = beego.AppConfig.String("fileUpPath") + "log.out"
	config["level"] = logs.LevelDebug
	configStr, err := json.Marshal(config)
	if err != nil {
		fmt.Println("marshal failed, err:", err)
		return
	}
	logs.SetLogger(logs.AdapterFile, string(configStr))
	logs.Debug("main.go", "日志系统启动")
	go task()
	beego.Run()

}

//定时任务初始化
func task() {
	go timerTask.Task1()
	go timerTask.Task2()
	go timerTask.Task3()
}

func ignoreCheck() {
	beego.InsertFilter("*", beego.BeforeRouter, cors.Allow(&cors.Options{
		AllowAllOrigins:  true,
		AllowMethods:     []string{"*"},
		AllowHeaders:     []string{"Origin", "Authorization", "Access-Control-Allow-Origin", "Access-Control-Allow-Headers", "Content-Type"},
		ExposeHeaders:    []string{"Content-Length", "Access-Control-Allow-Origin", "Access-Control-Allow-Headers", "Content-Type"},
		AllowCredentials: true,
	}))
	beego.InsertFilter("/", beego.BeforeRouter, ToMain)
	beego.InsertFilter("/erp/*", beego.BeforeRouter, CheckLogin)
	beego.InsertFilter("/file/*", beego.BeforeRouter, CheckFileUp)
}

func ToMain(ctx *context.Context) {
	ctx.Redirect(302, "/erp/index")
}

func CheckLogin(ctx *context.Context) {
	_, ok := ctx.Input.Session("CPXERP").(models.User)
	if !ok && ctx.Request.RequestURI != "/login" {
		ctx.Redirect(302, "/login")
	}
}

func CheckFileUp(ctx *context.Context) {
	_, ok := ctx.Input.Session("CPXERP").(models.User)
	s := ctx.Request.RequestURI
	if !ok || strings.Index(s, "/file") < 0 {
		ctx.Redirect(302, "/login")
	} else {
		md5r := ctx.Request.Header.Get("md5")
		md5s := fmt.Sprintf("%x", md5.Sum([]byte("29571935")))
		if md5r == md5s {
			fmt.Println("ok")
		} else {
			return
		}
	}
}
