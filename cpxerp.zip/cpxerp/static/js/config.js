// var fileUpUrl='http://67.209.186.58:80/file/fileUpload'
// var picUpUrl='http://67.209.186.58:80/file/picUpload'

var fileUpUrl='http://www.vvlgo.com/file/fileUpload';
var picUpUrl='http://www.vvlgo.com/file/picUpload';


// var fileUpUrl='http://127.0.0.1:80/file/fileUpload'
//
// var picUpUrl='http://127.0.0.1:80/file/picUpload'
function getFileUpUrl() {
    return fileUpUrl;
}

function getPicUpUrl() {
    return picUpUrl;
}