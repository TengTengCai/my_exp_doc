/**
 * 合同的审核界面的js文件
 */
$(function () {
    var cType = $("#contract_type option:selected").val();  // 合同类型
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var formSelects = layui.formSelects;
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        // 表单初始化
        // form.render();

        /*
        表格数据初始化
         */
        var tableIns = table.render({
            elem: '#verifyTable',
            url: '/erp/contract/contractSelectCheck',
            where: {
                cType: cType
            },
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'contractTable',
            cols: [[
                {fixed: 'left', event: 'detail', field: 'contract_code', width: '80', align: 'center', title: '合同编号'},
                {field: 'type', width: '80', align: 'center', title: '合同类型'},
                {field: 'company_name', width: '100', align: 'center', title: '缔约方'},
                {field: 'customer_name', width: '100', align: 'center', title: '合作方'},
                {field: 'business_name', width: '100', align: 'center', title: '合作项目'},
                {field: 'channel', width: '100', align: 'center', title: '合作渠道'},
                {field: 'project_type', width: '100', align: 'center', title: '项目类型'},
                {field: 'start_time', width: '100', align: 'center', title: '开始时间'},
                {field: 'end_time', width: '100', align: 'center', title: '结束时间'},
                {field: 'payment_method', width: '100', align: 'center', title: '付款方式'},
                {field: 'payment_currency', width: '100', align: 'center', title: '付款币种'},
                {field: 'account_period', width: '100', align: 'center', title: '账期'},
                {field: 'invoice_tax', width: '100', align: 'center', title: '开票税点'},
                {field: 'is_include_tax', width: '100', align: 'center', title: '含税'},
                {field: 'discount', width: '100', align: 'center', title: '折扣'},
                {field: 'user_name', width: '100', align: 'center', title: '创建人'},
                {field: 'create_time', width: '100', align: 'center', title: '创建时间'},
                {field: 'update_time', width: '100', align: 'center', title: '更新时间'},
                {field: 'department_name', width: '100', align: 'center', title: '部门'},
                {field: 'remark', width: '80', align: 'center', title: '备注'},
                {
                    field: 'file_url', width: '80', align: 'center', title: '文件',
                    templet: getFile
                },
                {field: 'leader_name', width: '100', align: 'center', title: '部门审核人'},
                {field: 'financial_name', width: '100', align: 'center', title: '财务审核人'},
                {field: 'ceo_name', width: '110', align: 'center', title: 'CEO审核人'},
                {
                    fixed: 'right', field: 'leader_ispass', width: '80', align: 'center', title: '部门审核',
                    templet: leaderCheck
                },
                {
                    fixed: 'right', field: 'financial_ispass', width: '80', align: 'center', title: '财务审核',
                    templet: financialCheck
                },
                {
                    fixed: 'right', field: 'ceo_ispass', width: '80', align: 'center', title: 'ceo审核',
                    templet: ceoCheck
                },
                {
                    fixed: 'right', field: 'is_ok', width: '80', align: 'center', title: '审核状态',
                    templet: checkTemplate
                },
                {fixed: 'right' ,width: '170',title: '操作', toolbar: "#barDemo", align: 'center', }
            ]],
            page: true
        });
        // select选择事件
        form.on("select(cType)", function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            // 表格数据重新加载
            cType = data.value;
            // alert(cType);
            tableIns.reload({
                url: '/erp/contract/contractSelectCheck',
                where: {
                    cType: data.value
                },
            });
        });
        /*
        表格工具
         */
        table.on('tool(verify_list)', function (obj) {
            var data = obj.data;
            var con_id = data.id;
            console.log(data);
            var mydata = {};
            if (obj.event === 'pass') {
                var roleLevel = $("#roleLevel").val();
                console.log(roleLevel);
                if (roleLevel == 2) {
                    layer.confirm("是否需要财务协助审核?", {
                        btn: ['需要', '不需要', '取消'],
                        yes: function (index, layero) {
                            mydata.IsIntervention = 1;
                            checkPass(con_id, mydata);
                            layer.close(index)
                        },
                        btn2: function (index, layero) {
                            mydata.IsIntervention = 0;
                            checkPass(con_id, mydata);
                            layer.close(index)
                        },
                        btn3: function (index, layero) {
                            layer.close(index)
                        }
                    })
                }else {
                    checkPass(con_id, mydata)
                }
            }
            if (obj.event === 'not_pass') {
                console.log(roleLevel);
                layer.prompt({
                    formType: 2,
                    value: '',
                    title: '请输入不通过理由',
                    area: ['400px', '350px'] //自定义文本域宽高
                }, function(value, index, elem){
                    mydata.refusal = value;
                    checkNotPass(con_id, mydata);
                    layer.close(index);
                });
            }
            /*
        审核通过的方法
         */
            function checkPass(id, mydata) {
                $.ajax({
                    url: '/erp/contract/contractCheckPass/'+id,
                    type: 'post',
                    data: mydata,
                    success: function (data) {
                        if (data.code === 0){
                            layer.alert(data.msg, {icon: 1});
                        } else {
                            layer.alert(data.msg, {icon: 2});
                        }
                        tableIns.reload({
                            where: {
                                cType: cType
                            },
                            page: {
                                curr: 1 //重新从第 1 页开始
                            }
                        });
                    }
                })
            }
            /*
            审核不通过的方法
             */
            function checkNotPass(id, mydata) {
                $.ajax({
                    url: '/erp/contract/contractCheckNotPass/'+id,
                    type: 'post',
                    data: mydata,
                    success: function (data) {
                        if (data.code === 0){
                            layer.alert(data.msg, {icon: 1});
                        }else {
                            layer.alert(data.msg, {icon: 2});
                        }
                        tableIns.reload({
                            where: {
                                cType: cType
                            },
                            page: {
                                curr: 1 //重新从第 1 页开始
                            }
                        });
                    }
                })
            }
        });

        /**
         * 审核状态由数字变为对应标签
         * @param d 行数据
         * @returns {string} 返回对应标签
         */
        function checkTemplate(d) {
            console.log(d.is_ok);
            if (d.is_ok === "0") {
                return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'
            } else if (d.is_ok === "1") {
                return '<button class="layui-btn layui-btn-xs">通过</button>'
            } else if (d.is_ok === "2") {
                return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
            }
        }


        /**
         * 部门领导审核状态
         * @param d 行数据
         * @returns {string} 返回对应的标签
         */
        function leaderCheck(d) {
            if (d.leader_ispass === "0") {
                return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'
            } else if (d.leader_ispass === "1") {
                return '<button class="layui-btn layui-btn-xs">通过</button>'
            } else if (d.leader_ispass === "2") {
                return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
            }
        }

        /**
         * 财务协助审核,当不需要协助时不显示,需要时显示对应状态按钮
         * @param d 行数据
         * @returns {string} 返回对应的标签
         */
        function financialCheck(d) {
            if (d.financial_is_intervention === "1") {
                if (d.leader_ispass === "0") {
                    return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'
                } else if (d.leader_ispass === "1") {
                    return '<button class="layui-btn layui-btn-xs">通过</button>'
                } else if (d.leader_ispass === "2") {
                    return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
                }
            } else {
                return '<button class="layui-btn layui-btn-xs layui-btn-disabled">不接手</button>'
            }
        }

        /**
         * CEO审核状态
         * @param d 行数据
         * @returns {string} 对应标签
         */
        function ceoCheck(d) {
            if (d.ceo_ispass === "0") {
                return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'
            } else if (d.ceo_ispass === "1") {
                return '<button class="layui-btn layui-btn-xs">通过</button>'
            } else if (d.ceo_ispass === "2") {
                return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
            }
        }

        /**
         * 获取文件标签
         * @param d 行数据
         * @returns {string} 对应标签
         */
        function getFile(d) {
            if (d.file_url === "") {
                return '无'
            } else {
                return '<a class="layui-btn layui-btn-xs" target="_blank" href="'+d.file_url+'">下载</a>'
            }
        }
    });
});