/**
 * 采购合同列表展示页面
 * Auth: TTC
 * Date: 2018-08-16
 */
$(function () {
    var selectData = {};  // 全局查询数据
    var types = $("#c_type").val();
    // console.log(types);
    /**
     * 初始化layui框架和控件
     */
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , upload = layui.upload
            , layer = layui.layer;

        // 时间控件
        laydate.render({
            elem: "#start_time",    // 标签id
            done: function (value, date, endDate) {
                selectData.start_time = value;
                // console.log(value); //得到日期生成的值，如：2017-08-18
                // console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
                // console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
                doSelect(selectData, false)
            }
        });
        // 时间控件
        laydate.render({
            elem: "#end_time",      // 标签id
            done: function (value, date, endDate) {
                selectData.end_time = value;
                // console.log(value); //得到日期生成的值，如：2017-08-18
                // console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
                // console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
                doSelect(selectData, false)
            }
        });
        // 表格初始化
        table.render({
            elem: '#contractTable',
            url: '/erp/contract/contractSelect',
            where: {
              Type: types
            },
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'contractTable',
            cols: [[
                {fixed: 'left', event: 'detail', field: 'contract_code', width: '80', align: 'center', title: '合同编号'},
                {field: 'type', width: '80', align: 'center', title: '合同类型'},
                {field: 'company_name', width: '100', align: 'center', title: '缔约方'},
                {field: 'customer_name', width: '100', align: 'center', title: '合作方'},
                {field: 'business_name', width: '100', align: 'center', title: '合作项目'},
                {field: 'channel', width: '100', align: 'center', title: '合作渠道'},
                {field: 'project_type', width: '100', align: 'center', title: '项目类型'},
                {field: 'start_time', width: '120', align: 'center', templet: setSTimeType, title: '开始时间'},
                {field: 'end_time', width: '120', align: 'center', templet: setETimeType,title: '结束时间'},
                {field: 'payment_method', width: '100', align: 'center', title: '付款方式'},
                {field: 'payment_currency', width: '100', align: 'center', title: '付款币种'},
                {field: 'account_period', width: '100', align: 'center', title: '账期'},
                {field: 'invoice_tax', width: '100', align: 'center', title: '开票税点'},
                {field: 'is_include_tax', width: '100', align: 'center', title: '含税'},
                {field: 'discount', width: '100', align: 'center', title: '折扣'},
                {field: 'user_name', width: '100', align: 'center', title: '创建人'},
                {field: 'create_time', width: '100', align: 'center', title: '创建时间'},
                {field: 'update_time', width: '100', align: 'center', title: '更新时间'},
                {field: 'department_name', width: '100', align: 'center', title: '部门'},
                {field: 'remark', width: '80', align: 'center', title: '备注'},
                {
                    field: 'file_url', width: '80', align: 'center', title: '文件',
                    templet: getFile
                },
                {field: 'leader_name', width: '100', align: 'center', title: '部门审核人'},
                {field: 'financial_name', width: '100', align: 'center', title: '财务审核人'},
                {field: 'ceo_name', width: '110', align: 'center', title: 'CEO审核人'},
                {
                    fixed: 'right', field: 'leader_ispass', width: '80', align: 'center', title: '部门审核',
                    templet: leaderCheck
                },
                {
                    fixed: 'right', field: 'financial_ispass', width: '80', align: 'center', title: '财务审核',
                    templet: financialCheck
                },
                {
                    fixed: 'right', field: 'ceo_ispass', width: '80', align: 'center', title: 'ceo审核',
                    templet: ceoCheck
                },
                {
                    fixed: 'right', field: 'is_ok', width: '80', align: 'center', title: '审核状态',
                    templet: checkTemplate
                },
            ]],
            page: true,
            done: function(res, curr, count){
                //如果是异步请求数据方式，res即为你接口返回的信息。
                //如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
                // console.log(res);

                //得到当前页码
                // console.log(curr);

                //得到数据总量
                // console.log(count);
                upload.render({
                    elem: '.upload_btn',
                    field: 'uploadName',
                    size: 60 * 1024, //限制文件大小60MB，单位 KB
                    accept: 'file', //普通文件
                    acceptMime: 'application/pdf',  // pdf
                    exts: 'pdf', //只允许上传压缩文件
                    done: function(res, index, upload){ //上传后的回调
                        table.reload('contractTable', {
                            url: '/erp/contract/contractSelect',
                        });
                        layer.closeAll('loading'); //关闭loading
                    },
                    error: function(res, index, upload){ //上传后的回调
                        layer.closeAll('loading'); //关闭loading
                    }
                });
            },
        });
        // 表格点击事件
        table.on('tool(contract_list)', function (obj) {
            var layEvent = obj.event;
            var id = obj.data.id;
            if (layEvent === 'detail') {
                // isOk 为0 时为带审批,不能进行修改
                layui.use('layer', function () {
                    layer.open({
                        type: 2,
                        title: "合同详细信息",
                        maxmin: true,
                        shadeClose: true, //点击遮罩关闭层
                        scrollbar: true,
                        area: ['1000px', '600px'],
                        content: '/erp/contract/contractDetail/' + id,
                        end: function(index, layero){
                            table.reload('contractTable', {
                                url: '/erp/contract/contractSelect',
                            });
                        }
                    });
                });
            }
        });
        // 选择框选择事件
        form.on('select(customer)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            selectData.partnner = data.value;
            doSelect(selectData, false)
        });
        // 选择框选择事件
        form.on('select(project)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            selectData.cooperative_project = data.value;
            doSelect(selectData, false)
        });
        // 选择框选择事件
        form.on('select(is_ok)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            selectData.is_ok = data.value;
            doSelect(selectData, false)
        });
        // 表单提交事件
        form.on('submit(doSearch)', function (data) {
            // console.log(data.elem) //被执行事件的元素DOM对象，一般为button对象
            // console.log(data.form) //被执行提交的form对象，一般在存在form标签时才会返回
            // console.log(data.field) //当前容器的全部表单字段，名值对形式：{name: value}
            doSelect(data, true)
        });
        // 禁用表单提交默认行为
        $('#contract_list_form').on('submit', function (event) {
            event.preventDefault();
            return
        });

        /**
         * 数据搜索,表格重新加载
         * @param data  查询数据
         * @param islayui 是否是layui的表单提交
         */
        function doSelect(data, islayui) {
            var mydata = {};
            if (islayui) {
                mydata = data.field;
            } else {
                mydata = data
            }
            table.reload('contractTable', {
                url: '/erp/contract/contractSelect',
                type: 'get',
                where: mydata, //设定异步数据接口的额外参数
                page: {
                    curr: 1 //重新从第 1 页开始
                }
            });
        }

        /**
         * 审核状态由数字变为对应标签
         * @param d 行数据
         * @returns {string} 返回对应标签
         */
        function checkTemplate(d) {
            if (d.is_ok === "0") {
                return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'
            } else if (d.is_ok === "1") {
                return '<button class="layui-btn layui-btn-xs">通过</button>'
            } else if (d.is_ok === "2") {
                return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
            }
        }

        /**
         * 部门领导审核状态
         * @param d 行数据
         * @returns {string} 返回对应的标签
         */
        function leaderCheck(d) {
            if (d.leader_ispass === "0") {
                return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'
            } else if (d.leader_ispass === "1") {
                return '<button class="layui-btn layui-btn-xs">通过</button>'
            } else if (d.leader_ispass === "2") {
                return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
            }
        }

        /**
         * 财务协助审核,当不需要协助时不显示,需要时显示对应状态按钮
         * @param d 行数据
         * @returns {string} 返回对应的标签
         */
        function financialCheck(d) {
            if (d.financial_is_intervention === "1") {
                if (d.financial_ispass === "0") {
                    return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'
                } else if (d.financial_ispass === "1") {
                    return '<button class="layui-btn layui-btn-xs">通过</button>'
                } else if (d.financial_ispass === "2") {
                    return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
                }
            } else {
                return '<button class="layui-btn layui-btn-xs layui-btn-disabled">不接手</button>'
            }
        }

        /**
         * CEO审核状态
         * @param d 行数据
         * @returns {string} 对应标签
         */
        function ceoCheck(d) {
            if (d.ceo_ispass === "0") {
                return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'
            } else if (d.ceo_ispass === "1") {
                return '<button class="layui-btn layui-btn-xs">通过</button>'
            } else if (d.ceo_ispass === "2") {
                return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
            }
        }

        /**
         * 获取文件标签
         * @param d 行数据
         * @returns {string} 对应标签
         */
        function getFile(d) {
            if (d.file_url === "") {
                // 这里渲染了文件上传的URL地址,每个合同的上传地址都不相同
                return '<button class="layui-btn layui-btn-xs layui-btn-normal upload_btn" lay-data="{url: \'/erp/contract/contractUploadById/'+d.id+'\'}">上传</button>'
            } else {
                return '<a class="layui-btn layui-btn-xs" target="_blank" href="'+d.file_url+'">下载</a>'
            }
        }

        /**
         * 设置结束时间格式
         * @param d
         * @returns {*}
         */
        function setETimeType(d) {
            if (d.end_time !== "") {
                return d.end_time.slice(0,10)
            }
            return ''
        }

        /**
         * 设置开始时间格式
         * @param d
         * @returns {*}
         */
        function setSTimeType(d) {
            if (d.start_time !== "") {
                return d.start_time.slice(0,10)
            }
            return ''
        }
    });

});