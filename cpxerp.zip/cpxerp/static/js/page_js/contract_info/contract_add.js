/**
 * 合同添加JS文件
 * Auth: TTC
 * Date: 2018-8-14
 */
$(function () {
    var cp_name = $("#cp_select option:selected").text();
    var cp_project = "";
    console.log(cp_name);
    setHideDiv(cp_name);
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var formSelects = layui.formSelects;
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        laydate.render({
            elem: '#start_time'
        });

        laydate.render({
            elem: '#end_time'
        });


        table.render({
            elem: '#rebate'
            , cols: [[ //标题栏
                {field: 'cycle', title: '周期', width: 80}
                , {field: 'lower', title: '标准下线', width: 100}
                , {field: 'upper', title: '标准上线', width: 100}
                , {field: 'rebate_point', title: '返点比例', width: 100}
                , {field: 'condition', title: '条件', width: 200}
                , {field: 'ranges', title: '范围', width: 200}
                , {fixed: 'right', title: '操作', width: 80, toolbar: '#toolbar'}
            ]],
            data: []
        });

        table.on('tool(rebate)', function (obj) {
            if (obj.event === 'del') {
                layer.confirm('是否确定删除该行?', function (index) {
                    obj.del();
                    layer.close(index);
                });
                console.log(table.cache.rebate)
            }
        });

        form.on('select(cp_select)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            var index = data.value;
            var dom = data.elem;
            cp_project = dom[index-1].text;
            setHideDiv(cp_project);
        });


        $('#add_rebate').on('click', function () {
            var tableContent = table.cache.rebate;
            var cycle = $('#cycle_select option:selected').val();
            var lower = $('#lower_input').val();
            var upper = $('#upper_input').val();
            var rebate = $('#rebate_input').val();
            var conditions = formSelects.value('condition', 'val');
            var ranges = formSelects.value('ranges', 'val');
            if (cycle === "" || lower === "" || upper === "" ||
                rebate === "" || conditions.length <= 0 || ranges.length <= 0) {
                layer.msg('输入不能为空');
                return
            }
            lower = parseFloat(lower);
            upper = parseFloat(upper);
            rebate = parseFloat(rebate);
            if ( lower > upper) {
                layer.msg('下限不能高于上限');
                return
            }
            conditions = conditions.join(',');
            ranges = ranges.join(',');
            // console.log(conditions);
            tableContent.push({
                cycle: cycle,
                lower: lower,
                upper: upper,
                rebate_point: rebate,
                condition: conditions,
                ranges: ranges,
            });
            // console.log(tableContent);
            table.reload("rebate", {
                data: tableContent
            });
            $('#lower_input').val("");
            $('#upper_input').val("");
            $('#rebate_input').val("");
        });

        form.on('submit(doAdd)', function (data) {
            var mydata = data.field;
            if (cp_project === "广告代理") {
                var mylist = [];
                var rebate_list = table.cache.rebate;
                for (var i = 0; i < rebate_list.length; i++){
                    if (!Array.isArray(rebate_list[i])) {
                        mylist.push({
                            cycle: rebate_list[i].cycle,
                            lower: rebate_list[i].lower+"",
                            upper: rebate_list[i].upper+"",
                            rebate_point: rebate_list[i].rebate_point,
                            condition: rebate_list[i].condition,
                            ranges: rebate_list[i].ranges
                        });
                    }
                }
                mydata['RebateList'] = JSON.stringify(mylist);
            }
            // if (mydata.filename === ""){
            //     layer.msg("上传文件不能为空!");
            //     return
            // }
            console.log(mydata);
            $.ajax({
                url: '/erp/contract/contractDoAdd',
                data: mydata,
                type: 'post',
                success: function (data) {
                    console.log(data);
                    if (data.code === 0) {
                        layer.msg(data.msg, {icon: 1, shade: 0.4, time: 1500});
                        setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        $('#add_contract_form').trigger('reset');
                    } else {
                        parent.layer.msg(data.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                    table.reload("rebate", {
                        data: []
                    });
                },
                error: function (data) {
                    alert("error");
                }
            });
            // $.post('/erp/contract/contractDoAdd', mydata, function (data) {
            //     console.log(data);
            //     if (data.code === 0) {
            //         layer.msg(data.msg, {icon: 1, shade: 0.4, time: 1500});
            //         setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
            //         setTimeout('parent.layer.closeAll()', 1500);//关闭layer
            //         $('#add_contract_form').trigger('reset');
            //     } else {
            //         parent.layer.msg(data.msg, {icon: 2, shade: 0.4, time: 1500});
            //         setTimeout(1500);
            //     }
            //     table.reload("rebate", {
            //         data: []
            //     });
            // })
        });
        upload.render({
            elem: '#uploadfile'
            ,url: '/erp/fileUpload'
            ,field: 'uploadName'
            ,size: 60 * 1024 //限制文件大小60MB，单位 KB
            ,accept: 'file' //普通文件
            ,acceptMime: 'application/pdf'  // pdf
            ,exts: 'pdf' //只允许上传压缩文件
            ,done: function(res, index){
                if (res.code === 0){
                    $("#filename_div").html("上传文件成功");
                    $("#filename_input").val(res.data);
                }else {
                    layer.msg("上传文件出错"+ res.msg)
                }
            }
        });
        $('#add_contract_form').on('submit', function (event) {
            event.preventDefault();
        });
    });

    function setHideDiv(cp_name) {
        //lay-verify="required"
        if (cp_name === "广告代理") {
            $('#cp_row_select_div').show();
            $('#cp_select_channel').attr('name', 'Channel').attr('lay-verify', 'required');
            $('#cp_select_project_type').attr('name', 'ProjectType').attr('lay-verify', 'required');

            $('#cp_row_input_div').hide();
            $('#cp_input_channel').removeAttr('name');
            $('#cp_input_project_type').removeAttr('name');

            $('.rebate_div').show();
        } else {
            $('#cp_row_select_div').hide();
            $('#cp_select_channel').removeAttr('name').removeAttr('lay-verify');
            $('#cp_select_project_type').removeAttr('name').removeAttr('lay-verify');

            $('#cp_row_input_div').show();
            $('#cp_input_channel').attr('name', 'Channel');
            $('#cp_input_project_type').attr('name', 'ProjectType');

            $('.rebate_div').hide();
        }
    }
});