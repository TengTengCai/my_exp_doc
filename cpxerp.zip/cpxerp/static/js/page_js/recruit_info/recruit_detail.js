$(function () {
    var recruit_position = $("#recruit_position_input").val();
    var employee_num = $("#employee_num_input").val();
    var working_place = $("#working_place_input").val();
    var employment_nature = $("#employment_nature_select option:selected").val();
    var age = $("#age_input").val();
    var employ_description = $("#employ_description_textarea").val();
    var sex = $("#sex_input").val();
    var education = $("#education_input").val();
    var post_duties = $("#post_duties_textarea").val();
    var professional_skills = $("#professional_skills_textarea").val();
    var work_experience = $("#work_experience_textarea").val();
    var key_capabilities = $("#key_capabilities_textarea").val();
    var duty_time = $("#duty_time_input").val();
    var salary_range = $("#salary_range_input").val();
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;
    });

    var clipboard = new ClipboardJS('#copyData_btn',{
        text: function(trigger) {
            // console.log(trigger);
            return "招聘职位: " + recruit_position + " \n" +
                "招聘人数: " + employee_num + " \n" +
                "工作地点: " + working_place + " \n" +
                "聘用性质: " + employment_nature + " \n" +
                "年龄: " + age + " \n" +
                "招聘需求说明: " + employ_description + " \n" +
                "性别: " + sex + " \n" +
                "学历: " + education + " \n" +
                "聘用岗位职责: " + post_duties + " \n" +
                "专业能力: " + professional_skills + " \n" +
                "工作经验: " + work_experience + " \n" +
                "关键胜任能力: " + key_capabilities + " \n" +
                "要求到岗时间: " + duty_time + " \n" +
                "期望薪酬范围: " + salary_range + " \n";
        }
    });
    clipboard.on('success', function(e) {
        // console.info('Action:', e.action);
        // console.info('Text:', e.text);
        // console.info('Trigger:', e.trigger);
        e.clearSelection();
        layer.msg("复制成功!",{icon: 1, shade: 0.4, time: 1500})
    });
});