$(function () {
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        laydate.render({
            elem: "#duty_time_input"
        });

        // 表单提交监听
        form.on('submit(doAdd)', function (data) {
            var _data = data.field;
            console.log(_data);
            $.ajax({
                url: '/erp/recruit/recruitDoAdd',
                type: 'post',
                dataType: 'JSON',
                data: _data,
                success: function (res) {
                    if (res.code == 0) {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                        setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        $('#add_recruit_form').trigger('reset');
                        table.reload('recruitTable',{
                            url: '/erp/recruit/recruitSelectByUser',
                        });
                    } else {
                        parent.layer.msg(res.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                },
                error: function () {
                    alert("失败")
                }
            });
            return false
        });

        table.render({
            elem: '#recruitTable',
            url: '/erp/recruit/recruitSelectByUser',
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'recruitTable',
            cols: [[
                {fixed: 'left', type: 'numbers', width: '50', align: 'center', title: '#'},
                {field: "create_user_name", width: '80', align: 'center', title: '需求人'},
                {field: "business_name", width: '100', align: 'center', title: '申请业务线'},
                {field: "recruit_position", width: '100', align: 'center', title: '招聘职位'},
                {field: "recruiting_numbers", width: '80', align: 'center', title: '招聘人数'},
                {field: "working_place", width: '80', align: 'center', title: '工作地点'},
                {field: "employment_nature", width: '100', align: 'center', title: '聘用性质'},
                {field: "age", width: '80', align: 'center', title: '年龄'},
                {field: "employ_reason", width: '200', align: 'center', title: '招聘理由'},
                {field: "employ_description", width: '200', align: 'center', title: '招聘说明'},
                {field: "post_duties", width: '150', align: 'center', title: '岗位职责'},
                {field: "sex", width: '80', align: 'center', title: '性别'},
                {field: "education", width: '80', align: 'center', title: '学历'},
                {field: "professional_skills", width: '80', align: 'center', title: '专业能力'},
                {field: "work_experience", width: '80', align: 'center', title: '工作经验'},
                {field: "key_capabilities", width: '80', align: 'center', title: '关键能力'},
                {field: "duty_time", width: '80', align: 'center', title: '到岗时间'},
                {field: "salary_range", width: '80', align: 'center', title: '期望薪酬范围'},
                {fixed: "right",field: "personnel_is_pass", width: '100', align: 'center', templet: setVerifyStatus ,title: '人事审核'},
                {fixed: "right",field: "ceo_is_pass", width: '100', align: 'center', templet: setCeoVerifyStatus ,title: 'CEO审核'},
                {fixed: "right",field: "is_had_recruit", width: '100', align: 'center', templet: setFinished, title: '招聘状态'},
                {fixed: "right", width: '80', align: 'center', title: '操作', toolbar: '#barDemo'},
            ]],
            page: true
        });

        table.on('tool(recruit)', function (obj) {
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            var tr = obj.tr; //获得当前行 tr 的DOM对象
            if(layEvent === 'detail'){ //查看
                layui.use('layer', function () {
                    layer.open({
                        type: 2,
                        title: "编辑",
                        maxmin: true,
                        shadeClose: true, //点击遮罩关闭层
                        scrollbar: true,
                        area: ['900px', '600px'],
                        content: '/erp/recruit/recruitDetail/' + data.id,
                        end: function () {
                            table.reload('recruitTable')
                        }
                    });
                });
            }
        })
    });
    $('#add_recruit_form').on("submit", function (event) {
        $('#add_recruit_form').preventDefault();
    });
    function setCeoVerifyStatus(d) {
        if (d.ceo_is_pass === '0') {
            return "<span class=\"layui-badge layui-bg-blue\">待审核</span>"
        } else if (d.ceo_is_pass === '1') {
            return "<span class=\"layui-badge layui-bg-green\">通过</span>"
        } else if (d.ceo_is_pass === '2') {
            return "<span class=\"layui-badge\">拒绝</span>"
        }
    }
    function setVerifyStatus(d) {
        if (d.personnel_is_pass === '0') {
            return "<span class=\"layui-badge layui-bg-blue\">待审核</span>"
        } else if (d.personnel_is_pass === '1') {
            return "<span class=\"layui-badge layui-bg-green\">通过</span>"
        } else if (d.personnel_is_pass === '2') {
            return "<span class=\"layui-badge\">拒绝</span>"
        }
    }
    function setFinished(d) {
        if (d.is_had_recruit === '0') {
            return '<span class="layui-badge layui-bg-orange">未招聘</span>'
        } else if (d.is_had_recruit === '1') {
            return '<span class="layui-badge layui-bg-blue">已招聘</span>'
        }
    }
});