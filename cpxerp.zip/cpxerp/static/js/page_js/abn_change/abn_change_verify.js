$(function () {
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        table.render({
            elem: '#abnormalTable',
            url: '/erp/abnormal/abnormalSelectVerify',
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'abnormalTable',
            page: true,
            cols: [[
                {fixed: 'left', width: '80', type: 'numbers', align: 'center', title: '#'},
                {field: "user_name", width: '100', align: 'center', title: '异动人'},
                {field: "depart_name", width: '100', align: 'center', title: '部门'},
                {field: "entry_time", width: '120', align: 'center', templet: setEntryTime, title: '入职时间'},
                {field: "apply_type", width: '120', align: 'center', title: '异动类型'},
                {field: "effect_time", width: '120', align: 'center', templet: setEffectTime, title: '期望生效时间'},
                {field: "reason", width: '200', align: 'center', title: '理由'},
                {fixed: "right", field: "depart_status", width: '80', align: 'center', templet:setDepartStatus, title: '部门主管审核'},
                {fixed: "right", field: "personnel_status", width: '80', align: 'center', templet:setPersonnalStatus, title: '人事审核状态'},
                {fixed: "right", field: "ceo_status", width: '80', align: 'center', templet:setCeoStatus, title: 'ceo审核状态'},
                {fixed: "right", field: "is_ok", width: '80', align: 'center', templet:setIsOkStatus, title: '审核结果'},
                {fixed: "right", width: '130', align: 'center', toolbar: '#barDemo', title: '操作'},
            ]]
        });

        table.on('tool(abnormal)', function (obj) {
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            var tr = obj.tr; //获得当前行 tr 的DOM对象

            if(layEvent === 'pass') {       //查看
                sendVerify(data, 1);
            }
            if (layEvent === 'notPass') {
                sendVerify(data, 2);
            }
        });

        function sendVerify(data, action) {
            var msg = "";
            if (action === 1){
                msg = '通过'
            } else {
                msg = '不通过'
            }
            layer.confirm('是否确认'+msg+'?', {icon: 3, title:'是否确认'}, function(index){
                $.ajax({
                    url: '/erp/abnormal/abnormalDoVerify/' + data.id ,
                    type: 'put',
                    data: {
                        action: action
                    },
                    success: function (data) {
                        if (data.code === 0) {
                            layer.msg(data.msg, {
                                icon: 1,
                                time: 2000 //2秒关闭（如果不配置，默认是3秒）
                            }, function () {
                                table.reload('abnormalTable');
                            });
                        } else {
                            layer.msg(data.msg, {
                                icon: 2,
                                time: 2000 //2秒关闭（如果不配置，默认是3秒）
                            });
                        }
                    }
                });
            });
        }

        function setDepartStatus(d) {
            if (d.depart_status === '0' && d.is_ok === '2' ) {
                return '<span class="layui-badge layui-bg-gray">未通过</span>'
            }
            if (d.depart_status === '0') {
                return '<span class="layui-badge layui-bg-blue">待审核</span>'
            } else if (d.depart_status === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        function setPersonnalStatus(d) {
            if (d.personnel_status === '0' && d.is_ok === '2' ) {
                return '<span class="layui-badge layui-bg-gray">未通过</span>'
            }
            if (d.personnel_status === '0') {
                return '<span class="layui-badge layui-bg-blue">待审核</span>'
            } else if (d.personnel_status === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        function setCeoStatus(d) {
            if (d.ceo_status === '0' && d.is_ok === '2') {
                return '<span class="layui-badge layui-bg-gray">未通过</span>'
            }
            if (d.ceo_status === '0') {
                return '<span class="layui-badge layui-bg-blue">待审核</span>'
            } else if (d.ceo_status === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        function setIsOkStatus(d) {
            if (d.is_ok === '0') {
                return '<span class="layui-badge layui-bg-blue">审核中...</span>'
            } else if (d.is_ok === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        function setEntryTime(d) {
            if (d.entry_time) {
                return d.entry_time.slice(0,10)
            }
            return '无'
        }

        function setEffectTime(d) {
            if (d.effect_time) {
                return d.effect_time.slice(0,10)
            }
            return '无'
        }
    });
});