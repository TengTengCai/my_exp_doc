$(function () {
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        table.render({
            elem: '#abnormalTable',
            url: '/erp/abnormal/abnormalSelectHadPass',
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'abnormalTable',
            page: true,
            cols: [[
                {fixed: 'left', width: '80', type: 'numbers', align: 'center', title: '#'},
                {field: "user_name", width: '100', align: 'center', title: '异动人'},
                {field: "depart_name", width: '100', align: 'center', title: '部门'},
                {field: "entry_time", width: '120', align: 'center', templet: setEntryTime, title: '入职时间'},
                {field: "apply_type", width: '120', align: 'center', title: '异动类型'},
                {field: "effect_time", width: '120', align: 'center', templet: setEffectTime, title: '期望生效时间'},
                {field: "reason", width: '200', align: 'center', title: '理由'},
                {fixed: "right", field: "is_ok", width: '80', align: 'center', templet: setIsOkStatus, title: '审核结果'},
                {fixed: "right", width: '100', align: 'center', toolbar: '#barDemo', title: '修改信息'},
            ]]
        });

        table.on('tool(abnormal)', function (obj) {
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            var tr = obj.tr; //获得当前行 tr 的DOM对象
            var myUel = '';
            if(layEvent === 'base') {       //查看
                myUrl =  '/erp/user/updateBase/' + data.applyer + '?abnId=' + data.id;
                setLayerOpen(myUrl)
            }
            if (layEvent === 'post') {
                myUrl =  '/erp/user/updatePost/' + data.applyer + '?isAbnChange=1&abnId=' + data.id;
                setLayerOpen(myUrl)
            }
            if (layEvent === 'salary') {
                myUrl =  '/erp/user/updateSalary/' + data.applyer + '?isAbnChange=1&abnId=' + data.id;
                setLayerOpen(myUrl)
            }
        });

        /**
         * 打开窗口
         * @param url 窗口中加载的url
         */
        function setLayerOpen(url) {
            layui.use('layer', function () {
                layer.open({
                    type: 2,
                    title: "编辑",
                    maxmin: true,
                    shadeClose: true, //点击遮罩关闭层
                    scrollbar: true,
                    area: ['900px', '600px'],
                    content: url,
                    end: function () {
                        table.reload('userTable')
                    }
                });
            });
        }

        function setIsOkStatus(d) {
            if (d.is_ok === '0') {
                return '<span class="layui-badge layui-bg-blue">审核中...</span>'
            } else if (d.is_ok === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        function setEntryTime(d) {
            if (d.entry_time) {
                return d.entry_time.slice(0,10)
            }
            return '无'
        }

        function setEffectTime(d) {
            if (d.effect_time) {
                return d.effect_time.slice(0,10)
            }
            return '无'
        }

    });
});