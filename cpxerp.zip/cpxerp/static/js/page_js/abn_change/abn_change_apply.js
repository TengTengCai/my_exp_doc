$(function () {
    var regular_time = $("#regular_time_input").val().slice(0,10);    // 获取转正时间
    var practice_end_time = $("#practice_end_time_input").val().slice(0,10);    // 获取结束时间
    $("#effect_time_input").val(regular_time);          // 设置转正时间
    // console.log(regular_time);
    // console.log(practice_end_time);
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        // 初始化时间选择器
        laydate.render({
            elem: '#effect_time_input',
            value: regular_time
        });
        // form表单中的下拉框选择事件
        form.on('select(apply_type)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            var regular_time_label = $("#regular_time_label");          // 转正时间label
            var practice_endTime_label = $("#practice_endTime_label");  // 实习结束时间label
            var change_salary_label = $("#change_salary_label");        // 调薪时间label
            var promotion_label = $("#promotion_label");                // 调岗时间label
            var regular_delay_label = $("#regular_delay_label");        // 转正延期label
            var practice_delay_label = $("#practice_delay_label");      // 实习延期label

            var effect_time_input = $("#effect_time_input");            // 有效时间input

            if (data.value === "转正") {
                regular_time_label.show();
                practice_endTime_label.hide();
                change_salary_label.hide();
                promotion_label.hide();
                regular_delay_label.hide();
                practice_delay_label.hide();
                effect_time_input.val(regular_time);
                setBtnEvent('');
            }
            if (data.value === "调薪") {
                regular_time_label.hide();
                practice_endTime_label.hide();
                change_salary_label.show();
                promotion_label.hide();
                regular_delay_label.hide();
                practice_delay_label.hide();
                laydate.render({
                    elem: '#effect_time_input',
                    value: new Date()
                });
                setBtnEvent('');
            }
            if (data.value === "实习转试用") {
                regular_time_label.hide();
                practice_endTime_label.show();
                change_salary_label.hide();
                promotion_label.hide();
                regular_delay_label.hide();
                practice_delay_label.hide();
                laydate.render({
                    elem: '#effect_time_input',
                    value: practice_end_time
                });
                setBtnEvent('');
            }
            if (data.value === "晋升") {
                regular_time_label.hide();
                practice_endTime_label.hide();
                change_salary_label.hide();
                promotion_label.show();
                regular_delay_label.hide();
                practice_delay_label.hide();
                laydate.render({
                    elem: '#effect_time_input',
                    value: new Date()
                });
                setBtnEvent('');
            }
            if (data.value === "转正延期") {
                regular_time_label.hide();
                practice_endTime_label.hide();
                change_salary_label.hide();
                promotion_label.hide();
                regular_delay_label.show();
                practice_delay_label.hide();
                effect_time_input.val(regular_time);
                setBtnEvent('');
            }
            if (data.value === "实习延期") {
                regular_time_label.hide();
                practice_endTime_label.hide();
                change_salary_label.hide();
                promotion_label.hide();
                regular_delay_label.hide();
                practice_delay_label.show();
                effect_time_input.val(practice_end_time);
                setBtnEvent('');
            }
        });

        form.on('submit(doAdd)', function (data) {
            var _data = data.field;
            // console.log(_data);
            $.ajax({
                url: '/erp/abnormal/abnormalApplyDoAdd',
                type: 'post',
                dataType: 'JSON',
                data: _data,
                success: function (res) {
                    if (res.code == 0) {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                        setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        $('#abn_change_apply_form').trigger('reset');
                        table.reload('abnormalTable',{
                            url: '/erp/abnormal/abnormalSelectByUser',
                        });
                    } else {
                        parent.layer.msg(res.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                }
            });
        });

        table.render({
            elem: '#abnormalTable',
            url: '/erp/abnormal/abnormalSelectByUser',
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'abnormalTable',
            page: true,
            cols: [[
                {fixed: 'left', width: '80', type: 'numbers', align: 'center', title: '#'},
                {field: "user_name", width: '100', align: 'center', title: '异动人'},
                {field: "depart_name", width: '100', align: 'center', title: '部门'},
                {field: "entry_time", width: '120', align: 'center', templet: setEntryTime, title: '入职时间'},
                {field: "apply_type", width: '120', align: 'center', title: '异动类型'},
                {field: "effect_time", width: '120', align: 'center', templet: setEffectTime, title: '期望生效时间'},
                {field: "reason", width: '200', align: 'center', title: '理由'},
                {fixed: "right", field: "depart_status", width: '80', align: 'center', templet:setDepartStatus, title: '部门主管审核'},
                {fixed: "right", field: "personnel_status", width: '80', align: 'center', templet:setPersonnalStatus, title: '人事审核状态'},
                {fixed: "right", field: "ceo_status", width: '80', align: 'center', templet:setCeoStatus, title: 'ceo审核状态'},
                {fixed: "right", field: "is_ok", width: '80', align: 'center', templet:setIsOkStatus, title: '审核结果'},
            ]]
        });

        /**
         * 设置部门审核状态
         * @param d 当前行数据
         * @returns {string}  渲染后的html字符串
         */
        function setDepartStatus(d) {
            if (d.depart_status === '0' && d.is_ok === '2' ) {
                return '<span class="layui-badge layui-bg-gray">未通过</span>'
            }
            if (d.depart_status === '0') {
                return '<span class="layui-badge layui-bg-blue">待审核</span>'
            } else if (d.depart_status === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        /**
         * 设置人事审核状态
         * @param d 当前行数据
         * @returns {string}   渲染后的html字符串
         */
        function setPersonnalStatus(d) {
            if (d.personnel_status === '0' && d.is_ok === '2' ) {
                return '<span class="layui-badge layui-bg-gray">未通过</span>'
            }
            if (d.personnel_status === '0') {
                return '<span class="layui-badge layui-bg-blue">待审核</span>'
            } else if (d.personnel_status === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        /**
         * 设置ceo审核状态
         * @param d 当前行数据
         * @returns {string}  渲染后的html字符串
         */
        function setCeoStatus(d) {
            if (d.ceo_status === '0' && d.is_ok === '2' ) {
                return '<span class="layui-badge layui-bg-gray">未通过</span>'
            }
            if (d.ceo_status === '0') {
                return '<span class="layui-badge layui-bg-blue">待审核</span>'
            } else if (d.ceo_status === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        /**
         * 设置整个审核流程状态
         * @param d  当前行数据
         * @returns {string}  渲染后的html字符串
         */
        function setIsOkStatus(d) {
            if (d.is_ok === '0') {
                return '<span class="layui-badge layui-bg-blue">审核中...</span>'
            } else if (d.is_ok === '1') {
                return '<span class="layui-badge layui-bg-green">通过</span>'
            } else {
                return '<span class="layui-badge">未通过</span>'
            }
        }

        /**
         * 设置入职时间格式
         * @param d 行数据
         * @returns {*}
         */
        function setEntryTime(d) {
            if (d.entry_time) {
                return d.entry_time.slice(0,10)
            }
            return '无'
        }

        /**
         * 设置有效时间格式
         * @param d 行数据
         * @returns {*}
         */
        function setEffectTime(d) {
            if (d.effect_time) {
                return d.effect_time.slice(0,10)
            }
            return '无'
        }

        /**
         * 点击按钮事件下载相关的文件
         * @param url
         */
        function setBtnEvent(url) {
            $('#download_btn').on('click', function (event) {
                window.open(url);
            })
        }
    });
    // 取消表单默认的提交行为
    $('#abn_change_apply_form').on('submit', function (event) {
        event.preventDefault();
    })
});