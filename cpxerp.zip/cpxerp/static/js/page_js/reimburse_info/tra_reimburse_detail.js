$(function () {
    var id = $('#tra_reimburse_id').val();
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        table.render({
            elem: '#detail'
            ,height: 350
            ,url: '/erp/reimburse/traReimburseDetails/' + id //数据接口
            ,page: true //开启分页
            ,cols: [[ //表头
                {fixed: 'left', type:"numbers", title: '#'}
                ,{field: 'CostItem', title: '费用项目'}
                ,{field: 'CostAbstract', title: '费用摘要'}
                ,{field: 'CostPrice', title: '金额'}
            ]]
        });
    });

});