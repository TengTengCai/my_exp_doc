$(function () {
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        table.render({
            elem: '#ord_reimburse'
            ,height: 350
            ,url: '/erp/reimburse/ordReimburseExamineData' //数据接口
            ,page: true //开启分页
            ,cols: [[ //表头
                {fixed: 'left', type:"numbers", title: '#', width:80}
                ,{field: 'name', title: '申请人', width:80}
                ,{field: 'department_name', title: '申请部门', width:110}
                ,{field: 'apply_time', title: '申请时间', width:130, sort:true}
                ,{field: 'cur_type', title: '申请币种', width: 90}
                ,{field: 'apply_price', title: '申请金额', width: 120}
                ,{field: 'capitals', title: '大写金额', width: 200}
                ,{field: 'company_name', title: '公司', width: 120}
                ,{field: 'file_url', title: '文件', width: 80, templet:getFile}
                ,{fixed:'right', field: 'depart_status', title: '部门审核', width: 90, templet: leaderStatus}
                ,{fixed:'right', field: 'financial_status', title: '财务审核', width: 90, templet: financialStatus}
                ,{fixed:'right', field: 'ceo_status', title: 'CEO审核', width: 90, templet: ceoStatus}
                ,{fixed:'right', field: 'pay_status', title: '支付状态', width: 90, templet: payStatus}
                ,{fixed:'right', title: '操作', width: 200, toolbar:'#barDemo'}
            ]]
        });

        table.on('sort(ord)', function(obj){
            // console.log(obj.field); //当前排序的字段名
            // console.log(obj.type); //当前排序类型：desc（降序）、asc（升序）、null（空对象，默认排序）
            // console.log(this); //当前排序的 th 对象
            var order = obj.field;
            if (obj.type === "desc") {
                order = "-" + order
            } else if (obj.type === "asc") {
            } else {
                order = ""
            }
            table.reload('ord_reimburse', {
                initSort: obj //记录初始排序，如果不设的话，将无法标记表头的排序状态。 layui 2.1.1 新增参数
                ,where: { //请求参数（注意：这里面的参数可任意定义，并非下面固定的格式）
                    order:order
                }
            });
        });

        table.on('tool(ord)', function (obj) {
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            var id = data.id;
            var mydata = {};
            if(layEvent === 'pass'){ // 通过
                //do somehing

                layer.confirm("是否确认通过?", {icon: 3, title:'提示'}, function (index) {
                    // 异步请求
                    mydata.Id = id;
                    mydata.AuditStatus = 1;
                    ordCheck(mydata);
                    layer.close(index);
                });
            } else if (layEvent === 'notPass') {
                // console.log(roleLevel);
                // layer.prompt({
                //     formType: 2,
                //     value: '',
                //     title: '请输入不通过原因',
                //     area: ['400px', '350px'] //自定义文本域宽高
                // }, function(value, index, elem){
                //     mydata.refusal = value;
                //     ordCheck(id, mydata);
                //     layer.close(index);
                // });
                mydata.Id = id;
                mydata.AuditStatus = 2;
                ordCheck(mydata);
            } else if (layEvent === 'detail') {
                layui.use('layer', function () {
                    layer.open({
                        type: 2,
                        title: "编辑",
                        maxmin: true,
                        shadeClose: true, //点击遮罩关闭层
                        scrollbar: true,
                        area: ['600px', '600px'],
                        content: '/erp/reimburse/ordReimburseSeeDetails/' + data.id
                    });
                });
            }
        });

        table.render({
            elem: '#tra_reimburse'
            ,height: 350
            ,url: '/erp/reimburse/traReimburseExamineData' //数据接口
            ,page: true //开启分页
            ,cols: [[ //表头
                {fixed: 'left', type:"numbers", title: '#', width:80}
                ,{field: 'ApplyerName', title: '申请人', width:80}
                ,{field: 'ApplyDepartName', title: '申请部门', width:110}
                ,{field: 'ApplyTime', title: '申请时间', width:130, sort:true}
                ,{field: 'CurType', title: '申请币种', width: 90}
                ,{field: 'ApplyPrice', title: '申请金额', width: 110}
                ,{field: 'Capitals', title: '大写金额', width: 120}
                ,{field: 'Outers', title: '外出人员', width: 120}
                ,{field: 'OutStartTime', title: '开始时间', width: 120}
                ,{field: 'OutEndTime', title: '结束时间', width: 120}
                ,{field: 'OutReason', title: '外出原因', width: 120}
                ,{field: 'CompanyName', title: '公司', width: 80}
                ,{field: 'FileUrl', title: '文件', width: 80, templet: getFilet}
                ,{fixed:'right', field: 'DepartStatus', title: '部门审核', width: 90, templet: leaderStatust}
                ,{fixed:'right', field: 'FinancialStatus', title: '财务审核', width: 90, templet: financialStatust}
                ,{fixed:'right', field: 'CeoStatus', title: 'CEO审核', width: 90, templet: ceoStatust}
                ,{fixed:'right', field: 'PayStatus', title: '支付状态', width: 90, templet: payStatust}
                ,{fixed:'right', title: '操作', width: 200, toolbar:'#barDemo'}
            ]]
        });

        table.on('sort(tra)', function(obj){
            // console.log(obj.field); //当前排序的字段名
            // console.log(obj.type); //当前排序类型：desc（降序）、asc（升序）、null（空对象，默认排序）
            // console.log(this); //当前排序的 th 对象
            table.reload('tra_reimburse', {
                initSort: obj //记录初始排序，如果不设的话，将无法标记表头的排序状态。 layui 2.1.1 新增参数
                ,where: { //请求参数（注意：这里面的参数可任意定义，并非下面固定的格式）
                    field: obj.field //排序字段
                    ,order: obj.type //排序方式
                }
            });
        });

        table.on('tool(tra)', function (obj) {
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            // var tr = obj.tr; //获得当前行 tr 的DOM对象
            var id = data.Id;
            var mydata = {};
            if(layEvent === 'pass'){ // 通过
                //do somehing
                layer.confirm("是否确认通过?", {icon: 3, title:'提示'}, function (index) {
                    // 异步请求
                    mydata.Id = id;
                    mydata.AuditStatus = 1;
                    traCheck(mydata);
                    layer.close(index);
                });
            } else if (layEvent === 'notPass') {    // 不通过
                // layer.prompt({
                //     formType: 2,
                //     value: '',
                //     title: '请输入不通过原因',
                //     area: ['400px', '350px'] //自定义文本域宽高
                // }, function(value, index, elem){
                //     mydata.refusal = value;
                //     traCheckNotPass(id, mydata);
                //     layer.close(index);
                // });
                mydata.Id = id;
                mydata.AuditStatus = 2;
                traCheck(mydata);
            } else if (layEvent === 'detail') {
                layui.use('layer', function () {
                    layer.open({
                        type: 2,
                        title: "编辑",
                        maxmin: true,
                        shadeClose: true, //点击遮罩关闭层
                        scrollbar: true,
                        area: ['800px', '800px'],
                        content: '/erp/reimburse/traReimburseSeeDetails/' + data.id
                    });
                });
            }
        });
        function ordCheck(mydata) {
            $.ajax({
                url: '/erp/reimburse/ordReimburseDoExamine',
                type: 'post',
                data: mydata,
                success: doSuccess
            })
        }


        function traCheck(mydata) {
            $.ajax({
                url: '/erp/reimburse/travelReimburseDoExamine',
                type: 'post',
                data: mydata,
                success: doSuccess
            })
        }

        function doSuccess(data) {
            if (data.code === 0) {
                layer.msg(data.msg, {icon: 1, shade: 0.4, time: 1500});
                setTimeout('$(".layui-laypage-btn").click()', 1500);
                setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                // table.reload('ord_reimburse');
                table.reload('tra_reimburse', {
                    url: '/erp/reimburse/traReimburseExamineData'
                });
            }else {
                layer.msg(data.msg, {icon: 2, shade: 0.4, time: 1500});
                // table.reload('tra_reimburse');
                // table.reload('tra_reimburse');
            }
        }
    });




    /**
     * 部门领导审核状态
     * @param d 行数据
     * @returns {string} 返回对应的标签
     */
    function leaderStatus(d) {
        if (d.depart_status === "0") {
            return '<span class="layui-badge layui-bg-blue">待审核</span>';
        } else if (d.depart_status === "1") {
            return '<span class="layui-badge layui-bg-green">通过</span>';
        } else if (d.depart_status === "2") {
            return '<span class="layui-badge">不通过</span>';
        }
    }

    /**
     * 财务审核状态
     * @param d 行数据
     * @returns {string} 返回对应的标签
     */
    function financialStatus(d) {
        if (d.financial_status === "0") {
            return '<span class="layui-badge layui-bg-blue">待审核</span>';
        } else if (d.financial_status === "1") {
            return '<span class="layui-badge layui-bg-green">通过</span>';
        } else if (d.financial_status === "2") {
            return '<span class="layui-badge">不通过</span>';
        }
    }
    /**
     * CEO审核状态
     * @param d 行数据
     * @returns {string} 返回对应的标签
     */
    function ceoStatus(d) {
        if (d.ceo_status === "0") {
            return '<span class="layui-badge layui-bg-blue">待审核</span>';
        } else if (d.ceo_status === "1") {
            return '<span class="layui-badge layui-bg-green">通过</span>';
        } else if (d.ceo_status === "2") {
            return '<span class="layui-badge">不通过</span>';
        }
    }
    /**
     * 支付状态
     * @param d 行数据
     * @returns {string} 返回对应的标签
     */
    function payStatus(d) {
        if (d.pay_status === "0") {
            return '<span class="layui-badge layui-bg-blue">待支付</span>';
            // return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'

        } else if (d.pay_status === "1") {
            return '<span class="layui-badge layui-bg-green">已支付</span>';
            // return '<button class="layui-btn layui-btn-xs">通过</button>'
        } else if (d.pay_status === "2") {
            return '<span class="layui-badge">拒绝支付</span>';
            // return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
        }
    }


    /**
     * 部门领导审核状态
     * @param d 行数据
     * @returns {string} 返回对应的标签
     */
    function leaderStatust(d) {
        if (d.DepartStatus === 0) {
            return '<span class="layui-badge layui-bg-blue">待审核</span>';
        } else if (d.DepartStatus === 1) {
            return '<span class="layui-badge layui-bg-green">通过</span>';
        } else if (d.DepartStatus === 2) {
            return '<span class="layui-badge">不通过</span>';
        }
    }

    /**
     * 财务审核状态
     * @param d 行数据
     * @returns {string} 返回对应的标签
     */
    function financialStatust(d) {
        if (d.FinancialStatus === 0) {
            return '<span class="layui-badge layui-bg-blue">待审核</span>';
        } else if (d.FinancialStatus === 1) {
            return '<span class="layui-badge layui-bg-green">通过</span>';
        } else if (d.FinancialStatus === 2) {
            return '<span class="layui-badge">不通过</span>';
        }
    }
    /**
     * CEO审核状态
     * @param d 行数据
     * @returns {string} 返回对应的标签
     */
    function ceoStatust(d) {
        if (d.CeoStatus === 0) {
            return '<span class="layui-badge layui-bg-blue">待审核</span>';
        } else if (d.CeoStatus === 1) {
            return '<span class="layui-badge layui-bg-green">通过</span>';
        } else if (d.CeoStatus === 2) {
            return '<span class="layui-badge">不通过</span>';
        }
    }
    /**
     * 支付状态
     * @param d 行数据
     * @returns {string} 返回对应的标签
     */
    function payStatust(d) {
        if (d.PayStatus === 0) {
            return '<span class="layui-badge layui-bg-blue">待支付</span>';
            // return '<button class="layui-btn layui-btn-xs layui-btn-normal">待审核</button>'

        } else if (d.PayStatus === 1) {
            return '<span class="layui-badge layui-bg-green">已支付</span>';
            // return '<button class="layui-btn layui-btn-xs">通过</button>'
        } else if (d.PayStatus === 2) {
            return '<span class="layui-badge">拒绝支付</span>';
            // return '<button class="layui-btn layui-btn-xs layui-btn-danger">不通过</button>'
        }
    }
    /**
     * 获取文件标签
     * @param d 行数据
     * @returns {string} 对应标签
     */
    function getFile(d) {
        if (d.file_url === "") {
            // 这里渲染了文件上传的URL地址,每个合同的上传地址都不相同
            return '<button class="layui-btn layui-btn-xs layui-btn-normal upload_btn" lay-data="{url: \'/erp/contract/contractUploadById/'+d.id+'\'}">上传</button>'
        } else {
            return '<a class="layui-btn layui-btn-xs" target="_blank" href="'+d.file_url+'">下载</a>'
        }
    }
    /**
     * 获取文件标签
     * @param d 行数据
     * @returns {string} 对应标签
     */
    function getFilet(d) {
        if (d.FileUrl === "") {
            // 这里渲染了文件上传的URL地址,每个合同的上传地址都不相同
            return '<button class="layui-btn layui-btn-xs layui-btn-normal upload_btn" lay-data="{url: \'/erp/contract/contractUploadById/'+d.id+'\'}">上传</button>'
        } else {
            return '<a class="layui-btn layui-btn-xs" target="_blank" href="'+d.file_url+'">下载</a>'
        }
    }
});