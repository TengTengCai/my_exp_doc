$(function () {
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        laydate.render({
            elem: '#apply_time'
        });

        table.render({
            elem: '#reimburse',
            cols: [[ //标题栏
                {title: '#', width: 80, templet: numTemplet}
                , {field: 'CostItem', title: '费用项目', minwidth: 80}
                , {field: 'CostAbstract', title: '费用摘要', minWidth: 80}
                , {field: 'CostPrice', title: '费用金额', minWidth: 80}
                , {fixed: 'right', title: '操作', width: 80, toolbar: '#toolbar'}
            ]],
            data: []
        });

        table.on('tool(reimburse)', function (obj) {
            if (obj.event === 'del') {
                layer.confirm('是否确定删除该行?', function (index) {
                    obj.del();
                    layer.close(index);
                    setTotal();
                });

            }
        });

        $("#add_reimburse_datail").on('click', function (event) {
            var tableContent = table.cache.reimburse;
            var costItem = $('#cost_item').val();
            var costAbstract = $('#cost_abstract').val();
            var costPrice = $('#cost_price').val();
            if (costItem === "" || costAbstract === "" || costPrice === "") {
                layer.msg("费用详情输入不能为空");
                return
            }
            costPrice = parseFloat(costPrice);
            tableContent.push({
                CostItem: costItem,
                CostAbstract: costAbstract,
                CostPrice: costPrice,
            });
            table.reload("reimburse", {
                data: tableContent
            });
            $('#cost_item').val("");
            $('#cost_abstract').val("");
            $('#cost_price').val("");
            setTotal();
        });

        form.on('submit(doAdd)', function (data) {
            var mydata = data.field;
            if (table.cache.reimburse.length <= 0){
                layer.msg("报销详情不能为空,无法报销!");
                return
            }
            var mylist = [];
            var reimburse_list = table.cache.reimburse;
            for (var i = 0; i < reimburse_list.length; i++){
                if (!Array.isArray(reimburse_list[i])) {
                    mylist.push(reimburse_list[i]);
                }
            }
            mydata.reimburse_list = JSON.stringify(mylist);
            mydata.apply_price = $("#price_total").text(); // 加参数
            mydata.capitals = $("#price_capitals").text();
            mydata.filename = $("#filename_input").val();
            console.log(mydata);
            $.ajax({
                url:'/erp/reimburse/ordReimburseDoApply',
                type: 'post',
                dataType: 'JSON',
                data: mydata,
                success: function (data) {
                    if (data.code === 0) {
                        layer.msg(data.msg, {icon: 1, shade: 0.4, time: 1500});
                        // setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        // setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        $('#reimburse_apply_form').trigger('reset');
                        table.reload("reimburse", {
                            data: []
                        });
                        $("#filename_input").val("");
                        $("#price_total").text("");
                        $("#price_capitals").text("");
                    } else {
                        parent.layer.msg(data.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                }
            })
        });

        upload.render({
            elem: '#uploadfile'
            ,url: '/erp/fileUpload'
            ,field: 'uploadName'
            ,size: 60 * 1024 //限制文件大小60MB，单位 KB
            ,accept: 'file' //普通文件
            ,acceptMime: 'application/zip'
            ,exts: 'zip' //只允许上传压缩文件
            ,done: function(res, index){
                if (res.code === 0){
                    $("#filename_div").html("上传文件成功");
                    $("#filename_input").val(res.data);
                }else {
                    layer.msg("上传文件出错"+ res.msg)
                }
            }
        });

        $('#add_contract_form').on('submit', function (event) {
            event.preventDefault();
        });

        function setTotal() {
            var total = 0;
            var tableContent = table.cache.reimburse;
            console.log(tableContent);
            for (var i = 0; i < tableContent.length; i++) {
                if (!Array.isArray(tableContent[i])){
                    total += parseInt(tableContent[i].CostPrice*100)
                }
            }
            total = total / 100.00;
            console.log(total);
            $("#price_total").text(total);
            $("#price_capitals").text(toCapitalChinese(total));
        }

        function numTemplet(d) {
            // console.log(d);
            return d.LAY_INDEX
        }
    });

    $('#reimburse_apply_form').on('submit', function (event) {
        event.preventDefault()
    });
});