$(function () {
    var business_str = $('#bussiness_str').val();
    var list = JSON.parse(business_str);
    console.log(list);
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var formSelects = layui.formSelects;
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        formSelects.value('business', list);
        //执行一个laydate实例
        laydate.render({
            elem: '#Birthday' //指定元素
        });
        //执行一个laydate实例
        laydate.render({
            elem: '#TimeOfEntry' //指定元素
        });
        //执行一个laydate实例
        laydate.render({
            elem: '#WorkingHours' //指定元素
        });



        form.verify({
            IDCard: [/^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/, '身份证号格式不正确'],
            PhoneNumber: [/^[1][3,4,5,7,8][0-9]{9}$/, '请输入正确的手机号'],
        });

        form.on('submit(doUpdate)', function (data) {
            var _data = data.field;
            _data.business = JSON.stringify(formSelects.value('business', 'val'));
            // console.log(_data);
            $.ajax({
                url: '/erp/user/userDoUpdate',
                type: 'put',
                dataType: 'JSON',
                data: _data,
                success: function (res) {
                    if (res.code == 0) {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                        setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        $('#add_user_form').trigger('reset');
                    } else {
                        parent.layer.msg(res.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                },
                error: function () {
                    alert("失败")
                }
            });
            return false
        });
    });
    $('#update_user_form').on('submit', function () {
        $('#update_user_form').preventDefault();
    });

});