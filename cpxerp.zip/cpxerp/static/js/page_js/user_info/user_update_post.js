$(function () {
    // 初始化用户参数
    var user_id = $('#user_id_input').val();
    var area_id = $('#area_id_select option:selected').val();
    var employee_nature = $('#employee_nature_select option:selected').val();
    var incumbency = $('#incumbency_select option:selected').val();
    var superior = $('#superior_select option:selected').val();
    var attendance_num = $('#attendance_num_input').val();
    var company_id = $('#company_id_select option:selected').val();
    var business_str = $('#business_str_input').val();
    var list = JSON.parse(business_str);
    var depart_id = $('#depart_id_input').val();
    var role_id = $('#role_id_input').val();
    var post_attributes = $('#post_attributes_input').val();
    var post_rank = $('#post_rank_input').val();
    var nature_of_work = $('#nature_of_work_input').val();
    var is_select = false;
    if (nature_of_work === "转正" || nature_of_work === "实习") {
        $('#regular_btn').hide();
    }
    // console.log(role_id);
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form'], function () {
        var formSelects = layui.formSelects;
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer;

        formSelects.value('business', list);

        formSelects.on(null, function(id, vals, choice, isAdd, isDisabled){
            //id:           点击select的id
            //vals:         当前select已选中的值
            //choice:       当前select点击的值
            //isAdd:        当前操作选中or取消
            //isDisabled:   当前选项是否是disabled

            //如果return false, 那么将取消本次操作
            is_select = true;
            return true;
        });

        form.on('select(post_attributes)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            setRank(data.value,false)
        });

        form.on('select(depart)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            setRole(data.value, false);
        });
        
        form.on('select(role)', function (data) {
            console.log(data.value); //得到被选中的值
        });

        /**
         * 设置Rank的数据
         * @param type 岗位属性
         * @param isSelected 是否是已选择
         */
        function setRank(type, isSelected){
            var mydata = {};
            mydata.type = type;
            $.ajax({
                url: '/erp/user/getRankByType',
                type: 'GET',
                data: mydata,
                success: function (res) {
                    if (res.code == 0) {
                        var data = res.data;
                        var html_str = "";
                        if (isSelected){
                            for (var i = 0; i < data.length; i++) {
                                if (data[i].RankName === post_rank) {
                                    html_str += '<option value="' + data[i].RankName + '" selected>' + data[i].RankName + '</option>';
                                }else {
                                    html_str += '<option value="' + data[i].RankName + '">' + data[i].RankName + '</option>'
                                }
                            }
                        } else {
                            for (var i = 0; i < data.length; i++) {
                                html_str += '<option value="' + data[i].RankName + '">' + data[i].RankName + '</option>'
                            }
                        }
                        $('#post_rank_select').html(html_str);
                        form.render('select');
                    } else {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                    }
                }
            })
        }

        /**
         * 设置动态渲染岗位
         * @param depart_id 部门ID
         * @param isSelected 是否是一选择
         */
        function setRole(depart_id, isSelected){
            var mydata = {};
            mydata.depart_id = depart_id;
            $.ajax({
                url: '/erp/user/getRoleByDepartId',
                type: 'GET',
                data: mydata,
                success: function (res) {
                    // console.log(res);
                    if (res.code == 0) {
                        var data = res.data;
                        var html_str = "";
                        if (isSelected){
                            // console.log('selected');
                            for (var i = 0; i < data.length; i++) {
                                // console.log(data[i].RoleId, role_id);
                                if (data[i].RoleId == role_id){
                                    html_str += '<option value="' + data[i].RoleId + '" selected>' + data[i].RoleName + '</option>';
                                }else {
                                    html_str += '<option value="' + data[i].RoleId + '">' + data[i].RoleName + '</option>'
                                }
                                // console.log(data);
                            }
                        } else {
                            for (var i = 0; i < data.length; i++) {
                                // console.log(data);
                                html_str += '<option value="' + data[i].RoleId + '">' + data[i].RoleName + '</option>'
                            }
                        }
                        $('#role_select').html(html_str);
                        form.render('select');
                    } else {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                    }
                }
            })
        }
        // 初始化选择的职级
        setRank(post_attributes, true);
        // 初始化选择的岗位
        setRole(depart_id, true);
        // 修改提交监听
        form.on('submit(doEdit)', function (data) {
            var _data = data.field;
            _data.business = JSON.stringify(formSelects.value('business', 'val'));
            // console.log(_data);
            // console.log(isChangeForm(_data));
            if (isChangeForm(_data)){
                $.ajax({
                    url: '/erp/user/userDoUpdatePost',
                    type: 'put',
                    dataType: 'JSON',
                    data: _data,
                    success: function (res) {
                        console.log(res);
                        if (res.code == 0) {
                            layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                            setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                            setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        } else {
                            parent.layer.msg(res.msg, {icon: 2, shade: 0.4, time: 1500});
                            setTimeout(1500);
                        }
                    },
                    error: function () {
                        alert("失败")
                    }
                });
            } else {
                layer.msg("表单未变更无法提交", {icon: 3, shade: 0.4, time: 1500});
            }
            return false
        });
    });
    // 取消默认的表单提交行为
    $("#update_user_post_form").on("submit", function (event) {
        event.preventDefault();
    });
    $("#regular_btn").on("click", function () {
        layer.confirm('确定要对当前员工进行转正操作?(不可逆)', {icon: 3, title:'提示'}, function(index){
            //do something
            var index1 = layer.load();
            $.ajax({
                url:'/erp/user/userDoRegular/'+user_id,
                type: 'put',
                data: {
                    isAbnChange: $('#isAbnChange_input').val(),
                    abnId: $('#abnId_input').val()
                },
                success: function (data) {
                    layer.close(index1);
                    if (data.code == 0) {
                        layer.msg(data.msg, {icon: 1, shade: 0.4, time: 2000});
                        setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                    } else {
                        parent.layer.msg(data.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                },
                error: function () {
                    layer.close(index1);
                    layer.msg("操作失败,网络不可用!", {icon: 2, shade: 0.4, time: 2000});

                }
            });
            layer.close(index);
        });
    });
    function isChangeForm(data) {
        if (data.AreaId !== area_id){
            return true
        }
        if (data.EmployeeNature !== employee_nature) {
            return true
        }
        if (data.DepartmentId !== depart_id) {
            return true
        }
        if (data.RoleId !== role_id) {
            return true
        }
        if (data.Incumbency !== incumbency) {
            return true
        }
        if (data.PostAttributes !== post_attributes) {
            return true
        }
        if (data.PostRank !== post_rank) {
            return true
        }
        if (is_select) {
            return true
        }
        if (data.Superior !== superior) {
            return true
        }
        if (data.AttendanceNum !== attendance_num) {
            return true
        }
        if (data.CompanyId !== company_id) {
            return true
        }
        return false
    }
});