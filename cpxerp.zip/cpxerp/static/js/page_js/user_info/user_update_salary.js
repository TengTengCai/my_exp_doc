$(function () {
    var bank_card_info = $('#bank_card_info_input').val();
    var bank_card_num = $('#bank_card_num_input').val();
    var internship_salary = $('#internship_salary_input').val();
    var probation_salary = $('#probation_salary_input').val();
    var probation_achieve_percent = $('#probation_achieve_percent').val();
    var regular_salary = $('#regular_salary_input').val();
    var regular_achieve_percent = $('#regular_achieve_percent').val();
    var tax_subsidy = $('#tax_subsidy_input').val();
    var other_subsidies = $('#other_subsidies_input').val();
    var num_of_insurance = $('#num_of_insurance_input').val();
    var num_of_medical_insurance = $('#num_of_medical_insurance_input').val();
    var num_of_unemp_loyment_insurance = $('#num_of_unemp_loyment_insurance').val();
    var accumulation_fund_base = $('#accumulation_fund_base_input').val();
    var payment_month = $('#payment_month_input').val();
    var social_security_type = $('#social_security_type_input').val();
    // 初始化用户参数
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer;

        laydate.render({
            elem: '#payment_month_input',
            type: 'month'
        });

        // 修改提交监听
        form.on('submit(doEdit)', function (data) {
            var _data = data.field;
            // console.log(_data);
            if (isChangeForm(_data)) {
                $.ajax({
                    url: '/erp/user/userDoUpdateSalary',
                    type: 'put',
                    dataType: 'JSON',
                    data: _data,
                    success: function (res) {
                        console.log(res);
                        if (res.code == 0) {
                            layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                            setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                            setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        } else {
                            parent.layer.msg(res.msg, {icon: 2, shade: 0.4, time: 1500});
                            setTimeout(1500);
                        }
                    },
                    error: function () {
                        alert("失败")
                    }
                });
            } else {
                layer.msg("表单数据未变化无法提交!", {icon: 3, shade: 0.4, time: 1500});
            }
            return false
        });
    });
    // 取消默认的表单提交行为
    $("#update_user_salary_form").on("submit", function () {
        $("#update_user_salary_form").preventDefault();
    });
    function isChangeForm(data) {
        if (data.BankCardInfo !== bank_card_info) {
            return true
        }
        if (data.BankCardNum !== bank_card_num) {
            return true
        }
        if (data.InternshipSalary !== internship_salary) {
            return true
        }
        if (data.ProbationSalary !== probation_salary) {
            return true
        }
        if (data.ProbationAchievePercent !== probation_achieve_percent) {
            return true
        }
        if (data.RegularSalary !== regular_salary) {
            return true
        }
        if (data.RegularAchievePercent !== regular_achieve_percent) {
            return true
        }
        if (data.TaxSubsidy !== tax_subsidy) {
            return true
        }
        if (data.OtherSubsidies !== other_subsidies) {
            return true
        }
        if (data.NumOfInsurance !== num_of_insurance) {
            return true
        }
        if (data.NumOfMedicalInsurance !== num_of_medical_insurance) {
            return true
        }
        if (data.NumOfUnempLoymentInsurance !== num_of_unemp_loyment_insurance) {
            return true
        }
        if (data.AccumulationFundBase !== accumulation_fund_base) {
            return true
        }
        if (data.PaymentMonth !== payment_month) {
            return true
        }
        if (data.SocialSecurityType !== social_security_type) {
            return true
        }
        return false
    }

});