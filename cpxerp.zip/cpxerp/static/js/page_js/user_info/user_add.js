$(function () {
    $("#contract_period_div").show();
    $("#probation_period_div").hide();
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var formSelects = layui.formSelects;
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;
        // 监听合同类型选择
        form.on('select(contract_nature)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            //$("#probation_period_div")
            if (data.value === "实习") {
                $("#contract_period_div").removeAttr("lay-verify").hide();
                $("#probation_period_div").attr("lay-verify", "required").show();
            } else if (data.value === "合同制") {
                $("#contract_period_div").attr("lay-verify", "required").show();
                $("#probation_period_div").removeAttr("lay-verify").hide();
            } else {
                $("#contract_period_div").hide().removeAttr("lay-verify");
                $("#probation_period_div").hide().removeAttr("lay-verify");
            }
        });
        // 监听岗位属性选择
        form.on('select(post_attributes)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            var mydata = {};
            mydata.type = data.value;
            $.ajax({
                url: '/erp/user/getRankByType',
                type: 'GET',
                data: mydata,
                success: function (res) {
                    if (res.code == 0) {
                        var data = res.data;
                        var html_str = "";
                        for (var i = 0; i < data.length; i++) {
                            html_str += '<option value="' + data[i].RankName + '">' + data[i].RankName + '</option>'
                        }
                        $('#post_rank_select').html(html_str);
                        form.render('select');
                    } else {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                    }
                }
            })
        });

        // 监听部门选择
        form.on('select(depart)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            var mydata = {};
            mydata.depart_id = data.value;
            $.ajax({
                url: '/erp/user/getRoleByDepartId',
                type: 'GET',
                data: mydata,
                success: function (res) {
                    if (res.code == 0) {
                        var data = res.data;
                        var html_str = "";
                        for (var i = 0; i < data.length; i++) {
                            // console.log(data);
                            html_str += '<option value="' + data[i].RoleId + '">' + data[i].RoleName + '</option>'
                        }
                        $('#role_select').html(html_str);
                        form.render('select');
                    } else {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                    }
                }
            })

        });

        //执行一个laydate实例
        laydate.render({
            elem: '#time_of_entry_input' //指定元素
            , done: function (value, date, endDate) {
                // console.log(value); //得到日期生成的值，如：2017-08-18
                // console.log(date); //得到日期时间对象：{year: 2017, month: 8, date: 18, hours: 0, minutes: 0, seconds: 0}
                // console.log(endDate); //得结束的日期时间对象，开启范围选择（range: true）才会返回。对象成员同上。
                var mydate = new Date(value);
                if (date.date >= 15) {
                    mydate.setMonth(date.month);
                    mydate.setDate(1);
                } else if (date.date < 15) {
                    mydate.setDate(1);
                    $('#payment_month_input').val(date.month)
                }
                laydate.render({
                    elem: '#payment_month_input',
                    value: mydate.getFullYear() + '-' + (mydate.getMonth() + 1) + '-' + mydate.getDate()
                });
            }
        });

        //执行一个laydate实例
        laydate.render({
            elem: '#birthday_input' //指定元素
        });

        //执行一个laydate实例
        laydate.render({
            elem: '#graduate_time_input' //指定元素
        });

        //执行一个laydate实例
        laydate.render({
            elem: '#working_hours_input' //指定元素
        });

        laydate.render({
            elem: '#payment_month_input'
        });

        form.verify({
            IDCard: [/^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/, '身份证号格式不正确'],
            PhoneNumber: [/^[1][3,4,5,7,8][0-9]{9}$/, '请输入正确的手机号'],
        });

        // 表单提交监听
        form.on('submit(doAdd)', function (data) {
            var _data = data.field;
            _data.business = JSON.stringify(formSelects.value('business', 'val'));
            console.log(_data);
            $.ajax({
                url: '/erp/user/userDoAdd',
                type: 'post',
                dataType: 'JSON',
                data: _data,
                success: function (res) {
                    if (res.code == 0) {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                        setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        $('#add_user_form').trigger('reset');
                    } else {
                        parent.layer.msg(res.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                },
                error: function () {
                    alert("失败")
                }
            });
            return false
        });
    });
    // 禁止表单默认行为
    $('#add_user_form').on('submit', function () {
        $('#add_user_form').preventDefault();
    });
    // 转正薪资失焦监听
    // $('#regular_salary_input').on('blur', function (event) {
    //     var value = $('#regular_salary_input').val();
    //     $('#num_of_insurance_input').val(value);
    //     $('#num_of_unemp_loyment_insurance').val(value);
    //     $('#accumulation_fund_base_input').val(value);
    //     $('#num_of_medical_insurance').val(value);
    // })

});