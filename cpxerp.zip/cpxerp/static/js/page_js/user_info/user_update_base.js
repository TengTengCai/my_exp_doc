$(function () {
    function setDivShow(d) {
        if (d === "实习") {
            $("#contract_period_div").hide();
            $("#probation_period_div").show();
            //.removeAttr("lay-verify")
            //.attr("lay-verify", "required")
        } else if (d === "合同制") {
            $("#contract_period_div").show();
            $("#probation_period_div").hide();
        } else {
            $("#contract_period_div").hide().removeAttr("lay-verify");
            $("#probation_period_div").hide().removeAttr("lay-verify");
        }
    }
    // 合同选择的值
    var contract_nature = $("#contract_nature_select option:selected").val();
    setDivShow(contract_nature);   // 页面设置
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer;
        // 设置合同类型改变监听
        form.on('select(contract_nature)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            //$("#probation_period_div")
            setDivShow(data.value)
        });
        // 设置改变表单提交行为
        form.on('submit(doEdit)', function (data) {
            var _data = data.field;
            // console.log(_data);
            $.ajax({
                url: '/erp/user/userDoUpdateBase',
                type: 'put',
                dataType: 'JSON',
                data: _data,
                success: function (res) {
                    if (res.code == 0) {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                        setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                    } else {
                        parent.layer.msg(res.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                },
                error: function () {
                    alert("失败")
                }
            });
            return false
        });
        // 入职时间
        laydate.render({
            elem: '#time_of_entry_input', //指定元素
            value: $('#time_of_entry_input').val()
        });

        //执行一个laydate实例
        laydate.render({
            elem: '#birthday_input' //指定元素
        });

        //执行一个laydate实例
        laydate.render({
            elem: '#graduate_time_input' //指定元素
        });

        //执行一个laydate实例
        laydate.render({
            elem: '#working_hours_input' //指定元素
        });


    });
    // 取消默认表单提交行为
    $('#update_user_base_form').on("submit", function () {
        $('#update_user_base_form').preventDefault();
    })
});