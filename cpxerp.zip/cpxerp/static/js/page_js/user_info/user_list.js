$(function () {
    // 取消表单默认的提交行为
    $('#search_form').on('submit', function () {
        $('#search_form').preventDefault();
    });
    // 设置下载按钮监听
    $('#outputExcel').on('click', function (event) {
        window.open('/erp/user/outputToExcel');
    });
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer;
        // 部门选择监听
        form.on('select(department_id)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            var mydata = {};
            mydata.depart_id = data.value;
            $.ajax({
                url: '/erp/user/getRoleByDepartId',
                type: 'GET',
                data: mydata,
                success: function (res) {
                    if (res.code == 0) {
                        var data = res.data;
                        var html_str = "<option></option>";
                        for (var i = 0; i < data.length; i++) {
                            // console.log(data);
                            html_str += '<option value="' + data[i].RoleId + '">' + data[i].RoleName + '</option>'
                        }
                        $('#role_id_select').html(html_str);
                        form.render('select');
                    } else {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                    }
                }
            })
        });

        // 搜索事件
        form.on('submit(search)', function (data) {
            var _data = data.field;
            console.log(_data);
            table.reload('userTable', {
                where: _data,
                url: '/erp/user/userDoSelect',
                page: {
                    curr: 1 //重新从第 1 页开始
                }
            });
            return false
        });
        // 表格加载
        table.render({
            elem: '#userTable',
            url: '/erp/user/userDoSelect',
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'userTable',
            cols: [[
                {fixed: 'left', field: 'user_id', width: '80', align: 'center', title: 'ID'},
                {fixed: 'left', field: 'employee_num', width: '80', align: 'center', title: '员工编号'},
                {fixed: 'left', field: 'name', width: '100', align: 'center', title: '姓名', templet:setNameColor},
                {field: 'contract_num', width: '200', align: 'center', title: '合同编号'},
                {field: 'email', width: '200', align: 'center', title: '邮箱'},
                {field: 'qq_num', width: '200', align: 'center', title: 'QQ号'},
                {field: 'phone_number', width: '150', align: 'center', title: '手机号'},
                {field: 'contract_nature', width: '150', align: 'center', title: '合同性质'},
                {field: 'time_of_entry', width: '150', align: 'center', title: '入职时间', templet: setTimeOfEntry},
                {field: 'regular_time', width: '150', align: 'center', title: '转正时间', templet: setRegularTime},
                {field: 'contract_period', width: '100', align: 'center', title: '合同期限', templet: setPeriod},
                {field: 'contract_end_time', width: '150', align: 'center', title: '合同结束时间', templet: setContractEndTime},
                {field: 'probation_period', width: '150', align: 'center', title: '实习期', templet: setProbationPeriod},
                {field: 'practice_end_time', width: '150', align: 'center', title: '实习截止时间', templet: setPracticeEndTime},
                {field: 'id_card', width: '200', align: 'center', title: '身份证编号'},
                {field: 'birthday', width: '150', align: 'center', title: '出生日期', templet: setBirthday},
                {field: 'age', width: '100', align: 'center', title: '年龄'},
                {field: 'sex', width: '100', align: 'center', title: '性别'},
                {field: 'nation', width: '100', align: 'center', title: '民族'},
                {field: 'native_place', width: '200', align: 'center', title: '籍贯'},
                {field: 'graduate_school', width: '200', align: 'center', title: '毕业学校'},
                {field: 'major', width: '200', align: 'center', title: '专业'},
                {field: 'education', width: '100', align: 'center', title: '学历'},
                {field: 'graduate_time', width: '150', align: 'center', title: '毕业时间', templet: setGraduateTime},
                {field: 'political_outlook', width: '100', align: 'center', title: '政治面貌'},
                {field: 'language_level', width: '100', align: 'center', title: '外语等级'},
                {field: 'computer_level', width: '100', align: 'center', title: '计算机等级'},
                {field: 'marital_status', width: '100', align: 'center', title: '婚姻状况'},
                {field: 'working_hours', width: '150', align: 'center', title: '参加工作时间', templet: setWorkingHours},
                {field: 'work_unit', width: '200', align: 'center', title: '入职前工作单位'},
                {field: 'registered_residence', width: '200', align: 'center', title: '户籍所在地'},
                {field: 'registered_type', width: '100', align: 'center', title: '户籍类型'},
                {field: 'birth_address', width: '100', align: 'center', title: '出生地址'},
                {field: 'present_address', width: '200', align: 'center', title: '现居地址'},
                {field: 'emergency_contact', width: '100', align: 'center', title: '紧急联系人'},
                {field: 'relationship', width: '100', align: 'center', title: '与紧急联系人关系'},
                {field: 'contactInformation', width: '200', align: 'center', title: '紧急联系人联系方式'},
                {field: 'bank_card_info', width: '200', align: 'center', title: '银行卡信息'},
                {field: 'bank_card_num', width: '200', align: 'center', title: '银行卡号'},
                {field: 'internship_salary', width: '200', align: 'center', title: '实习薪资'},
                {field: 'probation_basic_salary', width: '200', align: 'center', title: '试用期基本薪资'},
                {field: 'probation_achieve_salary', width: '200', align: 'center', title: '试用期绩效工资'},
                {field: 'regular_basic_salary', width: '200', align: 'center', title: '转正基本薪资'},
                {field: 'regular_achieve_salary', width: '200', align: 'center', title: '转正绩效薪资'},
                {field: 'tax_subsidy', width: '200', align: 'center', title: '税后补贴'},
                {field: 'other_subsidies', width: '200', align: 'center', title: '其他补贴'},
                {field: 'num_of_insurance', width: '200', align: 'center', title: '基本养老保险基数'},
                {field: 'num_of_unemp_loyment_insurance', width: '200', align: 'center', title: '失业保险基数'},
                {field: 'num_of_medical_insurance', width: '200', align: 'center', title: '基本医疗保险基数'},
                {field: 'accumulation_fund_base', width: '200', align: 'center', title: '公积金基数'},
                {field: 'payment_month', width: '150', align: 'center', title: '缴纳月份', templet: setPayMonth},
                {field: 'social_security_type', width: '150', align: 'center', title: '社保类型'},
                {field: 'area_name', width: '150', align: 'center', title: '地区'},
                {field: 'employee_nature', width: '150', align: 'center', title: '员工性质'},
                {field: 'department_name', width: '200', align: 'center', title: '所在部门'},
                {field: 'role_name', width: '100', align: 'center', title: '岗位'},
                {field: 'incumbency', width: '100', align: 'center', title: '在职状态'},
                {field: 'post_attributes', width: '100', align: 'center', title: '岗位属性'},
                {field: 'post_rank', width: '100', align: 'center', title: '岗位职级'},
                {field: 'company_name', width: '200', align: 'center', title: '公司'},
                {field: 'superior_name', width: '100', align: 'center', title: '上级领导'},
                {field: 'business_str', width: '200', align: 'center', title: '所属业务线'},
                {field: 'attendance_num', width: '100', align: 'center', title: '考勤卡号'},
                {field: 'nature_of_work', width: '100', align: 'center', title: '工作性质'},
                {fixed: 'right', width: '120', title: '变更记录', toolbar: "#record", align: 'center'},
                {fixed: 'right', width: '170', title: '修改', toolbar: "#barDemo", align: 'center'}
            ]]
            , page: true
        });

        // table.reload('#userTable',{
        //     url: '/api/table/search',
        //     where: {'name':'',
        //         'company_id': 1} //设定异步数据接口的额外参数
        // });
        //表格按钮事件操作
        //监听工具条
        table.on('tool(test)', function (obj) {
            var data = obj.data;
            var user_id = data.user_id;
            var myUrl = '';
            // console.log(data);
            if (obj.event === 'base') {
                // console.log(user_id);
                myUrl =  '/erp/user/updateBase/' + user_id;
                setLayerOpen(myUrl)
            }
            if (obj.event === 'post') {
                myUrl = '/erp/user/updatePost/' + user_id + '?isAbnChange=0';
                setLayerOpen(myUrl)
            }
            if (obj.event === 'salary') {
                myUrl = '/erp/user/updateSalary/' + user_id + '?isAbnChange=0';
                setLayerOpen(myUrl)
            }
            if (obj.event === 'postRecord') {
                myUrl = '/erp/record/postRecord/' + user_id;
                setLayerOpen(myUrl)
            }
            if (obj.event === 'salaryRecord') {
                myUrl = '/erp/record/salaryRecord/' + user_id;
                setLayerOpen(myUrl)
            }
        });

        /**
         * 打开窗口
         * @param url 窗口中加载的url
         */
        function setLayerOpen(url) {
            layui.use('layer', function () {
                layer.open({
                    type: 2,
                    title: "编辑",
                    maxmin: true,
                    shadeClose: true, //点击遮罩关闭层
                    scrollbar: true,
                    area: ['900px', '600px'],
                    content: url,
                    end: function () {
                        table.reload('userTable')
                    }
                });
            });
        }
    });

    function setNameColor(d) {
        if (d.nature_of_work === "试用") {
            return "<span style='color: lightgreen;'>"+d.name+"</span>"
        }else if (d.nature_of_work === "实习"){
            return "<span style='color: #007DDB;'>"+d.name+"</span>"
        } else {
            return d.name
        }
    }

    /**
     * 设置表格显示合同期限
     * @param d 行数据
     * @returns {string}
     */
    function setPeriod(d) {
        if (d.contract_nature === "合同制") {
            return d.contract_period + '年';
        } else if (d.contract_nature === "实习") {
            return d.contract_period + '月';
        } else {
            return d.contract_period + '年';
        }
    }

    /**
     * 入职时间
     * @param d 行数据
     * @returns {*}
     */
    function setTimeOfEntry(d) {
        if (d.time_of_entry){
            return d.time_of_entry.slice(0, 10)
        }
        return '无'
    }

    /**
     * 工作时间
     * @param d 行数据
     * @returns {*}
     */
    function setWorkingHours(d) {
        if (d.working_hours){
            return d.working_hours.slice(0, 10)
        }
        return '无'
    }

    /**
     * 转正时间
     * @param d 行数据
     * @returns {*}
     */
    function setRegularTime(d) {
        if (d.regular_time){
            return d.regular_time.slice(0, 10)
        }
        return '无'
    }

    /**
     * 实习期限
     * @param d 行数据
     * @returns {string}
     */
    function setProbationPeriod(d) {
        if (d.probation_period){
            return d.probation_period + '月';
        }
        return '无'
    }

    /**
     * 实习截至时间
     * @param d 行数据
     * @returns {*}
     */
    function setPracticeEndTime(d) {
        if (d.practice_end_time) {
            return d.practice_end_time.slice(0, 10)
        } else {
            return '无'
        }
    }

    /**
     * 合同截至时间
     * @param d 行数据
     * @returns {*}
     */
    function setContractEndTime(d) {
        if (d.contract_end_time){
            return d.contract_end_time.slice(0, 10)
        }
        return '无'
    }

    /**
     * 出生日期
     * @param d 行数据
     * @returns {*}
     */
    function setBirthday(d) {
        if (d.birthday){
            return d.birthday.slice(0,10)
        }
        return '无'
    }

    /**
     * 社保缴纳月
     * @param d 行数据
     * @returns {*}
     */
    function setPayMonth(d) {
        if (d.payment_month) {
            return d.payment_month.slice(0, 10)
        }else {
            return '无'
        }
    }

    /**
     * 毕业时间
     * @param d 行数据
     * @returns {*}
     */
    function setGraduateTime(d) {
        if (d.graduate_time){
            return d.graduate_time.slice(0, 10)
        }else {
            return '无'
        }
    }
});