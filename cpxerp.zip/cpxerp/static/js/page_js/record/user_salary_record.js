$(function () {
    var user_id = $('#user_id_input').val();
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer;

        // 表格加载
        table.render({
            elem: '#salaryRecordTable',
            url: '/erp/record/salaryRecordSelect/'+user_id,
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'userTable',
            cols: [[
                {fixed: 'left', field: 'user_id', type:'numbers',width: '80', align: 'center', title: '#'},
                {field: 'CreateTime',width: '120', align: 'center', title: '变更时间', templet: setCreateTime},
                {field: 'BasicSalary',width: '100', align: 'center', title: '基础工资'},
                {field: 'AchieveSalary',width: '100', align: 'center', title: '绩效工资'},
                {field: 'Salary',width: '100', align: 'center', title: '总工资'},
                {field: 'NatureOfWork',width: '100', align: 'center', title: '工作性质'},
                {field: 'ChangeUser',width: '80', align: 'center', title: '修改人'},

                {fixed: 'right', field: 'IsAbnormalChange',width: '120', align: 'center', title: '是否异动', templet: isAbnormal},
            ]],
            page: true
        });
    });
    function isAbnormal(d) {
        // 如果是异动,异动的类型是什么
        if (d.IsAbnormalChange === 1) {
            return '<span class="layui-badge">'+ d.AbnType+'</span>'
        }
        if (d.IsAbnormalChange === -1){
            return '<span class="layui-badge layui-bg-blue">新建</span>'
        }
        return '<span class="layui-badge layui-bg-green">非异动</span>'
    }
    function setCreateTime(d) {
        if (d.CreateTime) {
            return d.CreateTime.slice(0,10)
        }
        return '无'
    }
});