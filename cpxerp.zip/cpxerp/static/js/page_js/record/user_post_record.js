$(function () {
    var user_id = $('#user_id_input').val();
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer;

        // 表格加载
        table.render({
            elem: '#postRecordTable',
            url: '/erp/record/postRecordSelect/'+user_id,
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'userTable',
            cols: [[
                {fixed: 'left', field: 'user_id', type:'numbers',width: '80', align: 'center', title: '#'},
                {field: 'CreateTime',width: '120', align: 'center', title: '变更时间', templet: setCreateTime},
                {field: 'AreaName',width: '80', align: 'center', title: '地区'},
                {field: 'DepartName',width: '120', align: 'center', title: '部门'},
                {field: 'Business',width: '140', align: 'center', title: '业务线'},
                {field: 'EmployeeNature',width: '120', align: 'center', title: '员工性质'},
                {field: 'Incumbency',width: '120', align: 'center', title: '在职状态'},
                {field: 'PostAttributes',width: '120', align: 'center', title: '岗位属性'},
                {field: 'PostRank',width: '120', align: 'center', title: '岗位职级'},
                {field: 'Role',width: '120', align: 'center', title: '岗位'},
                {field: 'NatureOfWork',width: '120', align: 'center', title: '工作性质'},
                {field: 'ChangeUser',width: '80', align: 'center', title: '修改人'},
                // 修改人
                {fixed: 'right', field: 'IsAbnormalChange',width: '120', align: 'center', title: '是否异动', templet: isAbnormal},
            ]],
            page: true
        });
    });
    function isAbnormal(d) {
        // 如果是异动,异动的类型是什么
        if (d.IsAbnormalChange === 1) {
            return '<span class="layui-badge">'+ d.AbnType+'</span>'
        }
        if (d.IsAbnormalChange === -1){
            return '<span class="layui-badge layui-bg-blue">新建</span>'
        }
        return '<span class="layui-badge layui-bg-green">非异动</span>'
    }
    function setCreateTime(d) {
        if (d.CreateTime) {
            return d.CreateTime.slice(0,10)
        }
        return '无'
    }
});