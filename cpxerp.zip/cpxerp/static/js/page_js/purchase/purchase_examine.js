$(function () {
    Date.prototype.Format = function (fmt) { //author: meizz
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;


        table.render({
            elem: '#purchaseTable',
            url: '/erp/purchase/purchaseSelectExamine',
            cellMinWidth: 80,
            width: 'full',
            height: 'full',
            id: 'purchaseTable',
            page: true,
            cols: [[
                {fixed: 'left', width: '80', type: 'numbers', align: 'center', title: '#'},
                {field: "user_name", width: '100', align: 'center', title: '申请人'},
                {field: "depart_name", width: '100', align: 'center', title: '部门'},
                {field: "apply_time", width: '180', align: 'center', templet: setApplyTime, title: '申请月份'},
                {width: '200', align: 'center', templet: setFile, title: '文件'},
                {
                    fixed: "right",
                    field: "depart_status",
                    width: '120',
                    align: 'center',
                    templet: setDepartStatus,
                    title: '审核状态'
                },
                {fixed: "right", width: '140', align: 'center', toolbar: '#barDemo', title: '操作'}
            ]]
        });

        table.on('tool(purchase)', function (obj) {
            var data = obj.data; //获得当前行数据
            var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
            // var tr = obj.tr; //获得当前行 tr 的DOM对象

            if (layEvent === 'pass') {       // 通过
                layer.confirm('是否确认通过?', {icon: 3, title: '是否确认'}, function (index) {
                    $.ajax({
                        url: '/erp/purchase/purchaseDoExamine/' + data.id,
                        type: 'put',
                        data: {
                            action: 1
                        },
                        success: showMsg
                    });
                });
            }
            if (layEvent === 'notPass') {   // 不通过
                layer.prompt({
                    formType: 2,
                    title: '请输入拒绝原因!',
                    area: ['300px', '350px'] //自定义文本域宽高
                }, function(value, index, elem){
                    $.ajax({
                        url: '/erp/purchase/purchaseDoExamine/' + data.id,
                        type: 'put',
                        data: {
                            action: 2,
                            reason: value
                        },
                        success: showMsg
                    });
                    layer.close(index);
                });
            }
        });

        function showMsg(data) {
            if (data.code === 0) {
                layer.msg(data.msg, {
                    icon: 1,
                    time: 2000 //2秒关闭（如果不配置，默认是3秒）
                }, function () {
                    table.reload('purchaseTable');
                });
            } else {
                layer.msg(data.msg, {
                    icon: 2,
                    time: 2000 //2秒关闭（如果不配置，默认是3秒）
                });
            }
        }

    });


    function setApplyTime(d) {
        return new Date(d.apply_time).Format("yyyy-MM")
    }

    function setFile(d) {
        return '<a href="' + d.file_url + '" target="_blank">' + d.file_name + '</a>'
    }

    function setDepartStatus(d) {
        if (d.examine_status === '0') {
            return '<span class="layui-badge layui-bg-blue">待审核</span>'
        } else if (d.examine_status === '1') {
            return '<span class="layui-badge layui-bg-green">通过</span>'
        } else {
            return '<span class="layui-badge">未通过</span>'
        }
    }
});