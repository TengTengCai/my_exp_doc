$(function () {
    Date.prototype.Format = function (fmt) { //author: meizz
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        laydate.render({
            elem: "#apply_time_input",
            type: 'month',
            value: new Date().Format("yyyy-MM")
        });

        //执行实例
        var uploadInst = upload.render({
            elem: '#upload_file', //绑定元素
            auto: false,
            bindAction: "#doAdd",
            accept: "file",
            field: "uploadName",
            url: '/erp/purchase/purchaseApplyDoAdd', //上传接口
            acceptMime: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel",
            before: function (obj) { //obj参数包含的信息，跟 choose回调完全一致，可参见上文。
                // layer.load(); //上传loading
            },
            data: {
                depart: $("#depart_select option:selected").val(),
                applyTime: $("#apply_time_input").val()
            },
            done: function (res) {
                //上传完毕回调
                layer.msg("申请提交成功!", {icon: 1});
                table.reload('purchaseTable');
            },
            error: function () {
                //请求异常回调
                layer.msg("申请提交s失败!", {icon: 2});
            }
        });

        table.render({
            elem: '#purchaseTable',
            url: '/erp/purchase/purchaseSelectByUser',
            cellMinWidth: 80,
            width: 'full',
            height: 'full',
            id: 'purchaseTable',
            page: true,
            cols: [[
                {fixed: 'left', width: '80', type: 'numbers', align: 'center', title: '#'},
                {field: "user_name", width: '100', align: 'center', title: '申请人'},
                {field: "depart_name", width: '100', align: 'center', title: '部门'},
                {field: "apply_time", width: '180', align: 'center', templet: setApplyTime, title: '申请月份'},
                {width: '200', align: 'center', templet: setFile, title: '文件'},
                {field: "personnel", width: '200', align: 'center', title: '审核人'},
                {field: "refuse_reason", width: '200', align: 'center', title: '拒绝理由'},
                {
                    fixed: "right",
                    field: "depart_status",
                    width: '120',
                    align: 'center',
                    templet: setDepartStatus,
                    title: '审核状态'
                },
            ]]
        });

    });
    $("#purchase_apply_form").on("submit", function (event) {
        event.preventDefault();
    });

    function setApplyTime(d) {
        return new Date(d.apply_time).Format("yyyy-MM")
    }

    function setFile(d) {
        return '<a href="' + d.file_url + '" target="_blank">' + d.file_name + '</a>'
    }

    function setDepartStatus(d) {
        if (d.examine_status === '0') {
            return '<span class="layui-badge layui-bg-blue">待审核</span>'
        } else if (d.examine_status === '1') {
            return '<span class="layui-badge layui-bg-green">通过</span>'
        } else {
            return '<span class="layui-badge">未通过</span>'
        }
    }
});