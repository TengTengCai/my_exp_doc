$(function () {
    Date.prototype.Format = function (fmt) { //author: meizz
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        laydate.render({
            elem: "#date_input",
            value: new Date().Format("yyyy-MM"),
            type: 'month'
        });

        table.render({
            elem: '#supplementTable',
            url: '/erp/attendance/supplementSelectHadPass',
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'supplementTable',
            page: true,
            cols: [[
                {fixed: 'left', width: '80', type: 'numbers', align: 'center', title: '#'},
                {field: "name", width: '100', align: 'center', title: '申请人'},
                {field: "sup_date", width: '120', align: 'center', templet: setSupTime, title: '日期'},
                {field: "slot_time", width: '180', align: 'center', title: '时间段'},
                {field: "reason", width: '200', align: 'center', title: '原因'},
                {field: "auditor", width: '200', align: 'center', templet: setAuditor, title: '审核人'},
                {field: "refuse_reason", width: '200', align: 'center', title: '拒绝理由'},
                {
                    fixed: "right",
                    field: "person_status",
                    width: '120',
                    align: 'center',
                    templet: setPersonStatus,
                    title: '审核状态'
                },
            ]]
        });

        form.on('submit(doSelect)', function (data) {
            var _data = data.field;
            // console.log(_data);
            table.reload('supplementTable', {
                url: '/erp/attendance/supplementSelectHadPass',
                where: _data
            });
        });

    });

    /**
     *
     * @param d
     * @returns {*}
     */
    function setSupTime(d) {
        return new Date(d.sup_date).Format("yyyy-MM-dd");
        // return d.end_time
    }

    /**
     *
     * @param d
     * @returns {*}
     */
    function setAuditor(d) {
        if (d.auditor === '0') {
            return '无'
        }
        return d.auditor_name
    }

    /**
     *
     * @param d
     * @returns {string}
     */
    function setPersonStatus(d) {
        if (d.person_status === '0') {
            return '<span class="layui-badge layui-bg-blue">待审核</span>'
        } else if (d.person_status === '1') {
            return '<span class="layui-badge layui-bg-green">通过</span>'
        } else {
            return '<span class="layui-badge">未通过</span>'
        }
    }

    $("#supplement_select_form").on("submit", function (event) {
        event.preventDefault();
    })
});