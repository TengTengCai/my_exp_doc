$(function () {
    Date.prototype.Format = function (fmt) { //author: meizz
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        laydate.render({
            elem: '#start_time_input',
            type: 'datetime'
        });
        laydate.render({
            elem: '#end_time_input',
            type: 'datetime'
        });


        form.on('submit(doAdd)', function (data) {
            var _data = data.field;
            // console.log(_data);
            $.ajax({
                url: '/erp/overtime/workOvertimeDoAdd',
                type: 'post',
                dataType: 'JSON',
                data: _data,
                success: function (res) {
                    if (res.code == 0) {
                        layer.msg(res.msg, {icon: 1, shade: 0.4, time: 1500});
                        setTimeout(parent.$(".layui-laypage-btn").click(), 1500);
                        setTimeout('parent.layer.closeAll()', 1500);//关闭layer
                        $('#work_overtime_apply_form').trigger('reset');
                        table.reload('workOvertimeTable',{
                            url: '/erp/overtime/workOvertimeSelectByUser',
                        });
                    } else {
                        parent.layer.msg(res.msg, {icon: 2, shade: 0.4, time: 1500});
                        setTimeout(1500);
                    }
                }
            });
        });

        table.render({
            elem: '#workOvertimeTable',
            url: '/erp/overtime/workOvertimeSelectByUser',
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'workOvertimeTable',
            page: true,
            cols: [[
                {fixed: 'left', width: '80', type: 'numbers', align: 'center', title: '#'},
                {field: "user_name", width: '100', align: 'center', title: '申请人'},
                {field: "depart_name", width: '100', align: 'center', title: '部门'},
                {field: "start_time", width: '180', align: 'center', templet: setStartTime, title: '开始时间' },
                {field: "end_time", width: '180', align: 'center', templet: setEndTime,title: '结束时间'},
                {field: "total_time", width: '120', align: 'center', title: '合计时间(小时)'},
                {field: "reason", width: '200', align: 'center', title: '说明'},
                {field: "leader_name", width: '200', align: 'center', title: '审核人'},
                {field: "refuse_reason", width: '200', align: 'center', title: '拒绝理由'},
                {fixed: "right", field: "depart_status", width: '120', align: 'center', templet:setDepartStatus, title: '审核状态'},
            ]]
        });
    });

    function setDepartStatus(d) {
        if (d.depart_status === '0') {
            return '<span class="layui-badge layui-bg-blue">待审核</span>'
        } else if (d.depart_status === '1') {
            return '<span class="layui-badge layui-bg-green">通过</span>'
        } else {
            return '<span class="layui-badge">未通过</span>'
        }
    }

    function setStartTime(d){
        return new Date(d.start_time).Format("yyyy-MM-dd hh:mm:ss");
        // return d.start_time
    }

    function setEndTime(d){
        return new Date(d.end_time).Format("yyyy-MM-dd hh:mm:ss");
        // return d.end_time
    }

    $('#work_overtime_apply_form').on('submit', function (event) {
        event.preventDefault();
    });
});