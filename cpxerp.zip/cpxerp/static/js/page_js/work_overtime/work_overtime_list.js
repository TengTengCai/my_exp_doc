$(function () {
    Date.prototype.Format = function (fmt) { //author: meizz
        var o = {
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds(), //秒
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度
            "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    };
    layui.use(['table', 'laydate', 'laytpl', 'layer', 'form', 'upload'], function () {
        var table = layui.table
            , form = layui.form
            , laydate = layui.laydate
            , laytpl = layui.laytpl
            , $ = layui.jquery
            , layer = layui.layer
            , upload = layui.upload;

        laydate.render({
            elem: '#date_input',
            type: 'month'
        });

        table.render({
            elem: '#workOvertimeTable',
            url: '/erp/overtime/workOvertimeSelectHadPass',
            cellMinWidth: 80,
            width: 'full',
            height: 'full-200',
            id: 'workOvertimeTable',
            page: true,
            cols: [[
                {fixed: 'left', width: '80', type: 'numbers', align: 'center', title: '#'},
                {field: "user_name", width: '100', align: 'center', title: '申请人'},
                {field: "work_type", width: '100', align: 'center', title: '加班类型'},
                {field: "depart_name", width: '100', align: 'center', title: '部门'},
                {field: "start_time", width: '180', align: 'center', templet:setStartTime, title: '开始时间'},
                {field: "end_time", width: '180', align: 'center', templet:setEndTime, title: '结束时间'},
                {field: "total_time", width: '120', align: 'center', title: '合计时间(小时)'},
                {field: "reason", width: '200', align: 'center', title: '说明'},
                {field: "leader_name", width: '200', align: 'center', title: '审核人'},
            ]]
        });

        form.on('select(depart)', function (data) {
            // console.log(data.elem); //得到select原始DOM对象
            // console.log(data.value); //得到被选中的值
            // console.log(data.othis); //得到美化后的DOM对象
            $.ajax({
                url: "/erp/user/getUsersByDepartId",
                type: "GET",
                data: {
                    departId: data.value
                },
                success: function (data) {
                    var mylist = data.data;
                    if (data.code === 0) {
                        var htmlStr = "<option></option>";
                        if (mylist != null) {
                            for (var i = 0; i < mylist.length; i++) {
                                var item = mylist[i];
                                htmlStr += '<option value="' + item.user_id + '">' + item.name + '</option>'
                            }
                        }
                        $('#applier_select').html(htmlStr);
                        form.render('select'); //刷新select选择框渲染
                    } else {
                        layer.msg('数据加载错误', {icon: 2, shade: 0.4, time: 1500});
                    }
                }
            })
        });

        form.on('submit(doSelect)', function (data) {
            var _data = data.field;
            // console.log(_data);
            table.reload('workOvertimeTable', {
                url: '/erp/overtime/workOvertimeSelectHadPass',
                where: _data
            });
        });
    });

    function setStartTime(d){
        return new Date(d.start_time).Format("yyyy-MM-dd hh:mm:ss");
        // return d.start_time
    }

    function setEndTime(d){
        return new Date(d.end_time).Format("yyyy-MM-dd hh:mm:ss");
        // return d.end_time
    }

    $('#output_btn').on('click', function (event) {
        var date = $('#date_input').val();
        window.open("/erp/overtime/worKOvertimeOutputExcel?Date="+date)
    });
    $('#work_overtime_list_form').on('submit', function (event) {
        event.preventDefault();
    })
});