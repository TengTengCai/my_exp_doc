package timerTask

import (
	"cpxerp/models"
	util "cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/robfig/cron"
	"time"
)

/*
定时任务1，提醒转正
*/
func Task1() {

	c := cron.New()
	spec := "0 0 1 * * ?" //每晚一点执行
	//spec := "*/10 * * * * ?"

	c.AddFunc(spec, func() {
		logs.Info("提醒非正式员工转正开始！")
		user := models.User{}
		users := user.SelectNotOfficialUsers()
		nowTime := time.Now()
		//初始化一个map，装在不同公司的预转正人员，key=companyid
		maps := make(map[int][]models.User)
		for _, v := range users {
			tim := v.RegularTime
			num := int(tim.Sub(nowTime).Minutes()) / (60 * 24)
			if num > 0 && num < 7 {
				//判断map里面是否含有此公司，没有就加入这个员工

				us := maps[v.CompanyId]
				us = append(us, v)
				maps[v.CompanyId] = us

				str := make([]string, 0)
				str = append(str, v.Email)
				//单独发送邮件给当前员工提醒转正
				util.SendEmail(str, "可以申请转正了！", "")

			}
		}

		//遍历以公司为组的人员，发送邮件至对应公司的人事邮箱
		for k, v := range maps {
			title := ""
			for i := 0; i < len(v); i++ {
				title = title + v[i].Name + "(" + v[i].EmployeeNum + ");"
			}
			//根据k查出公司的人事和行政专员，并发送邮件
			u := models.User{}
			hrUsers := u.SelectHRUsers()
			for _, h := range hrUsers {
				if h.CompanyId == k {
					too := make([]string, 0)
					too = append(too, h.Email)
					util.SendEmail(too, "下列员工可以申请转正了！", title)
				}
			}

		}
		logs.Info("提醒非正式员工转正结束！")
	})
	c.Start()
	select {}

}

/*
定时任务2，提醒合同到期
*/
func Task2() {

	c1 := cron.New()
	spec := "0 0 1 * * ?" //每晚一点执行
	//spec := "*/10 * * * * ?"

	c1.AddFunc(spec, func() {
		logs.Info("提醒合同到期开始！")
		user := models.User{}
		users := user.SelectNotOfficialUsers()
		nowTime := time.Now()
		//初始化一个map，装在不同公司的合同到期人员，key=companyid
		maps := make(map[int][]models.User)
		for _, v := range users {
			tim := v.ContractEndTime
			num := int(tim.Sub(nowTime).Minutes()) / (60 * 24)
			if num > 0 && num < 10 {
				//判断map里面是否含有此公司，没有就加入这个员工

				us := maps[v.CompanyId]
				us = append(us, v)
				maps[v.CompanyId] = us

			}
		}

		//遍历以公司为组的人员，发送邮件至对应公司的人事邮箱
		for k, v := range maps {
			title := ""
			for i := 0; i < len(v); i++ {
				title = title + v[i].Name + "(" + v[i].EmployeeNum + ");"
			}
			//根据k查出公司的人事和行政专员，并发送邮件
			u := models.User{}
			hrUsers := u.SelectHRUsers()
			for _, h := range hrUsers {
				if h.CompanyId == k {
					too := make([]string, 0)
					too = append(too, h.Email)
					util.SendEmail(too, "下列员工合同即将到期！", title)
				}
			}

		}
		logs.Info("提醒合同到期结束！")
	})
	c1.Start()
	select {}

}

/*
定时任务3，新年初始化员工年假
*/
func Task3() {

	c1 := cron.New()
	//spec := "0 0 1 * * ?" //每晚一点执行
	spec := "0 0 0 1 1 ?" //每年一月一号凌晨执行

	c1.AddFunc(spec, func() {
		logs.Info("年假重置开始！")
		user := models.User{}
		annualLeave := models.AnnualLeave{}
		all := annualLeave.SelectALL()
		for _, v := range all {
			u := user.GetByUserId(v.UserId)
			leave := models.MakeUserAnnualLeave(*u)
			leave.UpdateByUserId()
		}
		logs.Info("年假重置结束！")
	})
	c1.Start()
	select {}

}
