package models

import (
	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"time"
)

type Notice struct {
	NoticeId         int       `orm:"column(notice_id);pk;auto"`  //通知id
	Title            string    `orm:"column(title)"`              //标题
	Context          string    `orm:"column(context);size(5000)"` //内容
	NoticeType       string    `orm:"column(notice_type)"`        //类型
	FileName         string    `orm:"column(file_name)"`          //文件名字
	FileUrl          string    `orm:"column(file_url)"`           //文件下载地址
	CreateTime       time.Time `orm:"column(create_time)"`        //创建时间（发布时间）
	UpdateTime       time.Time `orm:"column(update_time);null"`   //修改时间
	CeoExamineStatus int       `orm:"column(ceo_examine_status)"` //ceo审核状态 0：待审核，1：审核通过，2：不通过
	Remark           string    `orm:"column(remark)"`             //备注，用于审核不通过情况填写
	CompanyId        int       `orm:"column(company_id)"`         //公司id
}

func init() {
	orm.RegisterModel(new(Notice))
}

/*
新增通知
*/
func (n *Notice) Add() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("INSERT INTO notice (title,context,notice_type,file_name,file_url,create_time,ceo_examine_status,company_id) VALUES(?,?,?,?,?,?,?,?)",
		n.Title, n.Context, n.NoticeType, n.FileName, n.FileUrl, n.CreateTime, n.CeoExamineStatus, n.CompanyId).Exec()
	if err != nil {
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
所有通知数据
*/
func (n *Notice) SelectAll(companyId, page, limit int) *uitl.Page {
	count := n.Count()
	newPage := uitl.NewPage(page, limit, count)
	notices := []Notice{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from notice where company_id =? ORDER BY create_time DESC  limit ?,?", companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&notices)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = &notices
	return newPage
}

/*
所有通知数据数量
*/
func (n *Notice) Count() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from notice").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
所有待审核通知数据
*/
func (n *Notice) SelectExamineAll(companyId, page, limit int) *uitl.Page {
	count := n.CountExamine()
	newPage := uitl.NewPage(page, limit, count)
	notices := []Notice{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from notice where company_id =? and ceo_examine_status=0 ORDER BY create_time DESC  limit ?,?", companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&notices)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = &notices
	return newPage
}

/*
所有待审核通知数据数量
*/
func (n *Notice) CountExamine() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from notice where ceo_examine_status=0").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
修改审核状态
*/
func (n *Notice) UpdateExamineStatus() (b bool, status int) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE notice SET ceo_examine_status=?, remark=? WHERE notice_id=?", n.CeoExamineStatus, n.Remark, n.NoticeId).Exec()
	if err != nil {
		logs.Error("update notcie faild", err)
		o.Rollback()
		return false, 0
	}
	o.Commit()
	return true, n.CeoExamineStatus
}

/*
所有审核通过通知数据
*/
func (n *Notice) SelectExamineOKAll(companyId, page, limit int) *uitl.Page {
	count := n.CountExamineOK()
	newPage := uitl.NewPage(page, limit, count)
	notices := []Notice{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from notice where company_id =? and ceo_examine_status=1 ORDER BY create_time DESC  limit ?,?", companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&notices)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = &notices
	return newPage
}

/*
所有审核通过通知数据数量
*/
func (n *Notice) CountExamineOK() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from notice where ceo_examine_status=1").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
根据id查询通知
*/
func (n *Notice) SelectById() *Notice {

	notice := Notice{}
	o := orm.NewOrm()
	err := o.Raw("select * from notice where notice_id =?", n.NoticeId).QueryRow(&notice)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}

	return &notice
}

/*
修改审核状态
*/
func (n *Notice) Update() (b bool) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE notice SET title=?, context=?, notice_type=?, file_name=?, file_url=?, update_time=?, ceo_examine_status=?, remark=? WHERE notice_id=?",
		n.Title, n.Context, n.NoticeType, n.FileName, n.FileUrl, n.UpdateTime, n.CeoExamineStatus, n.Remark, n.NoticeId).Exec()
	if err != nil {
		logs.Error("update notcie faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
删除通知信息
*/
func (n *Notice) Delete() (b bool) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("Delete from notice  WHERE notice_id=?", n.NoticeId).Exec()
	if err != nil {
		logs.Error("delete notcie faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}
