package models

import (
	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"strconv"
)

type ManagementRank struct {
	RankId   int    `orm:"column(rank_id);pk;auto"`
	RankName string `orm:"column(rank_name);"`
}

func (t *ManagementRank) TableName() string {
	return "management_rank"
}

func init() {
	orm.RegisterModel(new(ManagementRank))
}

func (t *ManagementRank) Add() bool {
	o := orm.NewOrm()
	o.Begin()
	p1 := ManagementRank{}

	num := p1.Count()
	if num == 0 {
		_, err := o.Raw("insert into management_rank(rank_name) values('M0')").Exec()
		if err != nil {
			o.Rollback()
			return false
		}
		o.Commit()
		return true
	} else {
		err := o.Raw("select * from management_rank order by rank_id DESC limit 1").QueryRow(&p1)
		if err != nil {
			return false
		}
		_, err = o.Raw("insert into management_rank(rank_name) values(?)", "M"+strconv.Itoa(p1.RankId)).Exec()
		if err != nil {
			o.Rollback()
			return false
		}
		o.Commit()
		return true
	}

}

func (t *ManagementRank) Count() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from management_rank").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

func (t *ManagementRank) Select(page int, limit int) *uitl.Page {
	count := t.Count()
	newPage := uitl.NewPage(page, limit, count)
	ms := []ManagementRank{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from management_rank limit ?,?", newPage.StartIndex, newPage.PageSize).QueryRows(&ms)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = &ms
	return newPage
}

func SelectAllMRank() []ManagementRank {
	o := orm.NewOrm()
	var mRanks []ManagementRank
	_, err := o.QueryTable("management_rank").All(&mRanks)
	if err != nil {
		return nil
	}
	return mRanks
}
