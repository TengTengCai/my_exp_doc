package models

import (
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"math"
	"strconv"
	"time"
)

type AnnualLeave struct {
	Id                  int       `orm:"column(id);pk;auto;" form:"Id"`                                                     //id
	UserId              int       `orm:"column(user_id)" form:"UserId"`                                                     //用户id
	UserName            string    `orm:"column(user_name);size(10)" form:"UserName"`                                        //员工姓名
	EmployeeNum         string    `orm:"column(employee_num);size(32)" form:"EmployeeNum"`                                  //员工编号
	HaveAnnualLeaveDays float64   `orm:"column(have_annual_leave_days);digits(12);decimals(2);";form:"HaveAnnualLeaveDays"` //应有的年假
	AnnualLeaveDays     float64   `orm:"column(annual_leave_days);digits(12);decimals(2);";form:"AnnualLeaveDays"`          //剩余年假
	UsedAnnualLeaveDays float64   `orm:"column(used_annual_leave_days);digits(12);decimals(2);";form:"UsedAnnualLeaveDays"` //已使用年假
	January             float64   `orm:"column(january);digits(12);decimals(1);";form:"January"`                            //一月
	February            float64   `orm:"column(february);digits(12);decimals(1);";form:"February"`                          //二月
	March               float64   `orm:"column(march);digits(12);decimals(1);";form:"March"`                                //三月
	April               float64   `orm:"column(april);digits(12);decimals(1);";form:"April"`                                //四月
	May                 float64   `orm:"column(may);digits(12);decimals(1);";form:"May"`                                    //五月
	June                float64   `orm:"column(june);digits(12);decimals(1);";form:"June"`                                  //六月
	July                float64   `orm:"column(july);digits(12);decimals(1);";form:"July"`                                  //七月
	August              float64   `orm:"column(august);digits(12);decimals(1);";form:"August"`                              //八月
	September           float64   `orm:"column(september);digits(12);decimals(1);";form:"September"`                        //九月
	October             float64   `orm:"column(october);digits(12);decimals(1);";form:"October"`                            //十月
	November            float64   `orm:"column(november);digits(12);decimals(1);";form:"November"`                          //十一月
	December            float64   `orm:"column(december);digits(12);decimals(1);";form:"December"`                          //十二月
	RegularTime         time.Time `orm:"column(regular_time);type(date);null"`
}

func init() {
	orm.RegisterModel(new(AnnualLeave))
}

const sqlAnnul = "INSERT INTO annual_leave (user_id,user_name,employee_num,annual_leave_days,used_annual_leave_days," +
	"january,february,march,april,may," +
	"june,july,august,september,october," +
	"november,december,have_annual_leave_days) VALUES "

func (a *AnnualLeave) Add() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw(sqlAnnul+" (?,?,?,?,?,"+
		"?,?,?,?,?,"+
		"?,?,?,?,?,"+
		"?,?,?)", a.UserId, a.UserName, a.EmployeeNum, a.AnnualLeaveDays, a.UsedAnnualLeaveDays,
		a.January, a.February, a.March, a.April, a.May,
		a.June, a.July, a.August, a.September, a.October,
		a.November, a.December, a.HaveAnnualLeaveDays).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("add annual_leave err,", err)
		return false
	}
	o.Commit()
	return true
}

/*
批量插入年假数据
*/
func (a *AnnualLeave) AddList(as []AnnualLeave) (bool, error) {
	o := orm.NewOrm()

	ansql := sqlAnnul
	for k, v := range as {
		if k == 0 {
			ansql = ansql + "('" + strconv.Itoa(v.UserId) + "','" + v.UserName + "','" + v.EmployeeNum + "','" + uitl.Float64ToString(v.AnnualLeaveDays) + "','" + uitl.Float64ToString(v.UsedAnnualLeaveDays) +
				"','" + uitl.Float64ToString(v.January) + "','" + uitl.Float64ToString(v.January) + "','" + uitl.Float64ToString(v.March) + "','" + uitl.Float64ToString(v.April) + "','" + uitl.Float64ToString(v.May) + "','" +
				uitl.Float64ToString(v.June) + "','" + uitl.Float64ToString(v.July) + "','" + uitl.Float64ToString(v.August) + "','" + uitl.Float64ToString(v.September) + "','" + uitl.Float64ToString(v.October) + "','" +
				uitl.Float64ToString(v.November) + "','" + uitl.Float64ToString(v.December) + "','" + uitl.Float64ToString(v.HaveAnnualLeaveDays) + "')"
		} else {
			ansql = ansql + ",('" + strconv.Itoa(v.UserId) + "','" + v.UserName + "','" + v.EmployeeNum + "','" + uitl.Float64ToString(v.AnnualLeaveDays) + "','" + uitl.Float64ToString(v.UsedAnnualLeaveDays) +
				"','" + uitl.Float64ToString(v.January) + "','" + uitl.Float64ToString(v.January) + "','" + uitl.Float64ToString(v.March) + "','" + uitl.Float64ToString(v.April) + "','" + uitl.Float64ToString(v.May) + "','" +
				uitl.Float64ToString(v.June) + "','" + uitl.Float64ToString(v.July) + "','" + uitl.Float64ToString(v.August) + "','" + uitl.Float64ToString(v.September) + "','" + uitl.Float64ToString(v.October) + "','" +
				uitl.Float64ToString(v.November) + "','" + uitl.Float64ToString(v.December) + "','" + uitl.Float64ToString(v.HaveAnnualLeaveDays) + "')"
		}
	}
	o.Begin()
	_, err := o.Raw(ansql).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("addList annual_leave err,", err)
		return false, err
	}
	o.Commit()
	return true, nil
}

/*
根据用户id查询年假
*/
func (a *AnnualLeave) SelectByUserId() *AnnualLeave {
	o := orm.NewOrm()
	an := AnnualLeave{}
	err := o.Raw("SELECT * FROM annual_leave WHERE user_id=?", a.UserId).QueryRow(&an)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return &an
}

/*
根据年假id查询年假
*/
func (a *AnnualLeave) SelectById() *AnnualLeave {
	o := orm.NewOrm()
	an := AnnualLeave{}
	err := o.Raw("SELECT * FROM annual_leave WHERE id=?", a.Id).QueryRow(&an)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return &an
}

/*
根据公司id分页查询员工年假
*/
func (a *AnnualLeave) SelectByCompanyIdByPage(companyId, page, limit int) *uitl.Page {
	count := a.Count(companyId)
	newPage := uitl.NewPage(page, limit, count)
	o := orm.NewOrm()
	ans := []AnnualLeave{}
	_, err := o.Raw("SELECT a.id,a.user_id,u.name as user_name,u.employee_num,a.have_annual_leave_days,a.annual_leave_days,a.used_annual_leave_days,"+
		"a.january,"+
		"a.february,"+
		"a.march,"+
		"a.april,"+
		"a.may,"+
		"a.june,"+
		"a.july,"+
		"a.august,"+
		"a.september,"+
		"a.october,"+
		"a.november,"+
		"a.december,"+
		"u.regular_time from annual_leave  a LEFT JOIN user u on u.user_id=a.user_id WHERE u.company_id=? AND u.incumbency !='离职' limit ?,?", companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&ans)
	if err != nil {
		logs.Error(err)
		return nil
	}
	newPage.Data = &ans
	return newPage
}

/*
根据公司id查询所有员工年假
*/
func (a *AnnualLeave) SelectALLByCompanyId(companyId int) []AnnualLeave {
	o := orm.NewOrm()
	ans := []AnnualLeave{}
	_, err := o.Raw("SELECT a.id,a.user_id,u.name as user_name,u.employee_num,a.have_annual_leave_days,a.annual_leave_days,a.used_annual_leave_days,"+
		"a.january,"+
		"a.february,"+
		"a.march,"+
		"a.april,"+
		"a.may,"+
		"a.june,"+
		"a.july,"+
		"a.august,"+
		"a.september,"+
		"a.october,"+
		"a.november,"+
		"a.december,"+
		"u.regular_time from annual_leave  a LEFT JOIN user u on u.user_id=a.user_id WHERE u.company_id=? AND u.incumbency !='离职' ", companyId).QueryRows(&ans)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return ans
}

/*
根据公司id统计员工数量
*/
func (a *AnnualLeave) Count(companyId int) int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from annual_leave  a LEFT JOIN user u on u.user_id=a.user_id WHERE u.company_id=? AND u.incumbency !='离职' ", companyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]
}

/*
根据用户id更新年假数据
*/
func (a *AnnualLeave) UpdateByUserId() bool {
	sqlUpAn := "UPDATE annual_leave set have_annual_leave_days=?, annual_leave_days=?,used_annual_leave_days=? "
	if a.January != 0 {
		sqlUpAn = sqlUpAn + ",january='" + uitl.Float64ToString(a.January) + "'"
	}
	if a.February != 0 {
		sqlUpAn = sqlUpAn + ",january='" + uitl.Float64ToString(a.February) + "'"
	}
	if a.March != 0 {
		sqlUpAn = sqlUpAn + ",march='" + uitl.Float64ToString(a.March) + "'"
	}
	if a.April != 0 {
		sqlUpAn = sqlUpAn + ",april='" + uitl.Float64ToString(a.April) + "'"
	}
	if a.May != 0 {
		sqlUpAn = sqlUpAn + ",may='" + uitl.Float64ToString(a.May) + "'"
	}
	if a.June != 0 {
		sqlUpAn = sqlUpAn + ",june='" + uitl.Float64ToString(a.June) + "'"
	}
	if a.July != 0 {
		sqlUpAn = sqlUpAn + ",july='" + uitl.Float64ToString(a.July) + "'"
	}
	if a.August != 0 {
		sqlUpAn = sqlUpAn + ",august='" + uitl.Float64ToString(a.August) + "'"
	}
	if a.September != 0 {
		sqlUpAn = sqlUpAn + ",september='" + uitl.Float64ToString(a.September) + "'"
	}
	if a.October != 0 {
		sqlUpAn = sqlUpAn + ",october='" + uitl.Float64ToString(a.January) + "'"
	}
	if a.November != 0 {
		sqlUpAn = sqlUpAn + ",november='" + uitl.Float64ToString(a.November) + "'"
	}
	if a.December != 0 {
		sqlUpAn = sqlUpAn + ",december='" + uitl.Float64ToString(a.December) + "'"
	}
	sqlUpAn = sqlUpAn + " where user_id=?"
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw(sqlUpAn, a.HaveAnnualLeaveDays, a.AnnualLeaveDays, a.UsedAnnualLeaveDays, a.UserId).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("update annual_leave err,", err)
		return false
	}
	o.Commit()
	return true
}

/*
查询年假表中现有数据，准备重置
*/
func (a *AnnualLeave) SelectALL() []AnnualLeave {
	o := orm.NewOrm()
	ans := []AnnualLeave{}
	_, err := o.Raw("SELECT * from annual_leave ").QueryRows(&ans)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return ans
}

//计算年假
func MakeUserAnnualLeave(user User) AnnualLeave {
	num := uitl.TimeDValue(user.WorkingHours, time.Now(), "1")
	annualLeave := AnnualLeave{}
	annualLeave.UserId = user.Id
	annualLeave.UserName = user.Name
	annualLeave.EmployeeNum = user.EmployeeNum
	annualLeave.UsedAnnualLeaveDays = 0
	annualLeave.January = 0
	annualLeave.February = 0
	annualLeave.March = 0
	annualLeave.April = 0
	annualLeave.May = 0
	annualLeave.June = 0
	annualLeave.July = 0
	annualLeave.August = 0
	annualLeave.September = 0
	annualLeave.October = 0
	annualLeave.November = 0
	annualLeave.December = 0
	//如果参加工作时间至今小于一年，没有年假
	if num < 365 {
		annualLeave.AnnualLeaveDays = 0
	}
	//如果参加工作大于一年小于10年，5天年假
	if num > 365 && (num < 365*10) {
		//如果入职时间为当前年，按比例计算年假
		annualLeave.HaveAnnualLeaveDays = 5
		if user.TimeOfEntry.Year() == time.Now().Year() {
			i := int(user.TimeOfEntry.Month())
			annualLeave.AnnualLeaveDays = math.Round(5 / 12.00 * (12 - float64(i)))
		} else {
			annualLeave.AnnualLeaveDays = 5
		}

	}
	//如果参加工作至今大于等于10年小于20年，10天年假
	if (num >= 365*10) && (num < 365*20) {
		//如果入职时间为当前年，按比例计算年假
		annualLeave.HaveAnnualLeaveDays = 10
		if user.TimeOfEntry.Year() == time.Now().Year() {
			i := int(user.TimeOfEntry.Month())
			annualLeave.AnnualLeaveDays = math.Round(10 / 12.00 * (12 - float64(i)))
		} else {
			annualLeave.AnnualLeaveDays = 10
		}

	}
	//大于等于20年，15天年假
	if num >= 365*20 {
		//如果入职时间为当前年，按比例计算年假
		annualLeave.HaveAnnualLeaveDays = 15
		if user.TimeOfEntry.Year() == time.Now().Year() {
			i := int(user.TimeOfEntry.Month())
			annualLeave.AnnualLeaveDays = math.Round(15 / 12.00 * (12 - float64(i)))
		} else {
			annualLeave.AnnualLeaveDays = 15
		}

	}
	return annualLeave
}
