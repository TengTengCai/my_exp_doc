package models

import (
	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"strconv"
	"time"
)

type Payroll struct {
	Id                        int       `orm:"column(id);pk;auto";form:"Id"`                                                                 //id
	EmployeeNum               string    `orm:"column(employee_num);size(32)" form:"EmployeeNum"`                                             //员工编号
	UserId                    int       `orm:"column(user_id)" form:"UserId"`                                                                //员工id
	UserName                  string    `orm:"column(user_name);size(10)" form:"UserName"`                                                   //员工姓名
	Age                       int       `orm:"column(age);" form:"Age"`                                                                      // 年龄
	PayMonth                  time.Time `orm:"column(pay_month);type(date)" form:"PayMonth"`                                                 //工资月份
	PostRank                  string    `orm:"column(post_rank);size(10)" form:"PostRank"`                                                   //岗位职级
	BasicSalary               float64   `orm:"column(basic_salary);digits(12);decimals(2);" form:"BasicSalary"`                              // 基本薪资
	AchieveSalary             float64   `orm:"column(achieve_salary);digits(12);decimals(2);"form:"AchieveSalary"`                           // 绩效工资
	QuarterlyBonus            float64   `orm:"column(quarterly_bonus);digits(12);decimals(2);"form:"QuarterlyBonus"`                         // 季度奖金
	OvertimePay               float64   `orm:"column(overtime_pay);digits(12);decimals(2);"form:"OvertimePay"`                               // 加班工资
	SickLeaveCutPayment       float64   `orm:"column(sick_leave_cut_payment);digits(12);decimals(2);"form:"SickLeaveCutPayment"`             // 病假扣款
	PersonalLeaveCutPayment   float64   `orm:"column(personal_leave_payment);digits(12);decimals(2);"form:"PersonalLeaveCutPayment"`         // 事假扣款
	AbsenteeismCutPayment     float64   `orm:"column(absenteeism_cut_payment);digits(12);decimals(2);"form:"AbsenteeismCutPayment"`          // 旷工扣款
	EntryNotFullCutPayment    float64   `orm:"column(entry_not_full_cut_payment);digits(12);decimals(2);"form:"EntryNotFullCutPayment"`      // 入职未满扣款
	QuitDeductionCutPayment   float64   `orm:"column(quit_deduction_cut_payment);digits(12);decimals(2);"form:"QuitDeductionCutPayment"`     // 离职扣款
	LateCutPayment            float64   `orm:"column(late_cut_payment);digits(12);decimals(2);"form:"LateCutPayment"`                        // 迟到扣款
	AttendanceTotalCutPayment float64   `orm:"column(attendance_total_cut_payment);digits(12);decimals(2);"form:"AttendanceTotalCutPayment"` // 考勤合计扣款
	Insurance                 float64   `orm:"column(insurance);digits(12);decimals(2);"form:"Insurance"`                                    // 养老保险
	UnempLoymentInsurance     float64   `orm:"column(unemp_loyment_insurance);digits(12);decimals(2);"form:"UnempLoymentInsurance"`          // 失业保险
	NumOfMedicalInsurance     float64   `orm:"column(num_of_medical_insurance);digits(12);decimals(2);"form:"NumOfMedicalInsurance"`         // 医疗保险
	AccumulationFund          float64   `orm:"column(accumulation_fund);digits(12);decimals(2);"form:"AccumulationFund"`                     // 公积金
	PersonalOtherInsurance    float64   `orm:"column(personal_other_insurance);digits(12);decimals(2);"form:"PersonalOtherInsurance"`        // 个人其他保险
	PersonalIncomeTax         float64   `orm:"column(personal_income_tax);digits(12);decimals(2);"form:"PersonalIncomeTax"`                  // 个人所得税
	ComputerSubsidy           float64   `orm:"column(computer_subsidy);digits(12);decimals(2);"form:"ComputerSubsidy"`                       // 电脑补贴
	FullAttendance            float64   `orm:"column(full_attendance);digits(12);decimals(2);"form:"FullAttendance"`                         // 全勤奖
	AfterTaxSubsidy           float64   `orm:"column(after_tax_subsidy);digits(12);decimals(2);"form:"AfterTaxSubsidy"`                      // 其他税后补贴
	OtherSubsidy              float64   `orm:"column(other_subsidy);digits(12);decimals(2);"form:"OtherSubsidy"`                             // 其他税前补贴
	FinalPay                  float64   `orm:"column(final_pay);digits(12);decimals(2);"form:"FinalPay"`                                     // 最终工资
	CompletionRate            float64   `orm:"column(completion_rate);digits(12);decimals(2);";form:"CompletionRate"`                        //月工作完成率得分
	ShowAttitude              float64   `orm:"column(show_attitude);digits(12);decimals(2);";form:"ShowAttitude"`                            //月工作表现得分
	Overall                   float64   `orm:"column(overall);digits(12);decimals(2);";form:"Overall"`                                       //综合得分
	ShowExplain               string    `orm:"column(show_explain);size(1000)";form:"ShowExplain"`                                           //绩效评语
	LackOfCard                float64   `orm:"column(lack_of_card);digits(12);decimals(2);" form:"LackOfCard"`                               //缺卡次数
	CompanyId                 int       `orm:"column(company_id)";form:"CompanyId"`                                                          //公司id
}

func init() {
	orm.RegisterModel(new(Payroll))
}

/*
根据id查询数据
*/
func (a *Payroll) SelectById(id int) *Payroll {
	o := orm.NewOrm()
	err := o.Raw("SELECT * FROM payroll  WHERE id=? ", id).QueryRow(&a)
	if err != nil {
		return nil
	}
	return a
}

/*
根据id更新数据
*/
func (a *Payroll) UpdateById() bool {
	o := orm.NewOrm()
	_, err := o.Raw("UPDATE payroll SET quarterly_bonus=?,personal_other_insurance=? ,computer_subsidy=?,full_attendance=?,"+
		" after_tax_subsidy=?, other_subsidy=? WHERE id=?", a.QuarterlyBonus, a.PersonalOtherInsurance, a.ComputerSubsidy, a.FullAttendance,
		a.AfterTaxSubsidy, a.OtherSubsidy, a.Id).Exec()
	if err != nil {
		return false
	}
	return true
}

/*
根据月份和公司查询数据
*/
func (a *Payroll) SelectByMonth(paymonth time.Time, companyId int) (*[]Payroll, bool) {
	o := orm.NewOrm()
	ps := []Payroll{}
	_, err := o.Raw("SELECT * FROM payroll  WHERE company_id=? and pay_month='"+paymonth.Format("2006-01-02")+"'", companyId).QueryRows(&ps)
	if err != nil {
		return nil, false
	}
	return &ps, true
}

func (p *Payroll) AddList(ps []Payroll, companyId int, paymonth time.Time, flag bool) bool {
	sqlPay := " INSERT into payroll (employee_num,user_id,user_name,age,pay_month," +
		"post_rank,basic_salary,achieve_salary,quarterly_bonus,overtime_pay," +
		"sick_leave_cut_payment,personal_leave_payment,absenteeism_cut_payment,entry_not_full_cut_payment,quit_deduction_cut_payment," +
		"late_cut_payment,attendance_total_cut_payment,insurance,unemp_loyment_insurance,num_of_medical_insurance," +
		"accumulation_fund,personal_other_insurance,personal_income_tax,computer_subsidy,full_attendance," +
		"after_tax_subsidy,other_subsidy,final_pay,completion_rate,show_attitude," +
		"overall,show_explain,lack_of_card,company_id) VALUES "
	o := orm.NewOrm()
	for k, v := range ps {
		if k == 0 {
			sqlPay = sqlPay + " ('" + v.EmployeeNum + "','" + strconv.Itoa(v.UserId) + "','" + v.UserName + "','" + strconv.Itoa(v.Age) + "','" + v.PayMonth.Format("2006-01-02") + "','" +
				v.PostRank + "','" + uitl.Float64ToString(v.BasicSalary) + "','" + uitl.Float64ToString(v.AchieveSalary) + "','" + uitl.Float64ToString(v.QuarterlyBonus) + "','" + uitl.Float64ToString(v.OvertimePay) + "','" +
				uitl.Float64ToString(v.SickLeaveCutPayment) + "','" + uitl.Float64ToString(v.PersonalLeaveCutPayment) + "','" + uitl.Float64ToString(v.AbsenteeismCutPayment) + "','" + uitl.Float64ToString(v.EntryNotFullCutPayment) + "','" + uitl.Float64ToString(v.QuitDeductionCutPayment) + "','" +
				uitl.Float64ToString(v.LateCutPayment) + "','" + uitl.Float64ToString(v.AttendanceTotalCutPayment) + "','" + uitl.Float64ToString(v.Insurance) + "','" + uitl.Float64ToString(v.UnempLoymentInsurance) + "','" + uitl.Float64ToString(v.NumOfMedicalInsurance) + "','" +
				uitl.Float64ToString(v.AccumulationFund) + "','" + uitl.Float64ToString(v.PersonalOtherInsurance) + "','" + uitl.Float64ToString(v.PersonalIncomeTax) + "','" + uitl.Float64ToString(v.ComputerSubsidy) + "','" + uitl.Float64ToString(v.FullAttendance) + "','" +
				uitl.Float64ToString(v.AfterTaxSubsidy) + "','" + uitl.Float64ToString(v.OtherSubsidy) + "','" + uitl.Float64ToString(v.FinalPay) + "','" + uitl.Float64ToString(v.CompletionRate) + "','" + uitl.Float64ToString(v.ShowAttitude) + "','" +
				uitl.Float64ToString(v.Overall) + "','" + v.ShowExplain + "','" + uitl.Float64ToString(v.LackOfCard) + "','" + strconv.Itoa(v.CompanyId) + "')"
		} else {
			sqlPay = sqlPay + " ,('" + v.EmployeeNum + "','" + strconv.Itoa(v.UserId) + "','" + v.UserName + "','" + strconv.Itoa(v.Age) + "','" + v.PayMonth.Format("2006-01-02") + "','" +
				v.PostRank + "','" + uitl.Float64ToString(v.BasicSalary) + "','" + uitl.Float64ToString(v.AchieveSalary) + "','" + uitl.Float64ToString(v.QuarterlyBonus) + "','" + uitl.Float64ToString(v.OvertimePay) + "','" +
				uitl.Float64ToString(v.SickLeaveCutPayment) + "','" + uitl.Float64ToString(v.PersonalLeaveCutPayment) + "','" + uitl.Float64ToString(v.AbsenteeismCutPayment) + "','" + uitl.Float64ToString(v.EntryNotFullCutPayment) + "','" + uitl.Float64ToString(v.QuitDeductionCutPayment) + "','" +
				uitl.Float64ToString(v.LateCutPayment) + "','" + uitl.Float64ToString(v.AttendanceTotalCutPayment) + "','" + uitl.Float64ToString(v.Insurance) + "','" + uitl.Float64ToString(v.UnempLoymentInsurance) + "','" + uitl.Float64ToString(v.NumOfMedicalInsurance) + "','" +
				uitl.Float64ToString(v.AccumulationFund) + "','" + uitl.Float64ToString(v.PersonalOtherInsurance) + "','" + uitl.Float64ToString(v.PersonalIncomeTax) + "','" + uitl.Float64ToString(v.ComputerSubsidy) + "','" + uitl.Float64ToString(v.FullAttendance) + "','" +
				uitl.Float64ToString(v.AfterTaxSubsidy) + "','" + uitl.Float64ToString(v.OtherSubsidy) + "','" + uitl.Float64ToString(v.FinalPay) + "','" + uitl.Float64ToString(v.CompletionRate) + "','" + uitl.Float64ToString(v.ShowAttitude) + "','" +
				uitl.Float64ToString(v.Overall) + "','" + v.ShowExplain + "','" + uitl.Float64ToString(v.LackOfCard) + "','" + strconv.Itoa(v.CompanyId) + "')"
		}
	}
	o.Begin()
	if flag {
		_, err := o.Raw("DELETE FROM payroll WHERE  company_id=? and  date_format(pay_month,'%Y-%m')='"+paymonth.Format("2006-01")+"'", companyId).Exec()
		if err != nil {
			o.Rollback()
			return false
		}
	}
	_, err := o.Raw(sqlPay).Exec()
	if err != nil {
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
条件查询数据
*/
func (p *Payroll) SelectByPage(page, limit, companyId int, maps map[string]string) *uitl.Page {
	o := orm.NewOrm()
	count := p.GetCount(companyId, maps)
	newPage := uitl.NewPage(page, limit, count)
	sqlpay := "SELECT p.id,u.employee_num,p.user_id,u.name AS user_name,u.age,p.pay_month,u.post_rank,p.basic_salary,p.achieve_salary," +
		" p.quarterly_bonus,p.overtime_pay,p.sick_leave_cut_payment,p.personal_leave_payment,p.absenteeism_cut_payment,p.entry_not_full_cut_payment," +
		" p.quit_deduction_cut_payment,p.late_cut_payment,p.attendance_total_cut_payment,p.insurance,p.unemp_loyment_insurance," +
		" p.num_of_medical_insurance,p.accumulation_fund,p.personal_other_insurance,p.personal_income_tax,p.computer_subsidy,p.full_attendance," +
		" p.after_tax_subsidy,p.other_subsidy,p.final_pay,p.completion_rate,p.show_attitude,p.overall,p.show_explain,p.lack_of_card" +
		" FROM payroll p" +
		" LEFT JOIN user u ON u.user_id=p.user_id" +
		" WHERE u.company_id=? "
	for k, v := range maps {
		if k == "pay_month" {
			sqlpay = sqlpay + " and date_format(p." + k + ",'%Y-%m')='" + v + "'"
		} else {
			sqlpay = sqlpay + " and p." + k + "='" + v + "'"
		}

	}
	sqlpay = sqlpay + " limit ?,?"
	payrolls := []Payroll{}
	_, err := o.Raw(sqlpay, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&payrolls)
	if err != nil {
		logs.Error("select payroll err,", err)
		return nil
	}
	newPage.Data = &payrolls
	return newPage
}

/*
根据公司id查询总数
*/
func (p *Payroll) GetCount(companyId int, maps map[string]string) int {
	var num []int
	o := orm.NewOrm()
	sqlPayCount := "SELECT COUNT(*) FROM payroll p " +
		" LEFT JOIN user u ON u.user_id=p.user_id " +
		" WHERE u.company_id=? "
	for k, v := range maps {
		if k == "pay_month" {
			sqlPayCount = sqlPayCount + " and date_format(" + k + ",'%Y-%m')='" + v + "'"
		} else {
			sqlPayCount = sqlPayCount + " and " + k + "='" + v + "'"
		}
	}
	_, err := o.Raw(sqlPayCount, companyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
个人查询工资条
*/
func (p *Payroll) SelectBySelf(companyId int, psymonth string) []Payroll {
	o := orm.NewOrm()
	pay := []Payroll{}
	sqlpay := "SELECT p.id,u.employee_num,p.user_id,u.name AS user_name,u.age,p.pay_month,u.post_rank,p.basic_salary,p.achieve_salary," +
		" p.quarterly_bonus,p.overtime_pay,p.sick_leave_cut_payment,p.personal_leave_payment,p.absenteeism_cut_payment,p.entry_not_full_cut_payment," +
		" p.quit_deduction_cut_payment,p.late_cut_payment,p.attendance_total_cut_payment,p.insurance,p.unemp_loyment_insurance," +
		" p.num_of_medical_insurance,p.accumulation_fund,p.personal_other_insurance,p.personal_income_tax,p.computer_subsidy,p.full_attendance," +
		" p.after_tax_subsidy,p.other_subsidy,p.final_pay,p.completion_rate,p.show_attitude,p.overall,p.show_explain,p.lack_of_card" +
		" FROM payroll p" +
		" LEFT JOIN user u ON u.user_id=p.user_id" +
		" WHERE u.company_id=? and date_format(pay_month,'%Y-%m')=? and p.user_id=?"
	_, err := o.Raw(sqlpay, companyId, psymonth, p.UserId).QueryRows(&pay)
	if err != nil {
		logs.Error("select payroll by self err,", err)
		return nil
	}
	return pay
}

func (v *Payroll) Upate() bool {
	sqlPay := " UPDATE payroll SET employee_num=?,user_id=?,user_name=?,age=?,pay_month=?," +
		"post_rank=?,basic_salary=?,achieve_salary=?,quarterly_bonus=?,overtime_pay=?," +
		"sick_leave_cut_payment=?,personal_leave_payment=?,absenteeism_cut_payment=?,entry_not_full_cut_payment=?,quit_deduction_cut_payment=?," +
		"late_cut_payment=?,attendance_total_cut_payment=?,insurance=?,unemp_loyment_insurance=?,num_of_medical_insurance=?," +
		"accumulation_fund=?,personal_other_insurance=?,personal_income_tax=?,computer_subsidy=?,full_attendance=?," +
		"after_tax_subsidy=?,other_subsidy=?,final_pay=?,completion_rate=?,show_attitude=?," +
		"overall=?,show_explain=?,lack_of_card=? WHERE id=? "
	o := orm.NewOrm()

	o.Begin()

	_, err := o.Raw(sqlPay, v.EmployeeNum, v.UserId, v.UserName, v.Age, v.PayMonth,
		v.PostRank, v.BasicSalary, v.AchieveSalary, v.QuarterlyBonus, v.OvertimePay,
		v.SickLeaveCutPayment, v.PersonalLeaveCutPayment, v.AbsenteeismCutPayment, v.EntryNotFullCutPayment, v.QuitDeductionCutPayment,
		v.LateCutPayment, v.AttendanceTotalCutPayment, v.Insurance, v.UnempLoymentInsurance, v.NumOfMedicalInsurance,
		v.AccumulationFund, v.PersonalOtherInsurance, v.PersonalIncomeTax, v.ComputerSubsidy, v.FullAttendance,
		v.AfterTaxSubsidy, v.OtherSubsidy, v.FinalPay, v.CompletionRate, v.ShowAttitude,
		v.Overall, v.ShowExplain, v.LackOfCard, v.Id).Exec()
	if err != nil {
		logs.Error(err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}
