package models

import (
	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"strconv"
)

type TechnicalRank struct {
	RankId   int    `orm:"column(rank_id);pk;auto"`
	RankName string `orm:"column(rank_name);"`
}

func (t *TechnicalRank) TableName() string {
	return "technical_rank"
}

func init() {
	orm.RegisterModel(new(TechnicalRank))
}

func (t *TechnicalRank) Add() bool {
	o := orm.NewOrm()
	o.Begin()
	p1 := TechnicalRank{}

	num := p1.Count()
	if num == 0 {
		_, err := o.Raw("insert into technical_rank(rank_name) values('T0')").Exec()
		if err != nil {
			o.Rollback()
			return false
		}
		o.Commit()
		return true
	} else {
		err := o.Raw("select * from technical_rank order by rank_id DESC limit 1").QueryRow(&p1)
		if err != nil {
			return false
		}
		_, err = o.Raw("insert into technical_rank(rank_name) values(?)", "T"+strconv.Itoa(p1.RankId)).Exec()
		if err != nil {
			o.Rollback()
			return false
		}
		o.Commit()
		return true
	}

}

func (t *TechnicalRank) Count() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from technical_rank").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

func (t *TechnicalRank) Select(page int, limit int) *uitl.Page {
	count := t.Count()
	newPage := uitl.NewPage(page, limit, count)
	ts := []TechnicalRank{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from technical_rank  limit ?,?", newPage.StartIndex, newPage.PageSize).QueryRows(&ts)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}

	newPage.Data = &ts
	return newPage
}

func SelectAllTRank() []TechnicalRank {
	o := orm.NewOrm()
	var tRanks []TechnicalRank
	_, err := o.QueryTable("technical_rank").All(&tRanks)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return tRanks
}
