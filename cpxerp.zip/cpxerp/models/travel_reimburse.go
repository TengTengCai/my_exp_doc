package models

import (
	"github.com/astaxie/beego/logs"
	"time"

	"cpxerp/util"
	"github.com/astaxie/beego/orm"
	"strconv"
)

type TravelReimburse struct {
	Id              int       `orm:"column(id);auto"form:"Id"`
	ApplyerId       int       `orm:"column(applyer_id)";form:"ApplyerId" description:"申请人ID"`
	ApplyerName     string    `orm:"column(applyer_name)";form:"ApplyerName" description:"申请人名字"`
	ApplyDepartId   int       `orm:"column(apply_depart_id)";form:"ApplyDepartId" description:"申请部门ID"`
	ApplyDepartName string    `orm:"column(apply_depart_name)";form:"ApplyDepartName" description:"申请部门名称"`
	ApplyTime       time.Time `orm:"column(apply_time);type(datetime)";form:"ApplyTime" description:"申请时间"`
	ApplyPrice      float64   `orm:"column(apply_price);digits(32);decimals(2)";form:"ApplyPrice" description:"申请价格"`
	Capitals        string    `orm:"column(capitals);size(64)";form:"Capitals" description:"金额大写"`
	CurType         string    `orm:"column(cur_type);size(8)";form:"CurType" description:"币种"`
	Outers          string    `orm:"column(outers);size(64)";form:"Outers" description:"外出人员名称"`
	OutStartTime    time.Time `orm:"column(out_start_time);type(date)";form:"OutStartTime" description:"出差开始时间"`
	OutEndTime      time.Time `orm:"column(out_end_time);type(date)";form:"OutEndTime" description:"出差结束时间"`
	OutReason       string    `orm:"column(out_reason);size(500)";form:"OutReason" description:"出差原因"`
	CompanyId       int       `orm:"column(company_id)";form:"CompanyId" description:"公司ID"`
	CompanyName     string    `orm:"column(company_name)";form:"CompanyName" description:"公司ID"`
	DepartStatus    int       `orm:"column(depart_status)";form:"DepartStatus" description:"部门审核状态"`
	FinancialStatus int       `orm:"column(financial_status)";form:"FinancialStatus" description:"财务审核状态"`
	CeoStatus       int       `orm:"column(ceo_status)";form:"CeoStatus" description:"ceo状态"`
	PayStatus       int       `orm:"column(pay_status)";form:"PayStatus" description:"支付状态"`
	FileUrl         string    `orm:"column(file_url)";form:"FileUrl" description:"文件地址"`
}

func (t *TravelReimburse) TableName() string {
	return "travel_reimburse"
}

func init() {
	orm.RegisterModel(new(TravelReimburse))
}

/*
插入差旅报销数据
*/
func (t *TravelReimburse) Add(details []TraReimburseDetail) bool {
	o := orm.NewOrm()
	o.Begin()
	result, err := o.Raw("INSERT INTO travel_reimburse ("+
		"applyer_id,apply_depart_id,apply_time,apply_price,capitals,"+
		"cur_type,outers,out_start_time,out_end_time,out_reason,"+
		"company_id,depart_status,financial_status,ceo_status,pay_status,file_url) VALUES("+
		"?,?,?,?,?,"+
		"?,?,?,?,?,"+
		"?,?,?,?,?,?)",
		t.ApplyerId, t.ApplyDepartId, t.ApplyTime, t.ApplyPrice, t.Capitals,
		t.CurType, t.Outers, t.OutStartTime, t.OutEndTime, t.OutReason,
		t.CompanyId, t.DepartStatus, t.FinancialStatus, t.CeoStatus, t.PayStatus, t.FileUrl).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("insert travel_reimburse err, ", err)
		return false
	}
	id, err := result.LastInsertId()
	if err != nil {
		return false
	}

	ids := strconv.Itoa(int(id))
	sql := "INSERT INTO tra_reimburse_detail(tra_reimburse_id,cost_item,cost_abstract,cost_price) VALUES "
	for i := 0; i < len(details); i++ {
		if i == 0 {
			sql = sql + "('" + ids + "','" + details[i].CostItem + "','" + details[i].CostAbstract + "'," + details[i].CostPrice + ")"
		} else {
			sql = sql + ",('" + ids + "','" + details[i].CostItem + "','" + details[i].CostAbstract + "'," + details[i].CostPrice + ")"
		}
	}
	_, err = o.Raw(sql).Exec()
	if err != nil {
		o.Rollback()
		return false
	}

	o.Commit()
	return true

}

/*
查询差旅报销数据，当前登录用户申请的数据，公司id
*/
func (t *TravelReimburse) SelectBySelf(page, limit int, user User, companyId int) *uitl.Page {
	var sql = "SELECT t.id,t.apply_time,t.apply_price,t.capitals,t.cur_type," +
		" t.outers,t.out_start_time,t.out_end_time,t.out_reason,t.depart_status," +
		" t.financial_status,t.ceo_status,t.pay_status,t.file_url,t.applyer_id,t.apply_depart_id,t.company_id," +
		" u1.name AS applyer_name,d.department_name AS apply_depart_name,c.company_name AS company_name" +
		" FROM travel_reimburse t" +
		" LEFT JOIN user u1 ON u1.user_id=t.applyer_id" +
		" LEFT JOIN department d ON d.department_id=t.apply_depart_id" +
		" LEFT JOIN company c ON c.company_id=t.company_id" +
		" WHERE t.applyer_id=? AND t.company_id=?" +
		" LIMIT ?,?"
	o := orm.NewOrm()
	count := t.CountBySelf(user, companyId)
	newPage := uitl.NewPage(page, limit, count)
	travelReimburses := []TravelReimburse{}
	_, err := o.Raw(sql, user.Id, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&travelReimburses)
	if err != nil {
		logs.Error("exec count faild", err)
		return nil
	}
	newPage.Data = travelReimburses
	return newPage
}

/*
统计差旅报销数据，当前登录用户申请的数据，公司id
*/
func (t *TravelReimburse) CountBySelf(user User, companyId int) int {
	var sql = "SELECT COUNT(*) " +
		" FROM travel_reimburse t " +
		" LEFT JOIN user u1 ON u1.user_id=t.applyer_id " +
		" LEFT JOIN department d ON d.department_id=t.apply_depart_id " +
		" LEFT JOIN company c ON c.company_id=t.company_id " +
		" WHERE t.applyer_id=? AND t.company_id=?"
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw(sql, user.Id, companyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
差旅审核查询，根据部门，财务，ceo权限不同查询，限定当前公司id
*/
func (c *TravelReimburse) SelectExamineData(page, limit int, modules map[string]bool, user User, companyId int) *uitl.Page {
	var sql = "SELECT t.id,t.apply_time,t.apply_price,t.capitals,t.cur_type," +
		" t.outers,t.out_start_time,t.out_end_time,t.out_reason,t.depart_status," +
		" t.financial_status,t.ceo_status,t.pay_status,t.file_url,t.applyer_id,t.apply_depart_id,t.company_id," +
		" u1.name AS applyer_name,d.department_name AS apply_depart_name,c.company_name AS company_name" +
		" FROM travel_reimburse t" +
		" LEFT JOIN user u1 ON u1.user_id=t.applyer_id" +
		" LEFT JOIN department d ON d.department_id=t.apply_depart_id" +
		" LEFT JOIN company c ON c.company_id=t.company_id"
	o := orm.NewOrm()
	count := c.CountExamineData(modules, user, companyId)
	newPage := uitl.NewPage(page, limit, count)
	travelReimburses := []TravelReimburse{}
	if modules["deppart_examine"] == true {
		sql = sql + " WHERE t.apply_depart_id=? and t.company_id=? AND t.depart_status=0 and t.financial_status=0 and t.ceo_status=0 limit ?,?"
		_, err := o.Raw(sql, user.DepartmentId, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&travelReimburses)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}
		newPage.Data = travelReimburses
		return newPage
	} else if modules["finance_examine"] == true {
		sql = sql + " WHERE t.company_id=? AND t.depart_status=1 and t.financial_status=0 and t.ceo_status=0 limit ?,?"
		_, err := o.Raw(sql, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&travelReimburses)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}
		newPage.Data = travelReimburses
		return newPage
	} else if modules["ceo_examine"] == true {
		sql = sql + " WHERE t.company_id=? AND t.depart_status=1 and t.financial_status=1 and t.ceo_status=0 limit ?,?"
		_, err := o.Raw(sql, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&travelReimburses)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}
		newPage.Data = travelReimburses
		return newPage
	} else {
		return nil
	}
}

/*
差旅审核统计，根据部门，财务，ceo权限不同统计，限定当前公司id
*/
func (c *TravelReimburse) CountExamineData(modules map[string]bool, user User, companyId int) int {
	var sql = "SELECT COUNT(*) " +
		" FROM travel_reimburse t " +
		" LEFT JOIN user u1 ON u1.user_id=t.applyer_id " +
		" LEFT JOIN department d ON d.department_id=t.apply_depart_id " +
		" LEFT JOIN company c ON c.company_id=t.company_id "
	var num []int
	o := orm.NewOrm()
	if modules["deppart_examine"] == true {
		sql = sql + " WHERE t.apply_depart_id=? and t.company_id=? AND t.depart_status=0 and t.financial_status=0 and t.ceo_status=0"
		_, err := o.Raw(sql, user.DepartmentId, companyId).QueryRows(&num)
		if err != nil {
			logs.Error("exec count faild", err)
			return 0
		}
		return num[0]
	} else if modules["finance_examine"] == true {
		sql = sql + " WHERE t.company_id=? AND t.depart_status=1 and t.financial_status=0 and t.ceo_status=0"
		_, err := o.Raw(sql, companyId).QueryRows(&num)
		if err != nil {
			logs.Error("exec count faild", err)
			return 0
		}
		return num[0]
	} else if modules["ceo_examine"] == true {
		sql = sql + " WHERE t.company_id=? AND t.depart_status=1 and t.financial_status=1 and t.ceo_status=0"
		_, err := o.Raw(sql, companyId).QueryRows(&num)
		if err != nil {
			logs.Error("exec count faild", err)
			return 0
		}
		return num[0]
	} else {
		return 0
	}
}

func GetOneTraReimburseById(id int) *TravelReimburse {
	o := orm.NewOrm()
	tr := &TravelReimburse{Id: id}
	if err := o.Read(tr); err != nil {
		return nil
	}
	return tr
}

/*
根据部门，财务，公司领导分别修改对应的审核状态
*/
func (c *TravelReimburse) UpdateStatus(modules map[string]bool, user User, status, travelReimburseId int) bool {
	o := orm.NewOrm()
	o.Begin()
	var sql string

	if modules["deppart_examine"] == true {
		sql = "UPDATE travel_reimburse SET depart_status=" + strconv.Itoa(status) + " WHERE id=? "
	}
	if modules["finance_examine"] == true {
		sql = "UPDATE travel_reimburse SET financial_status=" + strconv.Itoa(status) + " WHERE id=? "
	}
	if modules["ceo_examine"] == true {
		sql = "UPDATE travel_reimburse SET ceo_status=" + strconv.Itoa(status) + " WHERE id=?"
	}

	_, err := o.Raw(sql, travelReimburseId).Exec()
	if err != nil {
		o.Rollback()
		return false
	} else {
		o.Commit()
		return true
	}

}

/*
 查询所有通过审核的数据，公司id
*/
func (c *TravelReimburse) SelectByStatus(page, limit, companyId int) *uitl.Page {
	var sql = "SELECT t.id,t.apply_time,t.apply_price,t.capitals,t.cur_type," +
		" t.outers,t.out_start_time,t.out_end_time,t.out_reason,t.depart_status," +
		" t.financial_status,t.ceo_status,t.pay_status,t.file_url,t.applyer_id,t.apply_depart_id,t.company_id," +
		" u1.name AS applyer_name,d.department_name AS apply_depart_name,c.company_name AS company_name" +
		" FROM travel_reimburse t" +
		" LEFT JOIN user u1 ON u1.user_id=t.applyer_id" +
		" LEFT JOIN department d ON d.department_id=t.apply_depart_id" +
		" LEFT JOIN company c ON c.company_id=t.company_id WHERE t.company_id=? AND t.depart_status=1 and t.financial_status=1 and t.ceo_status=1 limit ?,?"
	o := orm.NewOrm()
	count := c.CountByStatus(companyId)
	newPage := uitl.NewPage(page, limit, count)
	tras := []TravelReimburse{}
	_, err := o.Raw(sql, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&tras)
	if err != nil {
		logs.Error("exec count faild", err)
		return nil
	}
	newPage.Data = tras
	return newPage
}

/*
  统计所有通过审核的借款数据数量，公司id
*/
func (c *TravelReimburse) CountByStatus(companyId int) int {
	var sql = "SELECT COUNT(*) " +
		" FROM travel_reimburse t " +
		" LEFT JOIN user u1 ON u1.user_id=t.applyer_id " +
		" LEFT JOIN department d ON d.department_id=t.apply_depart_id " +
		" LEFT JOIN company c ON c.company_id=t.company_id WHERE t.company_id=? AND t.depart_status=1 and t.financial_status=1 and t.ceo_status=1"
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw(sql, companyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]

}

/*
   修改放款状态
*/
func (c *TravelReimburse) UpdatePayStatus(travelReimburseId int) bool {
	o := orm.NewOrm()
	o.Begin()
	sql := "UPDATE travel_reimburse SET pay_status=1 WHERE id=? "
	_, err := o.Raw(sql, travelReimburseId).Exec()
	if err != nil {
		o.Rollback()
		return false
	} else {
		o.Commit()
		return true
	}
}
