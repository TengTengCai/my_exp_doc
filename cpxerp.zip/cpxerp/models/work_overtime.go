package models

import (
	"errors"
	"fmt"
	"reflect"
	"strings"
	"time"

	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
)

type WorkOvertime struct {
	Id           int       `orm:"column(id);auto" description:"加班申请Id"`
	Applier      int       `orm:"column(applier)" description:"申请人"`
	Depart       int       `orm:"column(depart);null" description:"部门Id"`
	WorkType     string    `orm:"column(work_type);size(8)" description:"加班类型"` // 平时,公休,节日
	Leader       int       `orm:"column(leader);null" description:"直属领导Id"`
	StartTime    time.Time `orm:"column(start_time);type(datetime);null" description:"开始时间"`
	EndTime      time.Time `orm:"column(end_time);type(datetime);null" description:"结束时间"`
	TotalTime    float64   `orm:"column(total_time);" description:"计算的本次加班时间,单位为小时"`
	Reason       string    `orm:"column(reason);size(256);null" description:"加班原因"`
	DepartStatus int8      `orm:"column(depart_status);null" description:"审核状态"`
	RefuseReason string    `orm:"column(refuse_reason);size(256);" description:"拒绝理由"`
	CreateTime   time.Time `orm:"column(create_time);type(datetime);auto_now_add" description:"创建时间"`
	CompanyId    int       `orm:"column(company_id)" description:"公司Id"`
}

func (t *WorkOvertime) TableName() string {
	return "work_overtime"
}

func init() {
	orm.RegisterModel(new(WorkOvertime))
}

// AddWorkOvertime insert a new WorkOvertime into database and returns
// last inserted Id on success.
func AddWorkOvertime(m *WorkOvertime) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetWorkOvertimeById retrieves WorkOvertime by Id. Returns error if
// Id doesn't exist
func GetWorkOvertimeById(id int) (v *WorkOvertime, err error) {
	o := orm.NewOrm()
	v = &WorkOvertime{Id: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllWorkOvertime retrieves all WorkOvertime matches certain condition. Returns empty list if
// no records exist
func GetAllWorkOvertime(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(WorkOvertime))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []WorkOvertime
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateWorkOvertime updates WorkOvertime by Id and returns error if
// the record to be updated doesn't exist
func UpdateWorkOvertimeById(m *WorkOvertime) (err error) {
	o := orm.NewOrm()
	v := WorkOvertime{Id: m.Id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteWorkOvertime deletes WorkOvertime by Id and returns error if
// the record to be deleted doesn't exist
func DeleteWorkOvertime(id int) (err error) {
	o := orm.NewOrm()
	v := WorkOvertime{Id: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&WorkOvertime{Id: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

func SelectWorkOvertimeByFilter(filter map[string]interface{}, page, limit int, o orm.Ormer) ([]orm.Params, error) {
	baseSql := "select w.*, " +
		"u.name as user_name, " +
		"u.employee_num, " +
		"u1.name as leader_name, " +
		"d.department_name as depart_name " +
		"from work_overtime as w " +
		"left join user as u " +
		"on u.user_id = w.applier " +
		"left join department as d " +
		"on d.department_id = w.depart " +
		"left join user as u1 " +
		"on u1.user_id = w.leader "
	isFirst := true
	for k, v := range filter {
		var sqlItem string
		kt, s := uitl.AnalyzeCondition(k)
		str := uitl.TypeToString(v)
		if isFirst {
			sqlItem = "where w." + kt + s + "'" + str + "' "
			isFirst = false
		} else {
			sqlItem = "and w." + kt + s + "'" + str + "' "
		}
		baseSql += sqlItem
	}

	baseSql += "order by -w.create_time "

	if page != 0 && limit != 0 {
		baseSql += "limit " + fmt.Sprint(limit*(page-1)) + ", " + fmt.Sprint(limit)
	}
	var work []orm.Params
	_, err := o.Raw(baseSql).Values(&work)
	if err != nil {
		logs.Info(err)
		o.Rollback()
		return nil, err
	}
	return work, nil
}

func GetWorkOvertimeCountByFilter(filter map[string]interface{}, o orm.Ormer) (int, error) {
	qs := o.QueryTable(new(WorkOvertime))
	for k, v := range filter {
		kt, s := uitl.AnalyzeCondition(k)
		kt = kt[:len(kt)-1]
		if s == "= " {
			qs = qs.Filter(kt, v)
		}
		if s == "< " {
			qs = qs.Filter(kt+"__lt", v)
		}
		if s == "<= " {
			qs = qs.Filter(kt+"__lte", v)
		}
		if s == "> " {
			qs = qs.Filter(kt+"__gt", v)
		}
		if s == ">= " {
			qs = qs.Filter(kt+"__gte", v)
		}
	}
	count, err := qs.Count()
	if err != nil {
		o.Rollback()
		return 0, err
	}
	return int(count), nil
}
