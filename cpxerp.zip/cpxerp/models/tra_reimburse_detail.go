package models

import (
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
)

type TraReimburseDetail struct {
	Id             int    `orm:"column(id)" json:"Id"`
	TraReimburseId int    `orm:"column(tra_reimburse_id)" json:"TraReimburseId" description:"差旅报销表单id"`
	CostItem       string `orm:"column(cost_item);size(45);null" json:"CostItem" description:"费用项目"`
	CostAbstract   string `orm:"column(cost_abstract);size(45);null" json:"CostAbstract" description:"费用摘要"`
	CostPrice      string `orm:"column(cost_price);size(45);null" json:"CostPrice" description:"费用金额"`
}

func (t *TraReimburseDetail) TableName() string {
	return "tra_reimburse_detail"
}

func init() {
	orm.RegisterModel(new(TraReimburseDetail))
}

/*
查询报销详情，根据报销单id
*/
func (t *TraReimburseDetail) SelectByTraId(traReimburseId int) *[]TraReimburseDetail {
	details := []TraReimburseDetail{}
	o := orm.NewOrm()
	_, err := o.Raw("SELECT * FROM tra_reimburse_detail WHERE tra_reimburse_id=?", traReimburseId).QueryRows(&details)
	if err != nil {
		logs.Error("exec select tra_reimburse_detail faild", err)
		return nil
	}
	return &details
}
