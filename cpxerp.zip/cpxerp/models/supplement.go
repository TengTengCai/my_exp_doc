package models

import (
	"errors"
	"fmt"
	"reflect"
	"strings"
	"time"

	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
)

type Supplement struct {
	Id           int       `orm:"column(id);auto" description:"主键"`
	Applier      int       `orm:"column(applier)" description:"申请人"`
	SupDate      time.Time `orm:"column(sup_date);type(date)" description:"申请补卡的日期"`
	SlotTime     string    `orm:"column(slot_time);size(8)" description:"时间段(上午,下午)"`
	Reason       string    `orm:"column(reason);size(256);null" description:"申请补卡原因"`
	PersonStatus int8      `orm:"column(person_status);null" description:"人事审核状态(0为待审核,1通过审核,2未通过审核)"`
	RefuseReason string    `orm:"column(refuse_reason);size(256);" description:"拒绝理由"`
	Auditor      int       `orm:"column(auditor);null" description:"审核操作人"`
	CompanyId    int       `orm:"column(company_id);" description:"公司Id"`
	CreateTime   time.Time `orm:"column(create_time); auto_now_add;" description:"创建时间"`
}

func (t *Supplement) TableName() string {
	return "supplement"
}

func init() {
	orm.RegisterModel(new(Supplement))
}

// AddSupplement insert a new Supplement into database and returns
// last inserted Id on success.
func AddSupplement(m *Supplement) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetSupplementById retrieves Supplement by Id. Returns error if
// Id doesn't exist
func GetSupplementById(id int) (v *Supplement, err error) {
	o := orm.NewOrm()
	v = &Supplement{Id: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllSupplement retrieves all Supplement matches certain condition. Returns empty list if
// no records exist
func GetAllSupplement(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(Supplement))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []Supplement
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateSupplement updates Supplement by Id and returns error if
// the record to be updated doesn't exist
func UpdateSupplementById(m *Supplement) (err error) {
	o := orm.NewOrm()
	v := Supplement{Id: m.Id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteSupplement deletes Supplement by Id and returns error if
// the record to be deleted doesn't exist
func DeleteSupplement(id int) (err error) {
	o := orm.NewOrm()
	v := Supplement{Id: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&Supplement{Id: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

func SelectSupplementByFilter(filter map[string]interface{}, page, limit int, o orm.Ormer) ([]orm.Params, error) {
	baseSql := "select s.*, " +
		"u.name, u.employee_num, " +
		"u1.name as auditor_name " +
		"from supplement as s " +
		"left join user as u " +
		"on u.user_id = s.applier " +
		"left join user as u1 " +
		"on u1.user_id = s.auditor "

	isFirst := true
	for k, v := range filter {
		var sqlItem string
		kt, s := uitl.AnalyzeCondition(k)
		str := uitl.TypeToString(v)
		if isFirst {
			sqlItem = "where s." + kt + s + "'" + str + "' "
			isFirst = false
		} else {
			sqlItem = "and s." + kt + s + "'" + str + "' "
		}
		baseSql += sqlItem
	}
	if page != 0 && limit != 0 {
		baseSql += "limit " + fmt.Sprint(limit*(page-1)) + ", " + fmt.Sprint(limit)
	}
	var supple []orm.Params
	_, err := o.Raw(baseSql).Values(&supple)
	if err != nil {
		logs.Info(err)
		o.Rollback()
		return nil, err
	}
	return supple, nil
}

func GetSupplementCountByFilter(filter map[string]interface{}, o orm.Ormer) (int, error) {
	qs := o.QueryTable(new(Supplement))
	for k, v := range filter {
		kt, s := uitl.AnalyzeCondition(k)
		kt = kt[:len(kt)-1]
		if s == "= " {
			qs = qs.Filter(kt, v)
		}
		if s == "< " {
			qs = qs.Filter(kt+"__lt", v)
		}
		if s == "<= " {
			qs = qs.Filter(kt+"__lte", v)
		}
		if s == "> " {
			qs = qs.Filter(kt+"__gt", v)
		}
		if s == ">= " {
			qs = qs.Filter(kt+"__gte", v)
		}
	}
	count, err := qs.Count()
	if err != nil {
		return 0, err
	}
	return int(count), nil
}
