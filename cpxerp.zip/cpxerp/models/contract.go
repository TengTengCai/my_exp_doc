/*
合同数据模型
auth: TTC
Date: 2018-08-16
*/
package models

import (
	"errors"
	"fmt"
	"github.com/astaxie/beego/logs"
	"reflect"
	"strings"
	"time"

	"cpxerp/util"
	"github.com/astaxie/beego/orm"
)

type Contract struct {
	Id                      int       `orm:"column(id);auto" form:"Id"`
	Type                    string    `orm:"column(type);size(8)" form:"Type" description:"合同类型"`
	Party                   int       `orm:"column(party)" form:"Party" description:"缔约方"`
	Partnner                int       `orm:"column(partnner)" form:"Partnner" description:"合作方"`
	CooperativeProject      int       `orm:"column(cooperative_project);" form:"CooperativeProject" description:"合作项目"`
	Channel                 string    `orm:"column(channel);size(16)" form:"Channel" description:"通道"`
	ProjectType             string    `orm:"column(project_type);size(16)" form:"ProjectType" description:"项目类型"`
	StartTime               time.Time `orm:"column(start_time);type(date)" form:"StartTime" description:"开始日期"`
	EndTime                 time.Time `orm:"column(end_time);type(date)" form:"EndTime" description:"结束日期"`
	PaymentMethod           string    `orm:"column(payment_method);size(16)" form:"PaymentMethod" description:"支付方式"`
	PaymentCurrency         string    `orm:"column(payment_currency);size(8)" form:"PaymentCurrency" description:"支付币种"`
	AccountPeriod           string    `orm:"column(account_period);size(16)" form:"AccountPeriod" description:"账期"`
	InvoiceTax              float32   `orm:"column(invoice_tax)" form:"InvoiceTax" description:"开票税点"`
	IsIncludeTax            int8      `orm:"column(is_include_tax)" form:"IsIncludeTax" description:"是否含税"`
	Discount                float32   `orm:"column(discount)" form:"Discount" description:"折扣百分比"`
	ContractCode            string    `orm:"column(contract_code);size(32)" form:"ContractCode" description:"合同编号"`
	CreateUser              int       `orm:"column(create_user)" form:"CreateUser" description:"创建用户"`
	DepartmenId             int       `orm:"column(departmen_id)" form:"DepartmenId" description:"部门ID"`
	UpdateTime              time.Time `orm:"column(update_time);type(datetime)" from:"-" description:"更新时间"`
	CreateTime              time.Time `orm:"column(create_time);type(datetime)" form:"-" description:"创建时间"`
	Remark                  string    `orm:"column(remark);null" form:"Remark" description:"备注"`
	FileUrl                 string    `orm:"column(file_url);size(256);null" form:"FileUrl" description:"合同文件的URL"`
	LeaderIspass            int8      `orm:"column(leader_ispass)" form:"LeaderIspass" description:"部门领导审核是否通过(0 待审核, 1审核通过, 2审核不通过)"`
	FinancialIsIntervention int8      `orm:"column(financial_is_intervention)" form:"FinancialIsIntervention" description:"财务部门是否介入"`
	FinancialIspass         int8      `orm:"column(financial_ispass)" form:"FinancialIspass" description:"财务部门审核是否通过(0 待审核, 1审核通过, 2审核不通过)"`
	CeoIspass               int8      `orm:"column(ceo_ispass)" form:"CeoIspass" description:"CEO审核是否通过(0 待审核, 1审核通过, 2审核不通过)"`
	IsOk                    int8      `orm:"column(is_ok)" form:"IsOk" description:"合同是否全部审核完成(0 待全部审核, 1审核通过, 2审核不通过)"`
	LeaderId                int       `orm:"column(leader_id)" form:"LeaderId" description:"审核的部门领导ID"`
	FinancialId             int       `orm:"column(financial_id);null" form:"FinancialId" description:"财务审核的财务ID"`
	CeoId                   int       `orm:"column(ceo_id);null" form:"CeoId" description:"CEO的ID哪个审核的"`
	RefuseInfo              string    `orm:"column(refuse_info);size(256);null" description:"审核拒绝理由"`
}

func (t *Contract) TableName() string {
	return "contract"
}

func init() {
	orm.RegisterModel(new(Contract))
}

// AddContract insert a new Contract into database and returns
// last inserted Id on success.
func AddContract(m *Contract) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetContractById retrieves Contract by Id. Returns error if
// Id doesn't exist
func GetContractById(id int) (v *Contract, err error) {
	o := orm.NewOrm()
	v = &Contract{Id: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllContract retrieves all Contract matches certain condition. Returns empty list if
// no records exist
func GetAllContract(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(Contract))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, v == "true" || v == "1")
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []Contract
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateContract updates Contract by Id and returns error if
// the record to be updated doesn't exist
func UpdateContractById(m *Contract) (err error) {
	o := orm.NewOrm()
	v := Contract{Id: m.Id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteContract deletes Contract by Id and returns error if
// the record to be deleted doesn't exist
func DeleteContract(id int) (err error) {
	o := orm.NewOrm()
	v := Contract{Id: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&Contract{Id: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

/*
多条件过滤查询,可查,合同编号关键字,分页
*/
func SelectContract(filter map[string]interface{}, key string, page int, limit int) []orm.Params {
	baseSql := "select con.*, dep.department_name, " +
		"com.company_name, " +
		"bu.business_name, " +
		"cus.customer_name, " +
		"u.name as user_name, " +
		"l.name as leader_name, " +
		"f.name as financial_name, " +
		"c.name as ceo_name " +
		"from contract as con " +
		"left join company as com " +
		"on con.party = com.company_id " +
		"left join department as dep " +
		"on con.departmen_id = dep.department_id " +
		"left join user as u " +
		"on con.create_user = u.user_id " +
		"left join user as l " +
		"on con.leader_id = l.user_id " +
		"left join user as f " +
		"on con.financial_id = f.user_id " +
		"left join user as c " +
		"on con.ceo_id = c.user_id " +
		"left join business as bu " +
		"on con.cooperative_project = bu.business_id " +
		"left join customer as cus " +
		"on con.partnner = cus.customer_id "
	isFirst := true
	for k, v := range filter {
		var sqlItem string
		kt, s := uitl.AnalyzeCondition(k)
		str := uitl.TypeToString(v)
		if isFirst {
			sqlItem = "where " + kt + s + "'" + str + "' "
			isFirst = false
		} else {
			sqlItem = "and " + kt + s + "'" + str + "' "
		}
		baseSql += sqlItem
	}

	if len(key) > 0 {
		if isFirst {
			baseSql += "where "
			isFirst = false
		} else {
			baseSql += "and "
		}
		baseSql += "contract_code like '%" + key + "%' "
	}
	if page != 0 && limit != 0 {
		baseSql += "limit " + fmt.Sprint(limit*(page-1)) + ", " + fmt.Sprint(limit)
	}

	var contracts []orm.Params
	o := orm.NewOrm()
	_, err := o.Raw(baseSql).Values(&contracts)

	if err != nil {
		return nil
	}

	return contracts

}

func GetSelectContractCount(filter map[string]interface{}, key string) int {
	o := orm.NewOrm()
	qs := o.QueryTable("contract")
	for k, v := range filter {
		qs = qs.Filter(k, v)
	}
	qs.Filter("contract_code__contains", key)
	count, err := qs.Count()
	if err != nil {
		return 0
	}
	return int(count)
}

/*
通过Id更新合同文件
*/
func UpdateContractFileUrl(id int, fileUrl string) {
	c := Contract{Id: id}
	o := orm.NewOrm()
	if err := o.Read(&c); err == nil {
		var num int64
		c.FileUrl = fileUrl
		if num, err = o.Update(&c); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}
