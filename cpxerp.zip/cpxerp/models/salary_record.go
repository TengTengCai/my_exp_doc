package models

import (
	"errors"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"reflect"
	"strings"
	"time"
)

type SalaryRecord struct {
	Id               int       `orm:"column(id);auto"`
	UserId           int       `orm:"column(user_id)"`
	AchieveSalary    float64   `orm:"column(achieve_salary);digits(12);decimals(2)"`
	BasicSalary      float64   `orm:"column(basic_salary);digits(12);decimals(2)"`
	Salary           float64   `orm:"column(salary);digits(12);decimals(2)"`
	NatureOfWork     string    `orm:"column(nature_of_work);size(16)" description:"工作性质"`          // 从user获取 工作性质：转正，试用，实习
	IsAbnormalChange int       `orm:"column(is_abnormal_change); default(0);" description:"是否是异动"` // 异动申请成功改变职位后会为1
	CreateTime       time.Time `orm:"column(create_time);type(date);auto_now_add;"`
	AbnType          string    `orm:"column(abn_type); size(16)"`   // 异动类型
	ChangeUser       string    `orm:"column(change_user); size(8)"` // 何人修改的数据
}

func (t *SalaryRecord) TableName() string {
	return "salary_record"
}

func init() {
	orm.RegisterModel(new(SalaryRecord))
}

// AddSalaryRecord insert a new SalaryRecord into database and returns
// last inserted Id on success.
func AddSalaryRecord(m *SalaryRecord) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetSalaryRecordById retrieves SalaryRecord by Id. Returns error if
// Id doesn't exist
func GetSalaryRecordById(id int) (v *SalaryRecord, err error) {
	o := orm.NewOrm()
	v = &SalaryRecord{Id: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllSalaryRecord retrieves all SalaryRecord matches certain condition. Returns empty list if
// no records exist
func GetAllSalaryRecord(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(SalaryRecord))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []SalaryRecord
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateSalaryRecord updates SalaryRecord by Id and returns error if
// the record to be updated doesn't exist
func UpdateSalaryRecordById(m *SalaryRecord) (err error) {
	o := orm.NewOrm()
	v := SalaryRecord{Id: m.Id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteSalaryRecord deletes SalaryRecord by Id and returns error if
// the record to be deleted doesn't exist
func DeleteSalaryRecord(id int) (err error) {
	o := orm.NewOrm()
	v := SalaryRecord{Id: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&SalaryRecord{Id: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

func GetSalaryRecordByFilter(filter map[string]interface{}, page, limit int) []SalaryRecord {
	o := orm.NewOrm()
	var salaryRecordList []SalaryRecord
	qs := o.QueryTable(new(SalaryRecord))
	for k, v := range filter {
		qs = qs.Filter(k, v)
	}
	if page != 0 || limit != 0 {
		qs.Offset(limit * (page - 1)).Limit(limit)
	}
	qs = qs.OrderBy("-create_time")
	_, err := qs.All(&salaryRecordList)
	if err != nil {
		return nil
	}
	return salaryRecordList
}

func GetSalaryRecordCountByFilter(filter map[string]interface{}) int {
	o := orm.NewOrm()
	qs := o.QueryTable(new(SalaryRecord))
	for k, v := range filter {
		qs = qs.Filter(k, v)
	}
	count, err := qs.Count()
	if err != nil {
		return 0
	}
	return int(count)
}
