package models

import (
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"time"
)

type AskLeave struct {
	LeaveId               int       `orm:"column(leave_id);pk;auto;" form:"LeaveId"`                     //请假单id
	UserId                int       `orm:"column(user_id)" form:"UserId"`                                //请假人id
	UserName              string    `orm:"column(user_name)" form:"UserName"`                            //请假人姓名
	EmployeeNum           string    `orm:"column(employee_num)" form:"EmployeeNum"`                      //员工编号
	DepartmentId          int       `orm:"column(department_id)" form:"DepartmentId"`                    //部门id
	DepartmentName        string    `orm:"column(department_name)" form:"DepartmentName"`                //部门名称
	LeaveType             string    `orm:"column(leave_type)" form:"LeaveType"`                          //请假类型
	LeaveStartTime        time.Time `orm:"column(leave_start_time);date;null" form:"LeaveStartTime"`     //请假开始时间
	LeaveEndTime          time.Time `orm:"column(leave_end_time);date;null" form:"LeaveEndTime"`         //请假结束时间
	LeaveReason           string    `orm:"column(leave_reason)" form:"LeaveReason"`                      //请假原因
	SuperiorId            int       `orm:"column(superior_id)" form:"SuperiorId"`                        //上级id
	SuperiorName          string    `orm:"column(superior_name)" form:"SuperiorName"`                    //上级姓名
	SuperiorExamineStatus int       `orm:"column(superior_examine_status)" form:"SuperiorExamineStatus"` //上级审核状态 0:待审核，1：通过，2：拒绝
	CeoExamineStatus      int       `orm:"column(ceo_examine_status)" form:"CeoExamineStatus"`           //大于3天假期需要ceo审核,0:待审核，1：通过，2：拒绝，3：无需审核
	LeaveDays             float64   `orm:"column(leave_days);digits(12);decimals(2);" form:"LeaveDays"`  //请假天数 0.5的变动值
	Days                  float64   `orm:"column(days);digits(12);decimals(2);" form:"Days"`             //销假补假天数 0.5的变动值
	HRExamineStatus       int       `orm:"column(hr_examine_status)" form:"HRExamineStatus"`             //人事审核销假补假情况11：销假待审核：12：补假待审额，通过，2：不通过,3:无需审核
	CreateTime            time.Time `orm:"column(create_time)" form:"CreateTime"`                        //申请时间
	Remark                string    `orm:"column(remark)" form:"Remark"`                                 // 备注，主要用于驳回请假填写
	StartType             string    `orm:"column(start_type)" form:"StartType"`                          // 开始时间上午或者下午
	EndType               string    `orm:"column(end_type)" form:"EndType"`                              // 结束时间上午或者下午
	CompanyId             int       `orm:"column(company_id)" form:"CompanyId"`                          // 公司id
	OffDays               float64   `orm:"column(off_days);digits(12);decimals(2);" form:"OffDays"`      //销假天数 0.5的变动值，不得大于请假天数
	LeaveOffTime          time.Time `orm:"column(leave_off_time);date;null" form:"LeaveOffTime"`         //销假时间
	OffType               string    `orm:"column(off_type)" form:"OffType"`                              //销假上午或者下午
	DelayDays             float64   `orm:"column(delay_days);digits(12);decimals(2);" form:"DelayDays"`  //补假天数 0.5的变动值
	LeaveDelayTime        time.Time `orm:"column(leave_delay_time);date;null" form:"LeaveDelayTime"`     //补假时间
	DelayType             string    `orm:"column(delay_type)" form:"DelayType"`                          //补假上午或者下午
	DelayReason           string    `orm:"column(delay_reason)" form:"DelayReason"`                      //补假原因
	OffFalg               bool      `orm:"-"`
	DelayFlag             bool      `orm:"-"`
}

func init() {
	orm.RegisterModel(new(AskLeave))
}

/*
insert数据
*/
func (l *AskLeave) Add() bool {
	o := orm.NewOrm()
	o.Begin()
	_, e := o.Raw("INSERT INTO ask_leave (user_id,user_name,department_id,department_name,leave_type,"+
		"leave_start_time,leave_end_time,leave_reason,superior_id,superior_examine_status,"+
		"ceo_examine_status,leave_days,create_time,start_type,end_type,company_id,hr_examine_status)VALUES(?,?,?,?,?,"+
		"?,?,?,?,?,"+
		"?,?,?,?,?,?,?)",
		l.UserId, l.UserName, l.DepartmentId, l.DepartmentName, l.LeaveType,
		l.LeaveStartTime, l.LeaveEndTime, l.LeaveReason, l.SuperiorId, l.SuperiorExamineStatus,
		l.CeoExamineStatus, l.LeaveDays, l.CreateTime, l.StartType, l.EndType, l.CompanyId, l.HRExamineStatus).Exec()
	if e != nil {
		o.Rollback()
		logs.Error("insert leave err , ", e)
		return false
	}
	o.Commit()
	return true

}

/*
查询个人数据，user_id
*/
func (l *AskLeave) SelectByUserId(page, limit int) *uitl.Page {
	o := orm.NewOrm()
	count := l.CountByUserId()
	newPage := uitl.NewPage(page, limit, count)
	as := []AskLeave{}
	_, err := o.Raw("select * from ask_leave where user_id=? ORDER BY create_time DESC limit ?,?", l.UserId, newPage.StartIndex, newPage.PageSize).QueryRows(&as)
	if err != nil {
		logs.Error(err)
		return nil
	}
	ntime := time.Now()
	for i := 0; i < len(as); i++ {
		endTime := as[i].LeaveEndTime.Format("2006-01-02 15:04:05")
		if as[i].LeaveEndTime.Unix() > ntime.Unix() {
			as[i].OffFalg = true
			as[i].DelayFlag = true
			continue
		} else if as[i].LeaveEndTime.Unix() < ntime.Unix() && uitl.CalculateTime(endTime, 0, 0, 10).Unix() >= ntime.Unix() {
			as[i].OffFalg = false
			as[i].DelayFlag = true
		} else {
			as[i].OffFalg = false
			as[i].DelayFlag = false
		}
	}
	newPage.Data = &as
	return newPage
}

/*
根据公司id统计员工数量
*/
func (l *AskLeave) CountByUserId() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from ask_leave where user_id=?", l.UserId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]
}

/*
查询上级待审核数据，上级id
*/
func (l *AskLeave) SelectBySuperiorId(page, limit int) *uitl.Page {
	o := orm.NewOrm()
	count := l.CountByUserId()
	newPage := uitl.NewPage(page, limit, count)
	as := []AskLeave{}
	_, err := o.Raw("select * from ask_leave where superior_id=? AND superior_examine_status=0 ORDER BY create_time DESC limit ?,?", l.SuperiorId, newPage.StartIndex, newPage.PageSize).QueryRows(&as)
	if err != nil {
		logs.Error(err)
		return nil
	}
	newPage.Data = &as
	return newPage
}

/*
根据上级待审核数据数量
*/
func (l *AskLeave) CountBySuperiorId() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from ask_leave where superior_id=? AND superior_examine_status=0", l.SuperiorId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]
}

/*
查询公司领导待审核数据，大于三天数据，状态待审核
*/
func (l *AskLeave) SelectByCeoStatus(page, limit int) *uitl.Page {
	o := orm.NewOrm()
	count := l.CountByUserId()
	newPage := uitl.NewPage(page, limit, count)
	as := []AskLeave{}
	_, err := o.Raw("select * from ask_leave where ceo_examine_status=0 AND superior_examine_status=1 AND company_id=? ORDER BY create_time DESC limit ?,?", l.CompanyId, newPage.StartIndex, newPage.PageSize).QueryRows(&as)
	if err != nil {
		logs.Error(err)
		return nil
	}
	newPage.Data = &as
	return newPage
}

/*
根据公司领导待审核数据数量
*/
func (l *AskLeave) CountByCeoStatus() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from ask_leave where ceo_examine_status=0 AND superior_examine_status=1  AND company_id=?", l.CompanyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]
}

/*
上级审核操作更新
*/
func (l *AskLeave) SupUpdateExamineStatus() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE ask_leave SET superior_examine_status=?, remark=? WHERE leave_id=?", l.SuperiorExamineStatus, l.Remark, l.LeaveId).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
ceo审核操作审核
*/
func (l *AskLeave) CeoUpdateExamineStatus() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE ask_leave SET ceo_examine_status=?, remark=? WHERE leave_id=?", l.CeoExamineStatus, l.Remark, l.LeaveId).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
删除某条数据
*/
func (l *AskLeave) DeleteById() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("Delete from ask_leave  WHERE leave_id=?", l.LeaveId).Exec()
	if err != nil {
		logs.Error("delete ask_leave faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
查询所有通过的数据展示
*/
func (l *AskLeave) SelectAllByPage(page, limit int) *uitl.Page {
	o := orm.NewOrm()
	count := l.CountAll()
	newPage := uitl.NewPage(page, limit, count)
	as := []AskLeave{}
	_, err := o.Raw("select * from ask_leave where ceo_examine_status in (1,3) AND superior_examine_status=1 AND company_id=? ORDER BY create_time DESC limit ?,?", l.CompanyId, newPage.StartIndex, newPage.PageSize).QueryRows(&as)
	if err != nil {
		logs.Error(err)
		return nil
	}
	newPage.Data = &as
	return newPage
}

/*
统计所有通过的数据的数量
*/
func (l *AskLeave) CountAll() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from ask_leave where ceo_examine_status in (1,3) AND superior_examine_status=1 AND company_id=?", l.CompanyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]
}

/*
更加id查询请假记录
*/
func (l *AskLeave) SelectById() *AskLeave {
	o := orm.NewOrm()
	err := o.Raw("select * from ask_leave where leave_id=?", l.LeaveId).QueryRow(&l)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return l
}

/*
 填入销假申请数据，更新销假字段，人事状态进入待审核
*/
func (l *AskLeave) UpdateOff() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE ask_leave SET leave_off_time=?, off_type=?,off_days=?,hr_examine_status=? WHERE leave_id=?", l.LeaveOffTime, l.OffType, l.OffDays, l.HRExamineStatus, l.LeaveId).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
人事审核操作，审核通过：修改请假原有数据，销假数据还原，人事状态通过
不通过：销假数据还原，人事状态不通过
*/
func (l *AskLeave) UpdateLeaveByOff() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE ask_leave SET leave_end_time=?, leave_days=?,leave_off_time=?, off_type=?,off_days=?,hr_examine_status=? WHERE leave_id=?", l.LeaveEndTime, l.LeaveDays, l.LeaveOffTime, l.OffType, l.OffDays, l.HRExamineStatus, l.LeaveId).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
查询所有Hr待审核的销假数据
*/
func (l *AskLeave) SelectAllOffByPage(page, limit int) *uitl.Page {
	o := orm.NewOrm()
	count := l.CountAll()
	newPage := uitl.NewPage(page, limit, count)
	as := []AskLeave{}
	_, err := o.Raw("select * from ask_leave where ceo_examine_status in (1,3) AND superior_examine_status=1 AND  hr_examine_status=11 AND company_id=? ORDER BY create_time DESC limit ?,?", l.CompanyId, newPage.StartIndex, newPage.PageSize).QueryRows(&as)
	if err != nil {
		logs.Error(err)
		return nil
	}
	newPage.Data = &as
	return newPage
}

/*
统计所有通过待审核的销假数据的数量
*/
func (l *AskLeave) CountOffAll() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from ask_leave where ceo_examine_status in (1,3) AND superior_examine_status=1 AND  hr_examine_status=11 AND company_id=?", l.CompanyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]
}

/*
填入补假申请数据，更新补假字段，人事状态进入待审核
*/
func (l *AskLeave) UpdateDelay() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE ask_leave SET leave_delay_time=?, delay_type=?,delay_days=?,hr_examine_status=? WHERE leave_id=?", l.LeaveDelayTime, l.DelayType, l.DelayDays, l.HRExamineStatus, l.LeaveId).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
人事审核操作，审核通过：修改请假原有数据，销假数据还原，人事状态通过
不通过：销假数据还原，人事状态不通过
*/
func (l *AskLeave) UpdateLeaveByDelay() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE ask_leave SET leave_end_time=?, leave_days=?,leave_delay_time=?, delay_type=?,delay_days=?,hr_examine_status=? WHERE leave_id=?", l.LeaveEndTime, l.LeaveDays, l.LeaveDelayTime, l.DelayType, l.DelayDays, l.HRExamineStatus, l.LeaveId).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
查询所有Hr待审核的补假数据
*/
func (l *AskLeave) SelectAllDelayByPage(page, limit int) *uitl.Page {
	o := orm.NewOrm()
	count := l.CountAll()
	newPage := uitl.NewPage(page, limit, count)
	as := []AskLeave{}
	_, err := o.Raw("select * from ask_leave where ceo_examine_status in (1,3) AND superior_examine_status=1 AND  hr_examine_status=12 AND company_id=? ORDER BY create_time DESC limit ?,?", l.CompanyId, newPage.StartIndex, newPage.PageSize).QueryRows(&as)
	if err != nil {
		logs.Error(err)
		return nil
	}
	newPage.Data = &as
	return newPage
}

/*
统计所有通过待审核的补假数据的数量
*/
func (l *AskLeave) CountDelayAll() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from ask_leave where ceo_examine_status in (1,3) AND superior_examine_status=1 AND  hr_examine_status=12 AND company_id=?", l.CompanyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]
}
