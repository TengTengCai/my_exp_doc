/*
普通报销数据模型
*/
package models

import (
	"errors"
	"github.com/astaxie/beego/logs"
	"reflect"
	"strings"
	"time"

	"cpxerp/util"
	"github.com/astaxie/beego/orm"
)

type OrdinaryReimburse struct {
	Id              int       `orm:"column(id);pk;auto"`
	Applyer         int       `orm:"column(applyer)" description:"申请人"`
	ApplyDepart     int       `orm:"column(apply_depart)" description:"申请部门"`
	ApplyTime       time.Time `orm:"column(apply_time);type(datetime)" description:"申请时间"`
	ApplyPrice      float64   `orm:"column(apply_price);digits(32);decimals(2)" description:"申请金额"`
	Capitals        string    `orm:"column(capitals);size(64)" description:"大写金额"`
	CurType         string    `orm:"column(cur_type);size(8)" description:"申请币种"`
	CompanyId       int       `orm:"column(company_id)" description:"公司ID"`
	DepartStatus    int8      `orm:"column(depart_status)" description:"部门审核状态"`
	FinancialStatus int8      `orm:"column(financial_status)" description:"财务审核状态"`
	CeoStatus       int8      `orm:"column(ceo_status)" description:"ceo审核状态"`
	PayStatus       int8      `orm:"column(pay_status)" description:"支付状态"`
	FileUrl         string    `orm:"column(file_url);size(256)" description:"报销文件URL"`
	LeaderId		int       `orm:"column(leader_id);" description:"直属领导ID"`
}

func (t *OrdinaryReimburse) TableName() string {
	return "ordinary_reimburse"
}

func init() {
	orm.RegisterModel(new(OrdinaryReimburse))
}

// AddOrdinaryReimburse insert a new OrdinaryReimburse into database and returns
// last inserted Id on success.
func AddOrdinaryReimburse(m *OrdinaryReimburse) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetOrdinaryReimburseById retrieves OrdinaryReimburse by Id. Returns error if
// Id doesn't exist
func GetOrdinaryReimburseById(id int) (v *OrdinaryReimburse, err error) {
	o := orm.NewOrm()
	v = &OrdinaryReimburse{Id: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllOrdinaryReimburse retrieves all OrdinaryReimburse matches certain condition. Returns empty list if
// no records exist
func GetAllOrdinaryReimburse(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(OrdinaryReimburse))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []OrdinaryReimburse
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateOrdinaryReimburse updates OrdinaryReimburse by Id and returns error if
// the record to be updated doesn't exist
func UpdateOrdinaryReimburseById(m *OrdinaryReimburse) (err error) {
	o := orm.NewOrm()
	v := OrdinaryReimburse{Id: m.Id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteOrdinaryReimburse deletes OrdinaryReimburse by Id and returns error if
// the record to be deleted doesn't exist
func DeleteOrdinaryReimburse(id int) (err error) {
	o := orm.NewOrm()
	v := OrdinaryReimburse{Id: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&OrdinaryReimburse{Id: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

/*
普通订单查询方法
Auth: TTC
Daye: 2018-08-23
*/
func SelectOrdReimburse(filter map[string]interface{}, order string, page int, limit int) []orm.Params {
	baseSql := "select ord.*, u.name, d.department_name, c.company_name " +
		"from ordinary_reimburse as ord " +
		"left join user as u " +
		"on u.user_id = ord.applyer " +
		"left join department as d " +
		"on d.department_id = ord.apply_depart " +
		"left join company as c " +
		"on c.company_id = ord.company_id "
	isFirst := true
	for k, v := range filter {
		var sqlItem string
		kt, s := uitl.AnalyzeCondition(k)
		str := uitl.TypeToString(v)
		if isFirst {
			sqlItem = "where ord." + kt + s + "'" + str + "' "
			isFirst = false
		} else {
			sqlItem = "and ord." + kt + s + "'" + str + "' "
		}
		baseSql += sqlItem
	}
	if len(order) > 0 {
		baseSql += "order by " + order
	}
	baseSql += " limit ?, ?;"
	o := orm.NewOrm()
	var reimburseList []orm.Params
	_, err := o.Raw(baseSql, limit*(page-1), limit).Values(&reimburseList)
	if err != nil {
		return nil
	}
	return reimburseList
}
func GetSelectOrdReimburseCount(filter map[string]interface{}) int {
	o := orm.NewOrm()
	qs := o.QueryTable("ordinary_reimburse")
	for k, v := range filter {
		qs = qs.Filter(k, v)
	}
	count, err := qs.Count()
	if err != nil {
		return 0
	}
	return int(count)
}
