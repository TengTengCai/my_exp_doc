package models

import (
	//"time"

	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"strconv"
	"time"
)

type Customer struct {
	Id                  int       `orm:"column(customer_id);auto";form:"-"`
	CustomerName        string    `orm:"column(customer_name);size(32)";form:"CustomerName"`                //客户名称
	Abbreviation        string    `orm:"column(abbreviation);size(20)";form:"Abbreviation"`                 //客户简称
	Attribute           string    `orm:"column(attribute);size(10)";form:"Attribute"`                       //单位属性
	CustomerManagerId   int       `orm:"column(customer_manager_id)";form:"CustomerManagerId"`              //客户经理Id
	FollowUserId        int       `orm:"column(follow_user_id)";form:"FollowUserId"`                        //跟进人员
	AddrURL             string    `orm:"column(addr_url);size(100)";form:"AddrURL"`                         //网址
	StepId              int       `orm:"column(step_id);size(50)";form:"StepId"`                            //阶段Id
	StepName            string    `orm:"column(step_name);size(12)";form:"StepName"`                        //阶段名称
	ProductTypesId      int       `orm:"column(product_types_id);size(11)";form:"ProductTypesId"`           //产品类型id
	ProductTypesName    string    `orm:"column(product_types_name);size(100)";form:"ProductTypesName"`      //产品类型名称
	StartTime           time.Time `orm:"column(start_time);size(20)";form:"StartTime"`                      //开始时间
	CompanyAddress      string    `orm:"column(company_address);size(100)";form:"CompanyAddress"`           //工公司地址
	CustomerCode        string    `orm:"column(customer_code);size(12)";form:"CustomerCode"`                //客户编号
	CreateUserId        int       `orm:"column(create_user_id)";form:"CreateUserId"`                        //创建人
	CreateTime          time.Time `orm:"column(create_time);size(20)";form:"CreateTime"`                    //创建时间
	CompanyId           int       `orm:"column(company_id)";form:"CompanyId"`                               //公司id
	AuditStatus         int       `orm:"column(audit_status);size(11)";form:"AuditStatus"`                  //审核状态 待审核：0，通过：1，未通过：2
	AuditDepartmentId   int       `orm:"column(audit_department_id);size(11)";form:"AuditDepartmentId"`     //审核部门Id
	AuditDepartmentName string    `orm:"column(audit_department_Name);size(50)";form:"AuditDepartmentName"` //审核部门名称
	AuditUserId         int       `orm:"column(audit_user_id);size(11)";form:"AuditUserId"`                 //审核人员Id
	AuditUserName       string    `orm:"column(audit_user_name);size(50)";form:"AuditUserName"`             //审核人员
	CustomerManagerName string    `orm:"column(customer_manager_name)";form:"CustomerManagerName"`          //客户经理名字
	FollowUserName      string    `orm:"column(follow_user_name);size(50)";form:"FollowUserName"`           //对接人员名字
	CreateUserName      string    `orm:"column(create_user_name)";form:"CreateUserName"`                    //录入人员名字
	CompanyName         string    `orm:"column(company_name)";form:"CompanyName"`                           //公司名字
	Remarks             string    `orm:"column(remarks)";form:"CompanyName"`                                //备注
	Contacts            []Contact `orm:"-";form:"Contacts"`                                                 //公司名字
	//Competitor      string     `orm:"column(competitor);size(20)"`      //竞争对手
	//DeliveryTime string `orm:"column(deliveryTime);size(20)"` //预计投放时间
	//GeneralBudget   float64    `orm:"column(generalBudget)"`            //总预算
	//GoogleBudget    float64    `orm:"column(googleBudget)"`             //google预算
	//FacebookBudget  float64    `orm:"column(facebookBudget)"`           //facebook预算
	//CustomerSource  string     `orm:"column(customerSource);size(20)"`  //客户来源
	//PaymentDays     string     `orm:"column(paymentDays);size(4)"`      //账期
}

type Contact struct {
	Id             int    `orm:"column(contact_id);auto";form:"-";json:"Id"`
	ContactName    string `orm:"column(contact_name);size(20)";form:"ContactName";json:"ContactName"`            //联系人姓名
	ContactPost    string `orm:"column(contact_post);size(20)";form:"ContactPost";json:"ContactPost"`            //联系人职位
	ContactPhone   string `orm:"column(contact_phone);size(30)";form:"ContactPhone";json:"ContactPhone"`         //联系人电话
	ContactMail    string `orm:"column(contract_mail);size(30)";form:"ContactMail";json:"ContactMail"`           //联系人邮箱
	ContactAddress string `orm:"column(contract_address);size(100)";form:"ContactAddress";json:"ContactAddress"` //联系人地址
	CustomerId     int    `orm:"column(customer_id)";form:"-";json:"CustomerId"`                                 //客户Id
}

func (t *Customer) TableName() string {
	return "customer"
}

func init() {
	orm.RegisterModel(new(Customer), new(Contact))
}

/*
根据客户id查询客户信息
*/
func (c *Customer) GetCustomerById() *Customer {
	o := orm.NewOrm()
	err := o.Raw("SELECT * FROM customer WHERE customer_id=?", c.Id).QueryRow(&c)
	if err != nil {
		logs.Error("exec select customer faild", err)
		return nil
	}
	return c
}

/*
 插入客户数据
*/
func (c *Customer) Add() (bool, error) {
	o := orm.NewOrm()
	o.Begin()
	result, err := o.Raw("INSERT into customer("+
		"customer_name,abbreviation,attribute,follow_user_id,addr_url,"+
		"step_id,product_types_id,start_time,"+
		"company_address,create_user_id,create_time,company_id,audit_department_id,"+
		"remarks) VALUES("+
		"?,?,?,?,?,"+
		"?,?,?,"+
		"?,?,?,?,?,"+
		"?)",
		c.CustomerName, c.Abbreviation, c.Attribute, c.FollowUserId, c.AddrURL,
		c.StepId, c.ProductTypesId, c.StartTime,
		c.CompanyAddress, c.CreateUserId, c.CreateTime, c.CompanyId, c.AuditDepartmentId,
		c.Remarks).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("insert customer err, ", err)
		return false, err
	}
	id, err := result.LastInsertId()
	if err != nil {
		return false, err
	}
	if len(c.Contacts) > 0 {
		ids := strconv.Itoa(int(id))
		sql := "INSERT INTO contact (contact_name,contact_post,contact_phone,contract_mail,contract_address,customer_id) VALUES "
		for i := 0; i < len(c.Contacts); i++ {
			if i == 0 {
				sql = sql + "('" + c.Contacts[i].ContactName + "','" + c.Contacts[i].ContactPost + "','" + c.Contacts[i].ContactPhone + "','" + c.Contacts[i].ContactMail + "','" + c.Contacts[i].ContactAddress + "'," + ids + ")"
			} else {
				sql = sql + ",('" + c.Contacts[i].ContactName + "','" + c.Contacts[i].ContactPost + "','" + c.Contacts[i].ContactPhone + "','" + c.Contacts[i].ContactMail + "','" + c.Contacts[i].ContactAddress + "'," + ids + ")"
			}
		}
		_, err = o.Raw(sql).Exec()
		if err != nil {
			o.Rollback()
			return false, err
		}
	}

	o.Commit()
	return true, nil
}

const sql = "select c.customer_id,c.customer_name,c.abbreviation,c.attribute,c.customer_manager_id, " +
	"c.follow_user_id,c.addr_url,c.step_id,b.business_name as step_name, " +
	"c.product_types_id,b1.business_name as product_types_name,c.start_time,c.company_address, " +
	"c.customer_code,c.create_user_id,c.create_time,c.company_id,c.audit_status, " +
	"c.audit_department_id,d.department_name as audit_department_Name,c.audit_user_id,u2.name as audit_user_name, " +
	"c.customer_manager_name,u.name as follow_user_name,u1.name as create_user_name,cp.company_name,c.remarks " +
	"from customer c " +
	"LEFT JOIN user u on u.user_id=c.follow_user_id " +
	"LEFT JOIN user u1 ON u1.user_id=c.create_user_id " +
	"LEFT JOIN user u2 ON u2.user_id=c.audit_user_id " +
	"LEFT JOIN business b ON b.business_id=c.step_id " +
	"LEFT JOIN business b1 ON b1.business_id=c.product_types_id " +
	"LEFT JOIN company cp ON cp.company_id=c.company_id " +
	"LEFT JOIN department d ON d.department_id=c.audit_department_id "

/*
分页查询数据，根据当前公司id，如果是普通员工只能查询当前自己提交的，如果是部门领导查询当前部门的，财务及公司领导查询所有的
*/
func (c *Customer) GetAllByPage(page, limit, companyId, roleLevel int, user User, maps map[string]interface{}) *uitl.Page {
	if maps == nil {
		if roleLevel == 1 {
			count := c.GetCountByUserId(user.Id, nil)
			newPage := uitl.NewPage(page, limit, count)
			customers := []Customer{}
			o := orm.NewOrm()
			_, err := o.Raw(sql+" WHERE c.company_id=? AND c.create_user_id=? limit ?,?", companyId, user.Id, newPage.StartIndex, newPage.PageSize).QueryRows(&customers)
			if err != nil {
				logs.Error("exec select faild", err)
				return nil
			}
			newPage.Data = &customers
			return newPage
		} else if roleLevel == 2 {
			count := c.GetCountByDepartmentId(companyId, user.DepartmentId, nil)
			newPage := uitl.NewPage(page, limit, count)
			customers := []Customer{}
			o := orm.NewOrm()
			_, err := o.Raw(sql+" WHERE c.company_id=? AND c.audit_department_id=? limit ?,?", companyId, user.DepartmentId, newPage.StartIndex, newPage.PageSize).QueryRows(&customers)
			if err != nil {
				logs.Error("exec select faild", err)
				return nil
			}
			newPage.Data = &customers
			return newPage
		} else {
			count := c.GetCount(companyId, nil)
			newPage := uitl.NewPage(page, limit, count)
			customers := []Customer{}
			o := orm.NewOrm()
			_, err := o.Raw(sql+" WHERE c.company_id=? limit ?,?", companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&customers)
			if err != nil {
				logs.Error("exec select faild", err)
				return nil
			}
			newPage.Data = &customers
			return newPage
		}
	} else {
		if roleLevel == 1 {
			sqlm := sql + " WHERE c.company_id=? AND c.create_user_id=? "
			sql1 := makeSql(sqlm, maps)
			sql1 = sql1 + " limit ?,?"

			count := c.GetCountByUserId(user.Id, maps)
			newPage := uitl.NewPage(page, limit, count)
			customers := []Customer{}
			o := orm.NewOrm()
			_, err := o.Raw(sql1, companyId, user.Id, newPage.StartIndex, newPage.PageSize).QueryRows(&customers)
			if err != nil {
				logs.Error("exec select faild", err)
				return nil
			}
			newPage.Data = &customers
			return newPage
		} else if roleLevel == 2 {
			sqlm := sql + " WHERE c.company_id=? AND c.audit_department_id=? "
			sql1 := makeSql(sqlm, maps)
			sql1 = sql1 + " limit ?,?"

			count := c.GetCountByDepartmentId(companyId, user.DepartmentId, maps)
			newPage := uitl.NewPage(page, limit, count)
			customers := []Customer{}
			o := orm.NewOrm()
			_, err := o.Raw(sql1, companyId, user.DepartmentId, newPage.StartIndex, newPage.PageSize).QueryRows(&customers)
			if err != nil {
				logs.Error("exec select faild", err)
				return nil
			}
			newPage.Data = &customers
			return newPage
		} else {
			sqlm := sql + " WHERE c.company_id=? "
			sql1 := makeSql(sqlm, maps)
			sql1 = sql1 + " limit ?,?"
			count := c.GetCount(companyId, maps)
			newPage := uitl.NewPage(page, limit, count)
			customers := []Customer{}
			o := orm.NewOrm()
			_, err := o.Raw(sql1, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&customers)
			if err != nil {
				logs.Error("exec select faild", err)
				return nil
			}
			newPage.Data = &customers
			return newPage
		}
	}

}

/*
分页查询待审核的数据
*/
func (c *Customer) GetExamine(page, limit, companyId, roleLevel int, user User) *uitl.Page {
	if roleLevel >= 2 {
		count := c.GetExamineCountByDepartmentId(companyId, user.DepartmentId)
		newPage := uitl.NewPage(page, limit, count)
		customers := []Customer{}
		o := orm.NewOrm()
		_, err := o.Raw(sql+" WHERE c.company_id=? AND c.audit_department_id=? AND c.audit_status=0 limit ?,?", companyId, user.DepartmentId, newPage.StartIndex, newPage.PageSize).QueryRows(&customers)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}
		newPage.Data = &customers
		return newPage
	} else {
		return nil
	}
}

/*
跟客户id修改审核状态
*/
func (c *Customer) UpdateAuditStatusById() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE customer SET audit_user_id=?, audit_department_id=?, audit_status=?,remarks=? WHERE customer_id=?", c.AuditUserId, c.AuditDepartmentId, c.AuditStatus, c.Remarks, c.Id).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("exec del contact faild", err)
		return false
	}
	o.Commit()
	return true
}

/*
根据客户id修改用户信息
*/
func (c *Customer) UpdateCustomer() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE customer SET customer_name=?,abbreviation=?,attribute=?,follow_user_id=?,addr_url=?,step_id=?,product_types_id=?,company_address=?,remarks=?,audit_status=? WHERE customer_id=?", c.CustomerName, c.Abbreviation,
		c.Attribute, c.FollowUserId, c.AddrURL, c.StepId, c.ProductTypesId, c.CompanyAddress, c.Remarks, c.AuditStatus, c.Id).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("exec del contact faild", err)
		return false
	}
	o.Commit()
	return true
}

/*
根据权限获取客户名字和id数据，非重复
*/
func (c *Customer) GetAllCustomer(companyId, roleLevel int, user User) *[]Customer {

	if roleLevel == 1 {

		customers := []Customer{}
		o := orm.NewOrm()
		_, err := o.Raw("select * from customer WHERE company_id=? AND create_user_id=? GROUP BY customer_name", companyId, user.Id).QueryRows(&customers)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}

		return &customers
	} else if roleLevel == 2 {
		customers := []Customer{}
		o := orm.NewOrm()
		_, err := o.Raw("select * from customer WHERE company_id=? AND audit_department_id=? GROUP BY customer_name ", companyId, user.DepartmentId).QueryRows(&customers)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}

		return &customers
	} else {
		customers := []Customer{}
		o := orm.NewOrm()
		_, err := o.Raw("select * from customer WHERE company_id=? GROUP BY customer_name", companyId).QueryRows(&customers)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}
		return &customers
	}
}
func GetPassCustomer(companyId, roleLevel int, user User) []Customer {
	customers := []Customer{}
	o := orm.NewOrm()
	qt := o.QueryTable("customer")
	qs := qt.Filter("company_id", companyId).Filter("audit_status", 1)
	//if roleLevel == 1 {
	//	qs = qs.Filter("create_user_id", user.Id)
	//} else if roleLevel == 2{
	//	qs = qs.Filter("audit_department_id", user.DepartmentId)
	//}
	//qs = qs.GroupBy("customer_name")
	_, err := qs.All(&customers)
	if err != nil {
		return nil
	}
	return customers
}

/*
根据权限获取客户的对接人员名字和id，非重复
*/
func (c *Customer) GetAllFollowUser(companyId, roleLevel int, user User) *[]Customer {

	if roleLevel == 1 {

		customers := []Customer{}
		o := orm.NewOrm()
		_, err := o.Raw("select * from customer WHERE company_id=? AND create_user_id=? GROUP BY follow_user_id", companyId, user.Id).QueryRows(&customers)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}

		return &customers
	} else if roleLevel == 2 {
		customers := []Customer{}
		o := orm.NewOrm()
		_, err := o.Raw("select * from customer WHERE company_id=? AND audit_department_id=? GROUP BY follow_user_id ", companyId, user.DepartmentId).QueryRows(&customers)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}

		return &customers
	} else {
		customers := []Customer{}
		o := orm.NewOrm()
		_, err := o.Raw("select * from customer WHERE company_id=? GROUP BY follow_user_id", companyId).QueryRows(&customers)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}
		return &customers
	}
}

/*
根据公司id查询总数
*/
func (c *Customer) GetCount(companyId int, maps map[string]interface{}) int {
	var num []int
	o := orm.NewOrm()
	sqlm := "select count(*) as num from customer where company_id=? "
	sql1 := makeSql(sqlm, maps)
	_, err := o.Raw(sql1, companyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
根据创建者Id查询总数
*/
func (c *Customer) GetCountByUserId(userId int, maps map[string]interface{}) int {
	var num []int
	o := orm.NewOrm()
	sqlm := "select count(*) as num from customer where create_user_id=? "
	sql1 := makeSql(sqlm, maps)
	_, err := o.Raw(sql1, userId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
根据部门Id查询总数
*/
func (c *Customer) GetCountByDepartmentId(companyId, departmentId int, maps map[string]interface{}) int {
	var num []int
	o := orm.NewOrm()
	sqlm := "select count(*) as num from customer where company_id=? AND audit_department_id=? "
	sql1 := makeSql(sqlm, maps)
	_, err := o.Raw(sql1, companyId, departmentId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
根据部门Id查询待审核总数
*/
func (c *Customer) GetExamineCountByDepartmentId(companyId, departmentId int) int {
	var num []int
	o := orm.NewOrm()
	sqlm := "select count(*) as num from customer where company_id=? AND audit_department_id=? AND audit_status=0 "
	_, err := o.Raw(sqlm, companyId, departmentId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
根据客户查询联系人
*/
func (c *Customer) GetContactsByCustomerId(customerId int) *[]Contact {
	contacts := []Contact{}
	o := orm.NewOrm()
	_, err := o.Raw("SELECT * FROM contact WHERE customer_id=?", customerId).QueryRows(&contacts)
	if err != nil {
		logs.Error("exec select contact faild", err)
		return nil
	}
	return &contacts
}

/*
根据联系人id查询联系人
*/
func (c *Customer) GetContactsByContactId(contactId int) *Contact {
	contact := Contact{}
	o := orm.NewOrm()
	err := o.Raw("SELECT * FROM contact WHERE contact_id=?", contactId).QueryRow(&contact)
	if err != nil {
		logs.Error("exec select contact faild", err)
		return nil
	}
	return &contact
}

/*
根据联系人id删除联系人
*/
func (c *Customer) DelContactById(contactId int) bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("DELETE FROM contact WHERE contact_id=?", contactId).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("exec del contact faild", err)
		return false
	}
	o.Commit()
	return true
}

/*
根据联系人id修改联系人
*/
func (c *Customer) UpdateContactById(contact Contact) bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE contact set contact_name=?,contact_post=?,contact_phone=?,contract_mail=?,contract_address=? WHERE contact_id=?", contact.ContactName, contact.ContactPost,
		contact.ContactPhone, contact.ContactMail, contact.ContactAddress, contact.Id).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("exec del contact faild", err)
		return false
	}
	o.Commit()
	return true
}

/*
插入新的联系人
*/
func (c *Customer) AddContact(contact Contact) bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("INSERT INTO contact (contact_name,contact_post,contact_phone,contract_mail,contract_address,customer_id) VALUES(?,?,?,?,?,?)",
		contact.ContactName, contact.ContactPost,
		contact.ContactPhone, contact.ContactMail, contact.ContactAddress, contact.CustomerId).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("exec add contact faild", err)
		return false
	}
	o.Commit()
	return true
}

// AddCustomer insert a new Customer into database and returns
// 添加一条客户信息
func AddCustomer(m *Customer) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return id, err
}

//添加客户里面的联系人信息
func AddContact(m *Contact) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return id, err
}

//事物处理添加客户信息同时添加联系人信息
func AddCustomerContact(m *Customer) (id int64, err error) {
	o := orm.NewOrm()
	o.Begin()

	o.Commit()
	return id, err
}

// GetCustomerById retrieves Customer by Id. Returns error if
// 根据id获取一条客户信息（包含一个客户对着的多个联系人信息）
func GetCustomerById(id int) (v *Customer, err error) {
	o := orm.NewOrm()
	o.Raw("")
	return nil, err
}

// GetAllCustomer retrieves all Customer matches certain condition. Returns empty list if
// 根据条件查询客户（也包含联系人信息）
func GetAllCustomer(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, total int64, err error) {

	return nil, 0, err
}

// func GetContactByCustomerId(id int)(m *Contact,err error) {
// 	o := orm.NewOrm()
// 	v = &Contact{CustomerId: id}
// 	f err = o.Read(v); err == nil {

// 		return v, nil
// 	}
// 	return nil, err
// }

// UpdateCustomer updates Customer by Id and returns error if
// 跟新客户信息，删除该客户对应联系人信息，并重新插入
func UpdateCustomerById(m *Customer, keys string) (err error) {
	o := orm.NewOrm()
	o.Begin()

	o.Commit()
	return
}

// DeleteCustomer deletes Customer by Id and returns error if
// 删除客户信息
func DeleteCustomer(id int) (err error) {
	o := orm.NewOrm()
	o.Raw("")
	return
}

//删除客户下面的联系人信息
func DeleteContact(id int) (err error) {
	o := orm.NewOrm()
	o.Raw("")
	return
}

func makeSql(sql string, maps map[string]interface{}) string {
	if maps["key"] != nil {
		sql = sql + "and concat(c.customer_name,c.abbreviation,c.attribute,c.addr_url,c.step_name,c.product_types_name,c.start_time,c.company_address,c.create_time,c.audit_department_Name,c.follow_user_name,c.audit_user_name) like '%" + maps["key"].(string) + "%' "
		return sql
	} else {
		for k, v := range maps {
			if k == "start_time" {
				sql = sql + " AND c.start_time>='" + v.(string) + " 00:00:00'"
			} else if k == "customer_name" {
				sql = sql + " AND c." + k + "='" + v.(string) + "'"
			} else {
				sql = sql + " AND c." + k + "=" + v.(string)
			}
		}
		return sql
	}

}
