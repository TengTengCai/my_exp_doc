package models

import (
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
)

//权限模块组件
type Module struct {
	ModuleId   int    `orm:"column(module_id);pk;auto"`
	ModuleName string `orm:"column(module_name);size(50)"`
	ModuleKey  string `orm:"column(module_key);size(50)"`
}

func init() {
	orm.RegisterModel(new(Module))
}

//手动代码段

//查询现有所有权限模块，返回map
func (r *Module) GetModuleAll() (error, map[string]bool) {
	o := orm.NewOrm()
	models := []Module{}
	_, err := o.Raw("SELECT * FROM module ").QueryRows(&models)

	modelMap := make(map[string]bool)

	for _, v := range models {
		modelMap[v.ModuleKey] = false
	}
	return err, modelMap
}

//查询所有权限模块，返回权限结构体集合
func (r *Module) GetAll() []Module {
	o := orm.NewOrm()
	models := []Module{}
	_, err := o.Raw("SELECT * FROM module ").QueryRows(&models)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	return models
}
