package models

import (
	"cpxerp/util"
	"errors"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"reflect"
	"strings"
)

//部门
type Department struct {
	DepartmentId   int    `orm:"column(department_id);pk;auto"`
	DepartmentName string `orm:"column(department_name)"`
	Flag           bool   `orm:"-"`
}

func init() {
	orm.RegisterModel(new(Department))
}

//手写代码段
func (r Department) GetDepartmentByName(name string) (bool, *Department) {
	o := orm.NewOrm()
	depart := Department{}
	err := o.Raw("SELECT * FROM department where department_name = ? ", name).QueryRow(&depart)
	if err != nil {
		logs.Error("select department err", err, name)
		return false, nil
	}
	return true, &depart
}

/*
根据id查询部门
*/
func (r Department) GetDepartmentById(id int) *Department {
	o := orm.NewOrm()
	depart := Department{}
	err := o.Raw("SELECT * FROM department where department_id = ? ", id).QueryRow(&depart)
	if err != nil {
		logs.Error("select department err", err)
		return nil
	}
	return &depart
}

//查询所有部门
func (r *Department) FinddAll() []Department {

	departments := []Department{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from department ").QueryRows(&departments)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	return departments
}

//分页查询部门
func (r *Department) FinadAllByPage(page int, limit int) *uitl.Page {
	count := r.GetCount()
	newPage := uitl.NewPage(page, limit, count)
	departments := []Department{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from department limit ?,?", newPage.StartIndex, newPage.PageSize).QueryRows(&departments)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = &departments
	return newPage
}

//统计部门总数
func (r *Department) GetCount() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from department").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

//设置部门信息，设置所属公司和设置领导
func (r *Department) AddDepartmentSet(departmenId, companyId, userId int) bool {

	o := orm.NewOrm()
	var nums []int
	_, err := o.Raw("SELECT COUNT(*) FROM department_company_user WHERE department_id=? AND company_id =? and user_id=?", departmenId, companyId, userId).QueryRows(&nums)
	if err != nil {
		return false
	} else {
		if nums[0] == 0 {
			_, err := o.Raw("insert into department_company_user (department_id,company_id,user_id) VALUES (?,?,?)", departmenId, companyId, userId).Exec()
			if err != nil {
				logs.Error("exec select faild", err)
				return false
			}
			return true
		} else {
			return false
		}
	}

}

//查询所有已被设置的部门信息
func (r *Department) GetDepartComUserListByPage(page int, limit int) *uitl.Page {
	count := r.GetDeparmentSetCount()
	newPage := uitl.NewPage(page, limit, count)
	o := orm.NewOrm()
	dcus := &[]DepartmentCompanyUser{}
	_, err := o.Raw("SELECT dcu.*,u.name as user_name,c.company_name,d.department_name"+
		" FROM department_company_user dcu"+
		" LEFT JOIN user u on dcu.user_id=u.user_id"+
		" LEFT JOIN company c ON dcu.company_id=c.company_id"+
		" LEFT JOIN department d ON dcu.department_id=d.department_id limit ?,?", newPage.StartIndex, newPage.PageSize).QueryRows(dcus)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = dcus
	return newPage
}

//删除某条已设置的部门信息
func (r *Department) DepartComUserDel(departmenId, companyId, userId int) bool {
	o := orm.NewOrm()
	_, err := o.Raw("DELETE FROM department_company_user WHERE department_id=? AND company_id =? and user_id=?", departmenId, companyId, userId).Exec()

	if err != nil {
		return false
	}
	return true

}

func (r *Department) GetDeparmentSetCount() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from department_company_user").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
获取所有的部门函数
auth:ttc
*/
func SelectAllDepartment() []Department {
	o := orm.NewOrm()
	var departments []Department
	_, err := o.Raw("select * from department").QueryRows(&departments)
	if err != nil {
		logs.Error("exec count faild", err)
		return nil
	}
	return departments
}

//逆向生成代码段
func (t *Department) TableName() string {
	return "department"
}

// AddDepartment insert a new Department into database and returns
// last inserted Id on success.
func AddDepartment(m *Department) (id int64, err error) {
	o := orm.NewOrm()
	o.Begin()
	id, err = o.Insert(m)
	if err != nil {
		o.Rollback()
	}
	o.Commit()
	return
}

// GetDepartmentById retrieves Department by Id. Returns error if
// Id doesn't exist
func GetDepartmentById(id int) (v *Department, err error) {
	o := orm.NewOrm()
	v = &Department{DepartmentId: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllDepartment retrieves all Department matches certain condition. Returns empty list if
// no records exist
func GetAllDepartment(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(Department))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []Department
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateDepartment updates Department by Id and returns error if
// the record to be updated doesn't exist
func UpdateDepartmentById(m *Department) (err error) {
	o := orm.NewOrm()
	v := Department{DepartmentId: m.DepartmentId}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteDepartment deletes Department by Id and returns error if
// the record to be deleted doesn't exist
func DeleteDepartment(id int) (err error) {
	o := orm.NewOrm()
	v := Department{DepartmentId: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&Department{DepartmentId: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}
