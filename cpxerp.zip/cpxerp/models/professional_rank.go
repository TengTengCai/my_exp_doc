package models

import (
	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"strconv"
)

type ProfessionalRank struct {
	RankId   int    `orm:"column(rank_id);pk;auto"`
	RankName string `orm:"column(rank_name);"`
}

func (t *ProfessionalRank) TableName() string {
	return "professional_rank"
}

func init() {
	orm.RegisterModel(new(ProfessionalRank))
}
func (t *ProfessionalRank) Add() bool {
	o := orm.NewOrm()
	o.Begin()
	p1 := ProfessionalRank{}

	num := p1.Count()
	if num == 0 {
		_, err := o.Raw("insert into professional_rank(rank_name) values('P0')").Exec()
		if err != nil {
			o.Rollback()
			return false
		}
		o.Commit()
		return true
	} else {
		err := o.Raw("select * from professional_rank order by rank_id DESC limit 1").QueryRow(&p1)
		if err != nil {
			return false
		}
		_, err = o.Raw("insert into professional_rank(rank_name) values(?)", "P"+strconv.Itoa(p1.RankId)).Exec()
		if err != nil {
			o.Rollback()
			return false
		}
		o.Commit()
		return true
	}

}

func (t *ProfessionalRank) Count() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from professional_rank").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	logs.Error(num)
	return num[0]
}

func (t *ProfessionalRank) Select(page int, limit int) *uitl.Page {
	count := t.Count()
	newPage := uitl.NewPage(page, limit, count)
	ps := []ProfessionalRank{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from professional_rank  limit ?,?", newPage.StartIndex, newPage.PageSize).QueryRows(&ps)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = &ps
	return newPage
}

func SelectAllPRank() []ProfessionalRank {
	o := orm.NewOrm()
	var pRanks []ProfessionalRank
	_, err := o.QueryTable("professional_rank").All(&pRanks)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return pRanks
}
