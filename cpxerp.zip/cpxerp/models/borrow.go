package models

import (
	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"strconv"
	"time"
)

type Borrow struct {
	Id                       int       `orm:"column(borrow_id);auto";form:"Id"`                                    //id
	BorrowerId               int       `orm:"column(borrower_id)";form:"BorrowerId"`                               //借款人user_id
	BorrowerName             string    `orm:"column(borrower_name)";form:"BorrowerName"`                           //借款人 user_name
	DepartmentId             int       `orm:"column(department_id)";size(10);form:"DepartmentId"`                  //借款部门 部门id
	DepartmentName           string    `orm:"column(department_name)";size(10);form:"DepartmentName"`              //借款部门 部门名称
	UsageLoan                string    `orm:"column(usage_loan);size(300)";form:"UsageLoan"`                       //借款用途
	Currency                 string    `orm:"column(currency);size(10)";form:"Currency"`                           //币种
	LoanAmount               float64   `orm:"column(loan_amount)";form:"LoanAmount"`                               //数字借款金额
	LoanAmountCapitalChinese string    `orm:"column(loan_amount_capital_chinese)";form:"LoanAmountCapitalChinese"` //大写借款金额
	BankName                 string    `orm:"column(bank_name)";size(40);form:"BankName"`                          //银行户名
	OpeningBank              string    `orm:"column(opening_bank)";size(40);form:"OpeningBank"`                    //开户银行
	BankAccount              string    `orm:"column(bank_account)";size(40);form:"BankAccount"`                    //银行账号
	DivisionLeaderStatus     int       `orm:"column(division_leader_status)";form:"DivisionLeaderStatus"`          //部门负责人审批状态 	待审核：0，通过：1，未通过：2
	FinancialCheckStatus     int       `orm:"column(financial_check_status)";form:"FinancialCheckStatus"`          //财务部审批状态 		待审核：0，通过：1，未通过：2
	CompanyHeaderStatus      int       `orm:"column(company_header_status)";form:"CompanyHeaderStatus"`            //公司负责人审批状态 	待审核：0，通过：1，未通过：2
	PaymentStatus            int       `orm:"column(payment_status)";form:"PaymentStatus"`                         //付款标注状态         待方框：0，放款：1
	CompanyId                int       `orm:"column(company_id)";form:"CompanyId"`                                 //公司id
	CompanyName              string    `orm:"column(company_name)";form:"CompanyName"`                             //公司名称
	CreateUserId             int       `orm:"column(create_user_id)";form:"CreateUserId"`                          //创建人user_id
	CreateUserName           string    `orm:"column(create_user_name)";form:"CreateUserName"`                      //创建人user_name
	CreateTime               time.Time `orm:"column(create_time)";form:"CreateTime"`                               //创建时间
	ApplicationTime          time.Time `orm:"column(application_time)";form:"ApplicationTime"`                     //申请时间
}

func (t *Borrow) TableName() string {
	return "borrow"
}

func init() {
	orm.RegisterModel(new(Borrow))
}

/*
添加借款信息入库
*/
func (b *Borrow) Add() (bool, error) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("INSERT INTO borrow(borrower_id,department_id,usage_loan,currency,loan_amount,"+
		"bank_name,opening_bank,bank_account,division_leader_status,financial_check_status,"+
		"company_header_status,payment_status,company_id,create_user_id,create_time,"+
		"application_time,loan_amount_capital_chinese)"+
		"VALUES(?,?,?,?,?,"+
		"?,?,?,?,?,"+
		"?,?,?,?,?,"+
		"?,?)",
		b.BorrowerId, b.DepartmentId, b.UsageLoan, b.Currency, b.LoanAmount,
		b.BankName, b.OpeningBank, b.BankAccount, b.DivisionLeaderStatus, b.FinancialCheckStatus,
		b.CompanyHeaderStatus, b.PaymentStatus, b.CompanyId, b.CreateUserId, b.CreateTime,
		b.ApplicationTime, b.LoanAmountCapitalChinese).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("insert customer err, ", err)
		return false, err
	}
	o.Commit()
	return true, nil
}

/*
查询审核数据
1.部门只能查询当前部门的借款待审核数据
2.财务查看当前公司所有借款待审核数据，前提部门已通过的
3.公司领导查看当前公司所有待审核借款数据，前提是财务已通过审核
*/
func (b *Borrow) SelectDataList(page, limit int, modules map[string]bool, user User, companyId int) *uitl.Page {
	var sql = "SELECT b.borrow_id,b.borrower_id,b.department_id,b.usage_loan,b.currency, " +
		"b.loan_amount,b.loan_amount_capital_chinese,b.bank_name,b.opening_bank, " +
		"b.bank_account,b.division_leader_status,b.financial_check_status,b.company_header_status,b.payment_status,b.company_id,b.create_user_id, " +
		"b.application_time,u1.name as borrower_name,d.department_name,c.company_name,u2.name AS create_user_name " +
		"FROM borrow b " +
		"LEFT JOIN user u1 on u1.user_id=b.borrower_id " +
		"LEFT JOIN department d ON d.department_id=b.department_id " +
		"LEFT JOIN company c ON c.company_id=b.company_id " +
		"LEFT JOIN user u2 ON u2.user_id=b.create_user_id "
	o := orm.NewOrm()
	count := b.CountSelectData(modules, user, companyId)
	newPage := uitl.NewPage(page, limit, count)
	borrows := []Borrow{}
	if modules["deppart_examine"] == true {
		sql = sql + " WHERE b.department_id=? and b.company_id=? AND b.division_leader_status=0 and b.financial_check_status=0 and b.company_header_status=0 limit ?,?"
		_, err := o.Raw(sql, user.DepartmentId, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&borrows)
		if err != nil {
			logs.Error("exec count faild", err)
			return nil
		}
		newPage.Data = borrows
		return newPage
	} else if modules["finance_examine"] == true {
		sql = sql + " WHERE b.company_id=? AND b.division_leader_status=1 and b.financial_check_status=0 and b.company_header_status=0 limit ?,?"
		_, err := o.Raw(sql, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&borrows)
		if err != nil {
			logs.Error("exec count faild", err)
			return nil
		}
		newPage.Data = borrows
		return newPage
	} else if modules["ceo_examine"] == true {
		sql = sql + " WHERE b.company_id=? AND b.division_leader_status=1 and b.financial_check_status=1 and b.company_header_status=0 limit ?,?"
		_, err := o.Raw(sql, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&borrows)
		if err != nil {
			logs.Error("exec count faild", err)
			return nil
		}
		newPage.Data = borrows
		return newPage
	} else {
		return nil
	}
}

/*
统计查询审核数据
1.部门只能查询当前部门的借款待审核数据
2.财务查看当前公司所有借款待审核数据，前提部门已通过的
3.公司领导查看当前公司所有待审核借款数据，前提是财务已通过审核
*/
func (b *Borrow) CountSelectData(modules map[string]bool, user User, companyId int) int {
	var sql = "SELECT COUNT(*) " +
		" FROM borrow b " +
		" LEFT JOIN user u1 on u1.user_id=b.borrower_id " +
		" LEFT JOIN department d ON d.department_id=b.department_id " +
		" LEFT JOIN company c ON c.company_id=b.company_id " +
		" LEFT JOIN user u2 ON u2.user_id=b.create_user_id"
	var num []int
	o := orm.NewOrm()
	if modules["deppart_examine"] == true {
		sql = sql + " WHERE b.department_id=? and b.company_id=? AND b.division_leader_status=0 and b.financial_check_status=0 and b.company_header_status=0"
		_, err := o.Raw(sql, user.DepartmentId, companyId).QueryRows(&num)
		if err != nil {
			logs.Error("exec count faild", err)
			return 0
		}
		return num[0]
	} else if modules["finance_examine"] == true {
		sql = sql + " WHERE b.company_id=? AND b.division_leader_status=1 and b.financial_check_status=0 and b.company_header_status=0"
		_, err := o.Raw(sql, companyId).QueryRows(&num)
		if err != nil {
			logs.Error("exec count faild", err)
			return 0
		}
		logs.Error(num)
		return num[0]
	} else if modules["ceo_examine"] == true {
		sql = sql + " WHERE b.company_id=? AND b.division_leader_status=1 and b.financial_check_status=1 and b.company_header_status=0"
		_, err := o.Raw(sql, companyId).QueryRows(&num)
		if err != nil {
			logs.Error("exec count faild", err)
			return 0
		}
		return num[0]
	} else {
		return 0
	}
}

/*
根据部门，财务，公司领导分别修改对应的审核状态
*/
func (b *Borrow) UpdateStatus(modules map[string]bool, status, borrowId int) bool {
	o := orm.NewOrm()
	o.Begin()
	var sql string

	if modules["deppart_examine"] == true {
		sql = "UPDATE borrow SET division_leader_status=" + strconv.Itoa(status) + " WHERE borrow_id=? "
	}
	if modules["finance_examine"] == true {
		sql = "UPDATE borrow SET financial_check_status=" + strconv.Itoa(status) + " WHERE borrow_id=? "
	}
	if modules["ceo_examine"] == true {
		sql = "UPDATE borrow SET company_header_status=" + strconv.Itoa(status) + " WHERE borrow_id=?"
	}

	_, err := o.Raw(sql, borrowId).Exec()
	if err != nil {
		logs.Error(err)
		o.Rollback()
		return false
	} else {
		o.Commit()
		return true
	}

}

/*
查询个人当前的申请借款记录及审核状态
*/
func (b *Borrow) SelectBuCreateUser(page, limit int, user User) *uitl.Page {
	var sql = "SELECT b.borrow_id,b.borrower_id,b.department_id,b.usage_loan,b.currency, " +
		"b.loan_amount,b.loan_amount_capital_chinese,b.bank_name,b.opening_bank, " +
		"b.bank_account,b.division_leader_status,b.financial_check_status,b.company_header_status,b.payment_status,b.company_id,b.create_user_id, " +
		"b.application_time,u1.name as borrower_name,d.department_name,c.company_name,u2.name AS create_user_name " +
		"FROM borrow b " +
		"LEFT JOIN user u1 on u1.user_id=b.borrower_id " +
		"LEFT JOIN department d ON d.department_id=b.department_id " +
		"LEFT JOIN company c ON c.company_id=b.company_id " +
		"LEFT JOIN user u2 ON u2.user_id=b.create_user_id where b.create_user_id=? limit ?,?"
	o := orm.NewOrm()
	count := b.CountByCreateUser(user)
	newPage := uitl.NewPage(page, limit, count)
	borrows := []Borrow{}
	_, err := o.Raw(sql, user.Id, newPage.StartIndex, newPage.PageSize).QueryRows(&borrows)
	if err != nil {
		logs.Error("exec count faild", err)
		return nil
	}
	newPage.Data = borrows
	return newPage
}

/*
统计个人申请借款数量
*/
func (b *Borrow) CountByCreateUser(user User) int {
	var sql = "SELECT COUNT(*) " +
		" FROM borrow b " +
		" LEFT JOIN user u1 on u1.user_id=b.borrower_id " +
		" LEFT JOIN department d ON d.department_id=b.department_id " +
		" LEFT JOIN company c ON c.company_id=b.company_id " +
		" LEFT JOIN user u2 ON u2.user_id=b.create_user_id where b.create_user_id=?"
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw(sql, user.Id).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
 查询所有通过审核的数据，公司id
*/
func (b *Borrow) SelectByStatus(page, limit, companyId int) *uitl.Page {
	var sql = "SELECT b.borrow_id,b.borrower_id,b.department_id,b.usage_loan,b.currency, " +
		"b.loan_amount,b.loan_amount_capital_chinese,b.bank_name,b.opening_bank, " +
		"b.bank_account,b.division_leader_status,b.financial_check_status,b.company_header_status,b.payment_status,b.company_id,b.create_user_id, " +
		"b.application_time,u1.name as borrower_name,d.department_name,c.company_name,u2.name AS create_user_name " +
		"FROM borrow b " +
		"LEFT JOIN user u1 on u1.user_id=b.borrower_id " +
		"LEFT JOIN department d ON d.department_id=b.department_id " +
		"LEFT JOIN company c ON c.company_id=b.company_id " +
		"LEFT JOIN user u2 ON u2.user_id=b.create_user_id  WHERE b.company_id=? AND b.division_leader_status=1 and b.financial_check_status=1 and b.company_header_status=1 limit ?,?"
	o := orm.NewOrm()
	count := b.CountByStatus(companyId)
	newPage := uitl.NewPage(page, limit, count)
	borrows := []Borrow{}
	_, err := o.Raw(sql, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&borrows)
	if err != nil {
		logs.Error("exec count faild", err)
		return nil
	}
	newPage.Data = borrows
	return newPage
}

/*
  统计所有通过审核的借款数据数量，公司id
*/
func (b *Borrow) CountByStatus(companyId int) int {
	var sql = "SELECT COUNT(*) " +
		" FROM borrow b " +
		" LEFT JOIN user u1 on u1.user_id=b.borrower_id " +
		" LEFT JOIN department d ON d.department_id=b.department_id " +
		" LEFT JOIN company c ON c.company_id=b.company_id " +
		" LEFT JOIN user u2 ON u2.user_id=b.create_user_id WHERE b.company_id=? AND b.division_leader_status=1 and b.financial_check_status=1 and b.company_header_status=1"
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw(sql, companyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]

}

/*
   修改放款状态
*/
func (b *Borrow) UpdatePayStatus(borrowId int) bool {
	o := orm.NewOrm()
	o.Begin()
	sql := "UPDATE borrow SET payment_status=1 WHERE borrow_id=? "
	_, err := o.Raw(sql, borrowId).Exec()
	if err != nil {
		logs.Error(err)
		o.Rollback()
		return false
	} else {
		o.Commit()
		return true
	}
}
