/*
招聘模型
auth:ttc
data: 2018-09-19
 */
package models

import (
	"errors"
	"fmt"
	"github.com/astaxie/beego/logs"
	"reflect"
	"strings"
	"time"

	"cpxerp/util"
	"github.com/astaxie/beego/orm"
)

type Recruitment struct {
	Id                 int       `orm:"column(id);auto" form:"Id"`                                      // ID
	BusinessId         int       `orm:"column(business_id)"form:"BusinessId"`                           // 申请业务线
	RecruitPosition    string    `orm:"column(recruit_position);size(32)"form:"RecruitPosition"`        //	招聘职位
	RecruitingNumbers  int       `orm:"column(recruiting_numbers)"form:"RecruitingNumbers"`             // 招聘人数
	WorkingPlace       string    `orm:"column(working_place);size(64)"form:"WorkingPlace"`              // 工作地点
	EmploymentNature   string    `orm:"column(employment_nature);size(16)"form:"EmploymentNature"`      // 聘用性质
	Age                string    `orm:"column(age);size(50);"form:"Age"`                                // 年龄
	EmployReason       string    `orm:"column(employ_reason);size(16)"form:"EmployReason"`              // 招聘理由
	EmployDescription  string    `orm:"column(employ_description);size(128)"form:"EmployDescription"`   // 招聘说明
	PostDuties         string    `orm:"column(post_duties);size(256)"form:"PostDuties"`                 // 岗位职责
	Sex                string    `orm:"column(sex);size(4)"form:"Sex"`                                  // 性别
	Education          string    `orm:"column(education);size(4)"form:"Education"`                      // 学历
	ProfessionalSkills string    `orm:"column(professional_skills);size(256)"form:"ProfessionalSkills"` // 专业能力
	WorkExperience     string    `orm:"column(work_experience);size(256)"form:"WorkExperience"`         // 工作经验
	KeyCapabilities    string    `orm:"column(key_capabilities);size(256)"form:"KeyCapabilities"`       // 关键胜任能力
	DutyTime           time.Time `orm:"column(duty_time);type(datetime)"form:"DutyTime"`                // 到岗时间
	SalaryRange        string    `orm:"column(salary_range);size(34)"form:"SalaryRange"`                // 期望薪酬范围
	PersonnelIsPass    int       `orm:"column(personnel_is_pass);default(0)"`                           // 人事审核, 0为待审核, 1为通过, 2为未通过
	CeoIsPass          int       `orm:"column(ceo_is_pass);default(0)"`                                 // CEO审核, 0为待审核, 1为通过, 2为未通过
	IsOk				int      `orm:"column(is_ok); default(0)"`										// 审核是否通过, 0为待审核,1为通过,2为未通过
	IsHadRecruit       int       `orm:"column(is_had_recruit);default(0)"`                              // 是否已经招聘, 0为为招聘成功,1为已经招聘成功
	IsInternal         int       `orm:"column(is_internal); default(0);"`                               // 是否支持內推
	CreateUserId       int       `orm:"column(create_user_id);"`                                        // 创建人ID
	CompanyId          int       `orm:"column(company_id)"`                                             // 公司ID
	CreateTime         time.Time `orm:"column(create_time);auto_now_add;type(datetime)"`                // 创建时间
	UpdateTime         time.Time `orm:"column(update_time);auto_now;type(datetime)"`                    // 更新时间
}

func (t *Recruitment) TableName() string {
	return "recruitment"
}

func init() {
	orm.RegisterModel(new(Recruitment))
}

// AddRecruitment insert a new Recruitment into database and returns
// last inserted Id on success.
func AddRecruitment(m *Recruitment) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetRecruitmentById retrieves Recruitment by Id. Returns error if
// Id doesn't exist
func GetRecruitmentById(id int) (v *Recruitment, err error) {
	o := orm.NewOrm()
	v = &Recruitment{Id: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllRecruitment retrieves all Recruitment matches certain condition. Returns empty list if
// no records exist
func GetAllRecruitment(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(Recruitment))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []Recruitment
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateRecruitment updates Recruitment by Id and returns error if
// the record to be updated doesn't exist
func UpdateRecruitmentById(m *Recruitment) (err error) {
	o := orm.NewOrm()
	v := Recruitment{Id: m.Id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteRecruitment deletes Recruitment by Id and returns error if
// the record to be deleted doesn't exist
func DeleteRecruitment(id int) (err error) {
	o := orm.NewOrm()
	v := Recruitment{Id: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&Recruitment{Id: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

func SelectRecruitByFilter(filter map[string]interface{}, order string, page, limit int) []orm.Params {
	baseSql := "SELECT r.*, " +
		"b.business_name as business_name, " +
		"u.name as create_user_name " +
		"FROM recruitment as r " +
		"left join business as b " +
		"on r.business_id = b.business_id " +
		"left join user as u " +
		"on r.create_user_id = u.user_id "
	isFirst := true
	for k, v := range filter {
		var sqlItem string
		kt, s := uitl.AnalyzeCondition(k)
		str := uitl.TypeToString(v)
		if isFirst {
			sqlItem = "where r." + kt + s + "'" + str + "' "
			isFirst = false
		} else {
			sqlItem = "and r." + kt + s + "'" + str + "' "
		}
		baseSql += sqlItem
	}

	if len(order) > 0 {
		baseSql += "order by " + order + " "
	}

	if page != 0 && limit != 0 {
		baseSql += "limit " + fmt.Sprint(limit*(page-1)) + ", " + fmt.Sprint(limit)
	}

	var recruitment []orm.Params
	o := orm.NewOrm()
	_, err := o.Raw(baseSql).Values(&recruitment)

	if err != nil {
		return nil
	}

	return recruitment
}

func GetRecruitCountByFilter(filter map[string]interface{}) int {
	o := orm.NewOrm()
	qs := o.QueryTable(new(Recruitment))
	for k, v := range filter {
		qs = qs.Filter(k, v)
	}
	count, err := qs.Count()
	if err != nil {
		return 0
	}
	return int(count)
}
