package models

import (
	"cpxerp/util"
	"errors"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"reflect"
	"strconv"
	"strings"
)

//业务线
type Business struct {
	BusinessId     int    `orm:"column(business_id);pk;auto"`
	BusinessName   string `orm:"column(business_name)"`
	BusinessStatus int    `orm:"column(business_status)"` //运行：0；停运：1
	Flag           bool   `orm:"column(-)"`               //运行：0；停运：1
}

type UserBusinessRel struct {
	Id         int `orm:"column(id);pk;auto"`
	BusinessId int `orm:"column(business_id)"`
	UserId     int `orm:"column(user_id)"`
}

func init() {
	orm.RegisterModel(new(Business))
	orm.RegisterModel(new(UserBusinessRel))
}

//手写代码段
func (b *Business) GetBusinessByName(name string) (bool, *Business) {
	o := orm.NewOrm()
	business := Business{}
	err := o.Raw("SELECT * FROM business where business_name = ? ", name).QueryRow(&business)
	if err != nil {
		logs.Error("select business err", err, name)
		return false, nil
	}
	return true, &business
}

/*
分页查询业务线
*/
func (r *Business) FinadAllByPage(page int, limit int) *uitl.Page {
	count := r.GetCount()
	newPage := uitl.NewPage(page, limit, count)
	businesss := []Business{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from business limit ?,?", newPage.StartIndex, newPage.PageSize).QueryRows(&businesss)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = &businesss
	return newPage
}

/*
查询所有运行业务线
*/
func (r *Business) FinadAll() *[]Business {

	businesss := []Business{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from business where business_status=0").QueryRows(&businesss)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}

	return &businesss
}

func (r *Business) GetCount() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from business").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

//根据业务iD修改名字或者状态
func (r *Business) UpdateBusinessId(name string, status int, id int) bool {
	o := orm.NewOrm()
	if name == "" && status > -1 {
		sq := "UPDATE business SET business_status=? WHERE business_id=?"
		_, err := o.Raw(sq, status, id).Exec()
		if err != nil {
			return false
		} else {
			return true
		}
	} else {
		sq := "UPDATE business SET business_name=? WHERE business_id=?"
		_, err := o.Raw(sq, name, id).Exec()
		if err != nil {
			return false
		} else {
			return true
		}
	}

}

func (r *Business) AddUserBusiness(userId int, businessIds []int) bool {
	o := orm.NewOrm()
	o.Begin()
	sql := "INSERT into user_business_rel (user_id,business_id) VALUES "
	for i := 0; i < len(businessIds); i++ {
		if i == 0 {
			sql = sql + " (" + strconv.Itoa(userId) + "," + strconv.Itoa(businessIds[i]) + ")"
		} else {
			sql = sql + " ,(" + strconv.Itoa(userId) + "," + strconv.Itoa(businessIds[i]) + ")"
		}
	}
	_, err := o.Raw(sql).Exec()
	if err != nil {
		o.Rollback()
		return false
	}
	return true
}

/*
获取所有的商业线
auth:ttc
*/
func SelectAllBusiness() []Business {
	businesses := []Business{}
	o := orm.NewOrm()
	qs := o.QueryTable("business") // 获取Queryset对象
	_, err := qs.All(&businesses)  // 查询所有
	if err != nil {
		return nil
	}
	return businesses
}

//逆向生成代码段
func (t *Business) TableName() string {
	return "business"
}

// AddBusinssLine insert a new BusinssLine into database and returns
// last inserted Id on success.
func AddBusinss(m *Business) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetBusinssLineById retrieves BusinssLine by Id. Returns error if
// Id doesn't exist
func GetBusinssById(id int) (v *Business, err error) {
	o := orm.NewOrm()
	v = &Business{BusinessId: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllBusinssLine retrieves all BusinssLine matches certain condition. Returns empty list if
// no records exist
func GetAllBusinss(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(Business))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []Business
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateBusinssLine updates BusinssLine by Id and returns error if
// the record to be updated doesn't exist
func UpdateBusinssById(m *Business) (err error) {
	o := orm.NewOrm()
	v := Business{BusinessId: m.BusinessId}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteBusinssLine deletes BusinssLine by Id and returns error if
// the record to be deleted doesn't exist
func DeleteBusinss(id int) (err error) {
	o := orm.NewOrm()
	v := Business{BusinessId: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&Business{BusinessId: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

func AddUserBusinessRel(user *User, businessList []string) error {
	o := orm.NewOrm()
	o.Begin()
	var businessStr string
	for _, v := range businessList {
		businessId, err := strconv.ParseInt(v, 10, 64)
		b := Business{BusinessId: int(businessId)}
		o.Read(&b)
		businessStr += b.BusinessName + ","
		ubRel := UserBusinessRel{}
		ubRel.UserId = user.Id
		ubRel.BusinessId = int(businessId)
		_, err = o.Insert(&ubRel)
		if err != nil {
			return o.Rollback()
		}
	}
	user.BusinessStr = businessStr
	err := UpdateUserById(user)
	if err != nil {
		return o.Rollback()
	}
	o.Commit()
	return nil
}
func UpdateUserBusinessRel(user *User, businessList []string) error {
	o := orm.NewOrm()
	o.Begin()
	var business []UserBusinessRel
	o.QueryTable("user_business_rel").Filter("user_id", user.Id).All(&business)
	for _, v := range business {
		_, err := o.Delete(&v)
		if err != nil {
			return o.Rollback()
		}
	}
	err := AddUserBusinessRel(user, businessList)
	if err != nil {
		return o.Rollback()
	}
	o.Commit()
	return nil
}

func GetBusinessByUserId(userId int) []Business {
	o := orm.NewOrm()
	var businessRelList []UserBusinessRel
	_, err := o.QueryTable("user_business_rel").Filter("user_id", userId).All(&businessRelList)
	if err != nil {
		return nil
	}
	var businessList []Business
	for _, v := range businessRelList {
		b := Business{BusinessId: v.BusinessId}
		o.Read(&b)
		businessList = append(businessList, b)
	}
	return businessList
}
