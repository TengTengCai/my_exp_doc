package models

import (
	"cpxerp/util"
	"errors"
	"fmt"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"reflect"
	"strconv"
	"strings"
	"time"
)

//用户
type User struct {
	Id                  int       `orm:"column(user_id);pk;auto;" form:"Id"`
	EmployeeNum         string    `orm:"column(employee_num);size(32)" form:"EmployeeNum"`                   // 员工编号
	ContractNum         string    `orm:"column(contract_num);size(32)" form:"ContractNum"`                   // 合同编号
	Name                string    `orm:"column(name);size(10)" form:"Name"`                                  //姓名
	RecruitMethod       string    `orm:"column(recruit_method);size(32)" form:"RecruitMethod"`               // 招聘方式
	Email               string    `orm:"column(email);size(50);unique" form:"Email"`                         //邮箱
	QQNum               string    `orm:"column(qq_num);size(32);unique" form:"QQNum"`                        // QQ号
	Password            string    `orm:"column(password);size(250)" form:"Password"`                         //密码
	PhoneNumber         string    `orm:"column(phone_number);size(11)" form:"PhoneNumber"`                   //手机号码
	ContractNature      string    `orm:"column(contract_nature);size(16)" form:"ContractNature"`             // 合同性质
	ContractPeriod      int       `orm:"column(contract_period);" form:"ContractPeriod"`                     //合同期限
	TimeOfEntry         time.Time `orm:"column(time_of_entry);type(date)" form:"TimeOfEntry"`                //入职时间
	RegularTime         time.Time `orm:"column(regular_time);type(date);null" form:"RegularTime"`            // 转正日期
	ProbationPeriod     int       `orm:"column(probation_period);" form:"ProbationPeriod"`                   // 实习期
	PracticeEndTime     time.Time `orm:"column(practice_end_time);type(date);null" form:"PracticeEndTime"`   // 实习截至时间
	ContractEndTime     time.Time `orm:"column(contract_end_time);type(date);null" form:"ContractEndTime"`   // 合同结束时间
	IDCard              string    `orm:"column(id_card);size(20)" form:"IDCard"`                             // 身份证编号
	Birthday            time.Time `orm:"column(birthday);size(20)" form:"Birthday"`                          //出生日期
	Age                 int       `orm:"column(age);" form:"Age"`                                            // 年龄
	Sex                 string    `orm:"column(sex); size(4)" form:"Sex"`                                    // 性别
	Nation              string    `orm:"column(nation);size(14)" form:"Nation"`                              //民族
	NativePlace         string    `orm:"column(native_place);size(10)" form:"NativePlace"`                   //籍贯
	GraduateSchool      string    `orm:"column(graduate_school);size(50)" form:"GraduateSchool"`             //毕业学校
	Major               string    `orm:"column(major);size(40)" form:"Major"`                                //专业
	Education           string    `orm:"column(education);size(8)" form:"Education"`                         //学历
	GraduateTime        time.Time `orm:"column(graduate_time);type(date);null" form:"GraduateTime"`          //毕业时间
	PoliticalOutlook    string    `orm:"column(political_outlook);size(10)" form:"PoliticalOutlook"`         //政治面貌
	MaritalStatus       string    `orm:"column(marital_status); size(4)" form:"MaritalStatus"`               // 婚姻状况
	LanguageLevel       string    `orm:"column(language_level); size(32)" form:"LanguageLevel"`              // 外语等级
	ComputerLevel       string    `orm:"column(computer_level); size(32)" form:"ComputerLevel"`              // 计算机等级
	WorkingHours        time.Time `orm:"column(working_hours);size(20)" form:"WorkingHours"`                 //参加工作时间
	WorkUnit            string    `orm:"column(work_unit);size(200)" form:"WorkUnit"`                        //入职前工作单位
	RegisteredResidence string    `orm:"column(registered_residence);size(128);" form:"RegisteredResidence"` // 户籍所在地
	RegisteredType      string    `orm:"column(registered_type);size(8);" form:"RegisteredType"`             // 户籍类型
	BirthAddress        string    `orm:"column(birth_address);size(128);" form:"BirthAddress"`               // 出生地址
	PresentAddress      string    `orm:"column(present_address);size(128);" form:"PresentAddress"`           // 现居地址
	EmergencyContact    string    `orm:"column(emergency_contact);size(10)" form:"EmergencyContact"`         //紧急联系人
	Relationship        string    `orm:"column(relationship);size(10)" form:"Relationship"`                  //与紧急联系人关系
	ContactInformation  string    `orm:"column(contactInformation);size(11)" form:"ContactInformation"`      //紧急联系人联系方式

	BankCardInfo           string  `orm:"column(bank_card_info); size(64);" form:"BankCardInfo"`                                 // 银行卡信息
	BankCardNum            string  `orm:"column(bank_card_num); size(40);" form:"BankCardNum"`                                   // 银行卡号
	InternshipSalary       float64 `orm:"column(internship_salary);digits(12);decimals(2);" form:"InternshipSalary"`             // 实习薪资
	ProbationBasicSalary   float64 `orm:"column(probation_basic_salary);digits(12);decimals(2);" form:"ProbationBasicSalary"`    // 试用期基本薪资
	ProbationAchieveSalary float64 `orm:"column(probation_achieve_salary);digits(12);decimals(2);"form:"ProbationAchieveSalary"` // 试用期绩效工资
	RegularBasicSalary     float64 `orm:"column(regular_basic_salary);digits(12);decimals(2);" form:"RegularBasicSalary"`        // 转正基本薪资
	RegularAchieveSalary   float64 `orm:"column(regular_achieve_salary);digits(12);decimals(2);" form:"RegularAchieveSalary"`    // 转正绩效薪资
	TaxSubsidy             float64 `orm:"column(tax_subsidy);digits(12);decimals(2);" form:"TaxSubsidy"`                         // 税后补贴
	OtherSubsidies         float64 `orm:"column(other_subsidies);digits(12);decimals(2);"form:"OtherSubsidies"`                  // 其他补贴

	NumOfInsurance             float64   `orm:"column(num_of_insurance);digits(12);decimals(2);default(0.00);" form:"NumOfInsurance"`                           // 基本养老保险基数
	NumOfUnempLoymentInsurance float64   `orm:"column(num_of_unemp_loyment_insurance);digits(12);decimals(2);default(0.00);" form:"NumOfUnempLoymentInsurance"` // 失业保险基数
	NumOfMedicalInsurance      float64   `orm:"column(num_of_medical_insurance);digits(12);decimals(2);default(0.00);" form:"NumOfMedicalInsurance"`            // 基本医疗保险基数
	AccumulationFundBase       float64   `orm:"column(accumulation_fund_base);digits(12);decimals(2);default(0.00)" form:"AccumulationFundBase"`                // 公积金基数
	PaymentMonth               time.Time `orm:"column(payment_month);type(date); null" form:"PaymentMonth"`                                                     // 缴纳月份,会根据入职时间来计算,如果大于15号为下一个月
	SocialSecurityType         string    `orm:"column(social_security_type);size(4);default(城镇);" form:"SocialSecurityType"`                                    // 社保类型

	AreaId         int    `orm:"column(area);" form:"AreaId"`                            // 地区ID
	EmployeeNature string `orm:"column(employee_nature);size(10)" form:"EmployeeNature"` //员工性质 外派、合同制、实习,兼职
	DepartmentId   int    `orm:"column(department_id)" form:"DepartmentId"`              //所在部门ID
	RoleId         int    `orm:"column(role_id)" form:"RoleId"`                          //岗位
	Incumbency     string `orm:"column(incumbency);size(4)" form:"Incumbency"`           //在职状态
	//BusinessId     int    `orm:"column(business_id);size(11)" form:"BusinessId"`         //所属业务线
	PostAttributes string `orm:"column(post_attributes);size(10)" form:"PostAttributes"` //岗位属性,技术,管理,专业
	PostRank       string `orm:"column(post_rank);size(10)" form:"PostRank"`             //岗位职级

	CompanyId     int       `orm:"column(company_id);size(10)" form:"CompanyId"`                           //公司id
	Superior      int       `orm:"column(superior_id)" form:"Superior"`                                    // 上级领导                                                        //上级领导
	CreateTime    time.Time `orm:"column(create_time);auto_now_add;type(datetime);null" form:"CreateTime"` //创建时间
	UpdateTime    time.Time `orm:"column(update_time);auto_now;type(datetime);null" form:"UpdateTime"`     //更新时间
	BusinessStr   string    `orm:"column(business_str);size(128);"`
	AttendanceNum string    `orm:column(attendance_num);size(8);" form:"AttendanceNum"` // 考勤卡号
	NatureOfWork  string    `orm:column(nature_of_work);size(8);" form:"NatureOfWork"`  // 工作性质：转正，试用，实习
	PwdStatus     int       `orm:"column(pwd_status);default(0)" form:"PwdStatus"`      //密码状态，0：初始化，1，已修改
}

//手动代码段

//按名字查询
func (u User) GetOneByName(email string) (error, User) {
	o := orm.NewOrm()
	user := User{Email: email}
	qs := o.QueryTable(user)
	err := qs.Filter("email", email).Limit(1).One(&user)

	if err != nil {
		logs.Error("查询不到")
		return err, User{}
	} else {
		return nil, user
	}

}

/*
根据用户id查询用户
*/
func (u *User) GetByUserId(userId int) *User {
	o := orm.NewOrm()
	user := User{}
	err := o.Raw("select * from user where user_id=?", userId).QueryRow(&user)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	return &user
}

/*
按当前公司id和部门id查询所有
*/
func (u *User) GetByComIdAndDepartId(companyId, departmentId int) *[]User {
	o := orm.NewOrm()
	users := []User{}
	_, err := o.Raw("select * from user where company_id=? AND department_id=? and role_id!=5", companyId, departmentId).QueryRows(&users)
	if err != nil {
		logs.Error("exec select faild", err)
		return &[]User{}
	}
	return &users
}

/*
按当前公司id和上级id查询所有
*/
func (u *User) GetByComIdAndDSuperId(companyId, superId int) *[]User {
	o := orm.NewOrm()
	users := []User{}
	_, err := o.Raw("select * from user where company_id=? AND superior_id=? and role_id!=5", companyId, superId).QueryRows(&users)
	if err != nil {
		logs.Error("exec select faild", err)
		return &[]User{}
	}
	return &users
}

/*
查询所有的用户，可以传递的名字和公司id进查询,关联部门，公司，商业线
auth: TTC
*/
func SelectAllUser(name string, company_id int, page int, limit int) *uitl.Page {
	count := GetCountBy(name, company_id)
	newPage := uitl.NewPage(page, limit, int(count))
	users := []orm.Params{}
	o := orm.NewOrm()
	if name == "" {
		_, err := o.Raw(
			"select * from user as u "+
				"left join department as d "+
				"on u.department_id = d.department_id "+
				"left join company as c "+
				"on u.company_id = c.company_id "+
				"left join business as b "+
				"on u.business_id = b.business_id "+
				"where u.company_id = ? and u.role_id != 5 limit ?, ?;",
			company_id, newPage.StartIndex, newPage.PageSize).Values(&users)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}

	} else {
		_, err := o.Raw(
			"select * from user as u "+
				"left join department as d "+
				"on u.department_id = d.department_id "+
				"left join company as c "+
				"on u.company_id = c.company_id "+
				"left join business as b "+
				"on u.business_id = b.business_id "+
				"where u.company_id = ? and name like '%"+name+"%' and u.role_id != 5  limit ?, ?;",
			company_id, newPage.StartIndex, newPage.PageSize).Values(&users)
		if err != nil {
			logs.Error("exec select faild", err)
			return nil
		}
	}
	newPage.Data = &users

	return newPage
}

/*
根据用户姓名，编号，公司id查询员工信息
*/
func (u *User) SelectByNameEmCom() *User {
	o := orm.NewOrm()
	err := o.Raw("SELECT * FROM user WHERE name=? AND  company_id=? AND employee_num=?", u.Name, u.CompanyId, u.EmployeeNum).QueryRow(&u)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	return u
}

/*
传入Map,过滤条件,查询数据
*/
func SelectUserByFilter(filter map[string]interface{}, key string, page, limit int) []orm.Params {
	baseSql := "select u.*, d.department_name, " +
		"r.role_name, a.area_name, c.company_name, " +
		"u1.name as superior_name " +
		"from user as u " +
		"left join department as d " +
		"on d.department_id = u.department_id " +
		"left join role as r " +
		"on r.role_id = u.role_id " +
		"left join area as a " +
		"on a.area_id = u.area " +
		"left join company as c " +
		"on c.company_id = u.company_id " +
		"left join user as u1 " +
		"on u1.user_id = u.superior_id "
	isFirst := true
	for k, v := range filter {
		var sqlItem string
		kt, s := uitl.AnalyzeCondition(k)
		str := uitl.TypeToString(v)
		if isFirst {
			sqlItem = "where u." + kt + s + "'" + str + "' "
			isFirst = false
		} else {
			sqlItem = "and u." + kt + s + "'" + str + "' "
		}
		baseSql += sqlItem
	}

	if len(key) > 0 {
		if isFirst {
			baseSql += "where "
			isFirst = false
		} else {
			baseSql += "and "
		}
		baseSql += "u.name like '%" + key + "%' "
	}

	if page != 0 && limit != 0 {
		baseSql += "limit " + fmt.Sprint(limit*(page-1)) + ", " + fmt.Sprint(limit)
	}
	var users []orm.Params
	o := orm.NewOrm()
	_, err := o.Raw(baseSql).Values(&users)
	if err != nil {
		logs.Info(err)
		return nil
	}
	return users
}

//查询总数
func GetCount() int {
	num := []int{}
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from use").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

/*
按条件获取对于的数据条数
auth:ttc
date: 2018-08-30
*/
func GetCountBy(name string, company_id int) int64 {
	var cnt int64
	var err error
	o := orm.NewOrm()
	qs := o.QueryTable("user")
	if company_id != 0 {
		qs = qs.Filter("CompanyId", company_id)
	}
	if name != "" {
		qs = qs.Filter("Name__contains", name)
	}
	cnt, err = qs.Count()
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return cnt
}

/*
获取当前过滤条件的数据总数
auth: ttc
date: 2018-08-30
*/
func GetUserCountByFilter(filter map[string]interface{}, key string) int64 {
	o := orm.NewOrm()
	qs := o.QueryTable("user")
	for k, v := range filter {
		qs = qs.Filter(k, v)
	}
	qs.Filter("name__contains", key)
	cnt, err := qs.Count()
	if err != nil {
		logs.Info(err)
		return 0
	}
	return cnt
}

/*
根据公司ID获取所有用户
*/
func (u *User) GetUserByCompany(companyId int) []User {
	users := []User{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from user where company_id=? and role_id !=5", companyId).QueryRows(&users)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}

	return users
}

/*
根据公司ID获取所有用户未离职员工
*/
func (u *User) GetUserNotLeaveOffice(companyId int) []User {
	users := []User{}
	o := orm.NewOrm()
	_, err := o.Raw("select * from user where company_id=1 and role_id !=5 and incumbency!='离职'", companyId).QueryRows(&users)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}

	return users
}

//根据用户id更新角色id
func (u *User) UpdateRoleIdByUserId(userId, roleId int) bool {
	o := orm.NewOrm()
	_, err := o.Raw("UPDATE user SET role_id=?,update_time=? WHERE user_id=?", roleId, time.Now(), userId).Exec()
	if err != nil {
		return false
	} else {
		return true
	}
}

/*
查询当前员工最大的员工编号
*/
func (u *User) SelectUserNum(companyId int) *User {
	user := User{}
	o := orm.NewOrm()
	err := o.Raw("SELECT * FROM user WHERE company_id=? and role_id !=5 ORDER BY employee_num  DESC LIMIT 1", companyId).QueryRow(&user)
	if err != nil {
		logs.Error("exec selectUsernum faild", err)
		return nil
	}
	return &user
}

/*
根据身份证查询用户信息
*/
func (u *User) SelectByIdCard(idCard string) *User {
	user := User{}
	o := orm.NewOrm()
	err := o.Raw("select * from user where id_card=?", idCard).QueryRow(&user)
	if err != nil {
		//logs.Error("exec selectIdCard faild", err)
		return nil
	}
	return &user
}

/*
 插入excel表格数据，参数users，maps
*/
func (u *User) AddByExcel(users []User) (bool, string) {
	o := orm.NewOrm()
	o.Begin()
	num := 0
	sqlUser := "INSERT INTO user (employee_num,contract_num,name,recruit_method,email," +
		" qq_num,password,phone_number,contract_nature,contract_period," +
		" time_of_entry,regular_time,probation_period,practice_end_time," +
		" contract_end_time,id_card,birthday,age,sex," +
		" nation,native_place,graduate_school,major,education," +
		" graduate_time,political_outlook,marital_status,language_level,computer_level," +
		" working_hours,work_unit,registered_residence,registered_type,birth_address," +
		" present_address,emergency_contact,relationship,contactInformation,bank_card_info," +
		" bank_card_num,internship_salary,probation_basic_salary,probation_achieve_salary,regular_basic_salary," +
		" regular_achieve_salary,tax_subsidy,other_subsidies,num_of_insurance,num_of_unemp_loyment_insurance,num_of_medical_insurance,accumulation_fund_base," +
		" payment_month,social_security_type,area,employee_nature,department_id," +
		" role_id,incumbency,post_attributes,post_rank,company_id," +
		" create_time,update_time,business_str,attendance_num,nature_of_work,pwd_status) VALUES" +
		" (?,?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?,?," +
		" ?,?,?,?,?,?)"
	for i := 0; i < len(users); i++ {
		result, err := o.Raw(sqlUser, users[i].EmployeeNum, users[i].ContractNum, users[i].Name, users[i].RecruitMethod, users[i].Email,
			users[i].QQNum, users[i].Password, users[i].PhoneNumber, users[i].ContractNature, users[i].ContractPeriod,
			users[i].TimeOfEntry, users[i].RegularTime, users[i].ProbationPeriod, users[i].PracticeEndTime,
			users[i].ContractEndTime, users[i].IDCard, users[i].Birthday, users[i].Age, users[i].Sex,
			users[i].Nation, users[i].NativePlace, users[i].GraduateSchool, users[i].Major, users[i].Education,
			users[i].GraduateTime, users[i].PoliticalOutlook, users[i].MaritalStatus, users[i].LanguageLevel, users[i].ComputerLevel,
			users[i].WorkingHours, users[i].WorkUnit, users[i].RegisteredResidence, users[i].RegisteredType, users[i].BirthAddress,
			users[i].PresentAddress, users[i].EmergencyContact, users[i].Relationship, users[i].ContactInformation, users[i].BankCardInfo,
			users[i].BankCardNum, users[i].InternshipSalary, users[i].ProbationBasicSalary, users[i].ProbationAchieveSalary, users[i].RegularBasicSalary,
			users[i].RegularAchieveSalary, users[i].TaxSubsidy, users[i].OtherSubsidies, users[i].NumOfInsurance, users[i].NumOfUnempLoymentInsurance, users[i].NumOfMedicalInsurance, users[i].AccumulationFundBase,
			users[i].PaymentMonth, users[i].SocialSecurityType, users[i].AreaId, users[i].EmployeeNature, users[i].DepartmentId,
			users[i].RoleId, users[i].Incumbency, users[i].PostAttributes, users[i].PostRank, users[i].CompanyId,
			users[i].CreateTime, users[i].UpdateTime, users[i].BusinessStr, users[i].AttendanceNum, users[i].NatureOfWork, users[i].PwdStatus).Exec()
		if err != nil {
			logs.Error("insert excel user err，", err)
			errs := strings.ToLower(fmt.Sprintf("insert excel user err，%s", err))
			if strings.Contains(errs, "duplicate entry") {
				o.Rollback()
				return false, "某些信息重复请检查！"
			}
			o.Rollback()
			return false, "表格数据有误请检查再试"
		}
		id, err := result.LastInsertId()
		if err != nil {
			o.Rollback()
			return false, "表格数据有误请检查再试"
		}
		idstr := strings.Split(users[i].BusinessStr, ",")
		ids := make([]int, 0)
		bus := Business{}
		for _, v := range idstr {
			_, b := bus.GetBusinessByName(v)
			ids = append(ids, b.BusinessId)
		}
		sql := "INSERT into user_business_rel (user_id,business_id) VALUES "
		for i := 0; i < len(ids); i++ {
			if i == 0 {
				sql = sql + " (" + strconv.Itoa(int(id)) + "," + strconv.Itoa(ids[i]) + ")"
			} else {
				sql = sql + " ,(" + strconv.Itoa(int(id)) + "," + strconv.Itoa(ids[i]) + ")"
			}
		}
		_, err1 := o.Raw(sql).Exec()
		if err1 != nil {
			logs.Error("insert excel userBusi err，", err1)
			o.Rollback()
			return false, "表格数据有误请检查再试"
		}
		num = num + 1
	}
	if num == len(users) {
		o.Commit()
		return true, "导入成功"
	} else {
		o.Rollback()
		return false, "表格数据有误请检查再试"
	}
}

/*
查询试用期和实习期的员工
*/
func (u *User) SelectNotOfficialUsers() []User {
	o := orm.NewOrm()
	users := []User{}
	_, err := o.Raw("SELECT * FROM user WHERE nature_of_work in ('试用','实习') AND incumbency in ('在职','病休')").QueryRows(&users)
	if err != nil {
		logs.Info("select NotOfficialUsers err ,", err)
		return nil
	}
	return users

}

/*
查询所有在职员工
*/
func (u *User) SelectOfficialUsers(companyId int, page, limit int) *uitl.Page {
	o := orm.NewOrm()
	count := u.CountOfficialUsers(companyId)
	newPage := uitl.NewPage(page, limit, count)
	users := []User{}
	_, err := o.Raw("SELECT * FROM user WHERE nature_of_work in ('转正','实习','试用') and incumbency in ('在职','病休') and company_id=? limit ?, ?", companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&users)
	if err != nil {
		logs.Info("select OfficialUsers err ,", err)
		return nil
	}
	newPage.Data = &users
	return newPage

}

/*
查询所有在职及已转正的员工
*/
func (u *User) SelectOfficialormalUsers(companyId int) []User {
	o := orm.NewOrm()

	users := []User{}
	_, err := o.Raw("SELECT * FROM user WHERE nature_of_work in ('转正') and incumbency in ('在职','病休') and company_id=? ", companyId).QueryRows(&users)
	if err != nil {
		logs.Info("select OfficialUsers err ,", err)
		return nil
	}

	return users

}

/*
统计所有在职员工
*/
func (u *User) CountOfficialUsers(companyId int) int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("SELECT COUNT(*) FROM user WHERE nature_of_work in ('转正','实习','试用') and incumbency in ('在职','病休') and company_id=?").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]

}

/*
查询每个公司的人事和人事行政专员
*/
func (u *User) SelectHRUsers() []User {
	o := orm.NewOrm()
	users := []User{}
	_, err := o.Raw("SELECT u.* ,r.role_name FROM user u LEFT JOIN role r ON r.role_id=u.role_id WHERE r.role_name in ('HRBP','人事行政专员')AND u.incumbency='在职'").QueryRows(&users)
	if err != nil {
		logs.Error("select NotOfficialUsers err ,", err)
		return nil
	}
	return users

}

/*
修改密码
*/
func (u *User) UpdatePassword() (b bool) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE user SET password=?,pwd_status=? WHERE user_id=?", u.Password, u.PwdStatus, u.Id).Exec()
	if err != nil {
		logs.Error("update user password faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

//反向生成代码段
func (t *User) TableName() string {
	return "user"
}

// AddUser insert a new User into database and returns
// last inserted Id on success.
func AddUser(m *User) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetUserById retrieves User by Id. Returns error if
// Id doesn't exist
func GetUserById(id int) (v *User, err error) {
	o := orm.NewOrm()
	v = &User{Id: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllUser retrieves all User matches certain condition. Returns empty list if
// no records exist
func GetAllUser(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(User))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []User
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateUser updates User by Id and returns error if
// the record to be updated doesn't exist
func UpdateUserById(m *User) (err error) {
	o := orm.NewOrm()
	v := User{Id: m.Id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteUser deletes User by Id and returns error if
// the record to be deleted doesn't exist
func DeleteUser(id int) (err error) {
	o := orm.NewOrm()
	v := User{Id: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&User{Id: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

/*
通过状态来获取所有用户
*/
func GetAllUsersByStatus(status string, companyId int) []User {
	o := orm.NewOrm()
	var users []User
	_, err := o.QueryTable(new(User)).
		Filter("Incumbency", status).   // 在职状态
		Filter("CompanyId", companyId). // 公司ID
		All(&users)
	if err != nil {
		return nil
	}
	return users
}
