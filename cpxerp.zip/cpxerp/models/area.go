package models

import (
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
)

type Area struct {
	AreaId   int    `orm:"column(area_id);pk;auto";form:"AreaId"`
	AreaName string `orm:"column(area_name)";form:"AreaName"`
	Flag     string `orm:"-"`
}

func (t *Area) TableName() string {
	return "area"
}

func init() {
	orm.RegisterModel(new(Area))
}

func (c *Area) Add() (bool, error) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("INSERT into area(area_name) VALUES(?)",
		c.AreaName).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("insert area err, ", err)
		return false, err
	}
	o.Commit()
	return true, nil
}

func (c *Area) Update() (bool, error) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("Update area set area_name=? where area_id=?",
		c.AreaName, c.AreaId).Exec()
	if err != nil {
		o.Rollback()
		logs.Error("update area err, ", err)
		return false, err
	}
	o.Commit()
	return true, nil
}

func (c *Area) GetAreaByName(name string) (bool, Area) {
	o := orm.NewOrm()
	area := Area{}
	err := o.Raw("SELECT * FROM area where area_name = ? ", name).QueryRow(&area)
	if err != nil {
		logs.Error("select role err", err, name)
		return false, Area{}
	}
	return true, area
}

func (c *Area) GetAreaById(id int) *Area {
	o := orm.NewOrm()
	area := Area{}
	err := o.Raw("SELECT * FROM area where area_id = ? ", id).QueryRow(&area)
	if err != nil {
		logs.Error("select role err", err)
		return nil
	}
	return &area
}

func (c *Area) FinadAllByPage(page int, limit int) *uitl.Page {
	count := c.GetCount()
	newPage := uitl.NewPage(page, limit, count)
	areas := []Area{}
	o := orm.NewOrm()
	num, err := o.Raw("select * from area limit ?,?", newPage.StartIndex, newPage.PageSize).QueryRows(&areas)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	fmt.Println(num)
	newPage.Data = &areas
	return newPage
}

func (c *Area) GetCount() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from area").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]
}

func SelectAllArea() []Area {
	o := orm.NewOrm()
	var areas []Area
	_, err := o.QueryTable("area").All(&areas)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return areas
}

func GetAreaById(id int) (v *Area, err error) {
	o := orm.NewOrm()
	v = &Area{AreaId: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}
