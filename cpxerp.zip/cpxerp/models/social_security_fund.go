package models

import (
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
)

type SocialSecurityFund struct {
	Id                                int     `orm:"column(id);pk;auto";form:"Id"`
	PercentageOfInsurance             float64 `orm:"column(percentage_of_insurance);digits(12);decimals(3);";form:"PercentageOfInsurance"`                          //基本养老保险比例
	PercentageOfUnempLoymentInsurance float64 `orm:"column(percentage_of_unempLoyment_insurance);digits(12);decimals(3);";form:"PercentageOfUnempLoymentInsurance"` //失业保险比例
	PercentageOfMedicalInsurance      float64 `orm:"column(percentage_of_medical_insurance);digits(12);decimals(3);";form:"PercentageOfMedicalInsurance"`           //基本医疗保险比例
	PercentageOfFunc                  float64 `orm:"column(percentage_of_func);digits(12);decimals(3);";form:"PercentageOfFunc"`                                    //公积金比例
	ExemptionAmount                   float64 `orm:"column(exemption_amount);digits(12);decimals(3);";form:"ExemptionAmount"`                                       //起征点
	CompanyId                         int     `orm:"column(company_id)";form:"CompanyId"`
}

type SocialSecurityFundForUser struct {
	EmployeeNum                string  //员工编号
	Name                       string  //姓名
	NatureOfWork               string  // 工作性质：转正，试用，实习
	BasicSalary                float64 //基本工资
	NumOfInsurance             float64 //基本养老保险基数
	Insurance                  float64 //基本养老保险费用
	NumOfUnempLoymentInsurance float64 //失业保险基数
	UnempLoymentInsurance      float64 //失业保险费用
	NumOfMedicalInsurance      float64 //基本医疗保险基数
	MedicalInsurance           float64 //医疗保险费用
	PercentageOfFunc           float64 //公积金比例
	Func                       float64 //公积金费用
	Other                      float64 //其它保险费用
}

func init() {
	orm.RegisterModel(new(SocialSecurityFund))
}

func (s *SocialSecurityFund) Select() *SocialSecurityFund {
	o := orm.NewOrm()
	err := o.Raw("SELECT * FROM social_security_fund where company_id=?", s.CompanyId).QueryRow(&s)
	if err != nil {
		logs.Info("select social_security_fund err,", err)
		return nil
	}
	return s
}

func (s *SocialSecurityFund) Insert() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("INSERT INTO social_security_fund ("+
		" percentage_of_insurance,percentage_of_unempLoyment_insurance,"+
		" percentage_of_medical_insurance,percentage_of_func,company_id,exemption_amount)"+
		" VALUES (?,?,?,?,?,?)",
		s.PercentageOfInsurance, s.PercentageOfUnempLoymentInsurance, s.PercentageOfMedicalInsurance, s.PercentageOfFunc, s.CompanyId, s.ExemptionAmount).Exec()
	if err != nil {
		o.Rollback()
		logs.Info("insert social_security_fund err,", err)
		return false
	}
	o.Commit()
	return true
}

func (s *SocialSecurityFund) Update() bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE social_security_fund set percentage_of_insurance=?,percentage_of_unempLoyment_insurance=?,percentage_of_medical_insurance=?,percentage_of_func=?,exemption_amount=?  WHERE id=?",
		s.PercentageOfInsurance, s.PercentageOfUnempLoymentInsurance, s.PercentageOfMedicalInsurance, s.PercentageOfFunc, s.ExemptionAmount, s.Id).Exec()
	if err != nil {
		o.Rollback()
		logs.Info("update social_security_fund err,", err)
		return false
	}
	o.Commit()
	return true
}
