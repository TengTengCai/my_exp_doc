package models

import (
	"errors"
	"fmt"
	"reflect"
	"strings"
	"time"

	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
)

type AbnormalChange struct {
	Id              int       `orm:"column(id);auto" form:"Id"`
	Applyer         int       `orm:"column(applyer)" description:"申请人" form:"Applyer"`
	DepartId        int       `orm:"column(depart_id)" description:"部门" form:"DepartId"`
	EntryTime       time.Time `orm:"column(entry_time);type(date)" description:"入职时间" form:"EntryTime"`
	EffectTime      time.Time `orm:"column(effect_time);type(date)" description:"期望生效时间" form:"EffectTime"`
	ApplyType       string    `orm:"column(apply_type);size(16)" description:"申请类型" form:"ApplyType"`
	Reason          string    `orm:"column(reason);size(256)" description:"理由" form:"Reason"`
	LeaderId        int       `orm:"column(leader_id)" description:"审核直属领导" `
	DepartStatus    int8      `orm:"column(depart_status)" description:"部门主管审核"`
	PersonnelStatus int8      `orm:"column(personnel_status)" description:"人事审核状态"`
	CeoStatus       int8      `orm:"column(ceo_status)" description:"ceo审核状态"`
	IsOk            int8      `orm:"column(is_ok)" description:"总状态"`
	// 下面三个字段会更具添加时的异动类型来进行初始化
	IsChangeInfo   int8 `orm:"column(is_change_info)" description:"是否改变基本信息"`   // 0是待修改,1是已修改
	IsChangePost   int8 `orm:"column(is_change_post)" description:"是否改变岗位信息"`   // 0是带修改,1是已修改
	IsChangeSalary int8 `orm:"column(is_change_salary)" description:"是否改变薪资信息"` // 0是待修改,1是已修改
	CompanyId      int  `orm:"column(company_id)" description:"公司ID"`
}

func (t *AbnormalChange) TableName() string {
	return "abnormal_change"
}

func init() {
	orm.RegisterModel(new(AbnormalChange))
}

// AddAbnormalChange insert a new AbnormalChange into database and returns
// last inserted Id on success.
func AddAbnormalChange(m *AbnormalChange) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetAbnormalChangeById retrieves AbnormalChange by Id. Returns error if
// Id doesn't exist
func GetAbnormalChangeById(id int) (v *AbnormalChange, err error) {
	o := orm.NewOrm()
	v = &AbnormalChange{Id: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllAbnormalChange retrieves all AbnormalChange matches certain condition. Returns empty list if
// no records exist
func GetAllAbnormalChange(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(AbnormalChange))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []AbnormalChange
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateAbnormalChange updates AbnormalChange by Id and returns error if
// the record to be updated doesn't exist
func UpdateAbnormalChangeById(m *AbnormalChange) (err error) {
	o := orm.NewOrm()
	v := AbnormalChange{Id: m.Id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteAbnormalChange deletes AbnormalChange by Id and returns error if
// the record to be deleted doesn't exist
func DeleteAbnormalChange(id int) (err error) {
	o := orm.NewOrm()
	v := AbnormalChange{Id: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&AbnormalChange{Id: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

/*
多条件查询
*/
func SelectAbnormalChangeByFilter(filter map[string]interface{}, page, limit int) []orm.Params {
	baseSql := "select a.*, " +
		"u.name as user_name, " +
		"d.department_name as depart_name " +
		"from abnormal_change as a " +
		"left join user as u " +
		"on u.user_id = a.applyer " +
		"left join department as d " +
		"on d.department_id = a.depart_id "

	isFirst := true
	for k, v := range filter {
		var sqlItem string
		kt, s := uitl.AnalyzeCondition(k)
		str := uitl.TypeToString(v)
		if isFirst {
			sqlItem = "where a." + kt + s + "'" + str + "' "
			isFirst = false
		} else {
			sqlItem = "and a." + kt + s + "'" + str + "' "
		}
		baseSql += sqlItem
	}

	if page != 0 && limit != 0 {
		baseSql += "limit " + fmt.Sprint(limit*(page-1)) + ", " + fmt.Sprint(limit)
	}

	var abnChanges []orm.Params
	o := orm.NewOrm()
	_, err := o.Raw(baseSql).Values(&abnChanges)
	if err != nil {
		logs.Error(err)
		return nil
	}
	return abnChanges
}

/*
多条件查询的数据总和
*/
func GetAbnormalChangeCountByFilter(filter map[string]interface{}) int {
	o := orm.NewOrm()
	qs := o.QueryTable(new(AbnormalChange))
	for k, v := range filter {
		qs = qs.Filter(k, v)
	}
	count, err := qs.Count()
	if err != nil {
		return 0
	}
	return int(count)
}
