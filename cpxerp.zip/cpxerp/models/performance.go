package models

import (
	"cpxerp/util"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"time"
)

type Performance struct {
	Id             int       `orm:"column(id);pk;auto;" form:"Id"`
	UserId         int       `orm:"column(user_id)" form:"UserId"`                                         //员工id
	EmployeeNum    string    `orm:"column(employee_num);size(32)" form:"EmployeeNum"`                      // 员工编号
	Name           string    `orm:"column(name);size(10)" form:"Name"`                                     //员工姓名
	Month          time.Time `orm:"column(month);type(date); null" form:"Month"`                           //月份
	CompletionRate float64   `orm:"column(completion_rate);digits(12);decimals(2);";form:"CompletionRate"` //完成率得分
	ShowAttitude   float64   `orm:"column(show_attitude);digits(12);decimals(2);";form:"ShowAttitude"`     //表现得分
	ShowExplain    string    `orm:"column(show_explain);size(1000)";form:"ShowExplain"`                    //表现说明
	Overall        float64   `orm:"column(overall);digits(12);decimals(2);";form:"Overall"`                //综合得分
	ExamineStatus  int       `orm:"column(examine_status)";form:"ExamineStatus"`                           //综合得分>=1.2的需要审核，0：待审核，1：通过，2：不通过，小于1.2的不许审核状态为3
	Remark         string    `orm:"column(remark);size(10)" form:"Remark"`                                 //审核不通过需说明原因
	ApplyStatus    int       `orm:"column(apply_status);size(10)" form:"ApplyStatus"`                      //初始0：可发起申请修改，1：待人事审核，2：同意，3：不同意，4：不可修改
}

func init() {
	orm.RegisterModel(new(Performance))
}

/*
录入数据
*/
func (p *Performance) Add() bool {
	o := orm.NewOrm()
	o.Begin()
	_, e := o.Raw("INSERT INTO performance (user_id,month,completion_rate,show_attitude,show_explain,overall,examine_status,apply_status)VALUES(?,?,?,?,?,?,?,?)",
		p.UserId, p.Month, p.CompletionRate, p.ShowAttitude, p.ShowExplain, p.Overall, p.ExamineStatus, p.ApplyStatus).Exec()
	if e != nil {
		o.Rollback()
		logs.Info("insert performance err , ", e)
		return false
	}
	o.Commit()
	return true
}

/*
录入数据
*/
func (p *Performance) SelectByUserIdAndMonth(month string) *Performance {
	o := orm.NewOrm()
	performance := Performance{}
	e := o.Raw("SELECT * FROM performance WHERE user_id=? AND month=?",
		p.UserId, month).QueryRow(&performance)
	if e != nil {
		logs.Info("select performance by userid and month err , ", e)
		return nil
	}
	return &performance
}

const sql1 = "SELECT p.id,p.user_id,p.month,p.overall,p.completion_rate,p.show_attitude,p.show_explain,p.apply_status,p.examine_status,p.remark,u.name as name,u.employee_num FROM performance p " +
	" LEFT JOIN user u ON p.user_id=u.user_id " +
	" WHERE u.company_id=? "

const countsql = "SELECT COUNT(*) FROM performance p " +
	" LEFT JOIN user u ON p.user_id=u.user_id " +
	" WHERE u.company_id=? "

/*
通过id查询某条记录
*/
func (c *Performance) SelectById(companyId int) *Performance {
	o := orm.NewOrm()
	sql := sql1 + " and id=?"
	err := o.Raw(sql, companyId, c.Id).QueryRow(&c)
	if err != nil {
		logs.Info("select performance by id err,", err)
		return nil
	}
	return c

}

/*
分页查询数据，根据当前公司id及上级领导id，如果有其他条件则组装条件查询
*/
func (c *Performance) SelectByMap(page, limit, companyId int, maps map[string]interface{}) *uitl.Page {
	performances := []Performance{}

	sqlm := sql1
	sql2 := makeSqlPerfor(sqlm, maps)
	sql2 = sql2 + " limit ?,?"

	count := c.CountByMap(companyId, maps)
	newPage := uitl.NewPage(page, limit, count)
	o := orm.NewOrm()
	_, err := o.Raw(sql2, companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&performances)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}

	newPage.Data = &performances
	return newPage

}

/*
统计数据，byMap
*/
func (c *Performance) CountByMap(companyId int, maps map[string]interface{}) int {
	var num []int
	o := orm.NewOrm()
	sqlm := countsql
	sql2 := makeSqlPerfor(sqlm, maps)
	_, err := o.Raw(sql2, companyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

func makeSqlPerfor(sql string, maps map[string]interface{}) string {
	for k, v := range maps {
		if k == "month" {
			sql = sql + " AND p.month='" + v.(string) + "-01'"
		} else if k == "superior_id" {
			sql = sql + " AND u." + k + "=" + v.(string)
		} else if k == "examine_status" {
			if v == "1,3" {
				sql = sql + " AND p.examine_status in (1,3)"
			}
			if v == "0" {
				sql = sql + " AND p.examine_status=0"
			}
		} else {
			sql = sql + " AND p." + k + "=" + v.(string)
		}
	}
	return sql

}

/*
修改审核状态
*/
func (p *Performance) UpdateExamineStatus() (b bool) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE performance SET examine_status=?, remark=? WHERE id=?", p.ExamineStatus, p.Remark, p.Id).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
修改审核状态
*/
func (p *Performance) UpdateDetail() (b bool) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE performance SET month=?, completion_rate=?,show_attitude=? ,show_explain=?,overall=?,examine_status=? ,remark=?,apply_status=? WHERE id=?",
		p.Month, p.CompletionRate, p.ShowAttitude, p.ShowExplain, p.Overall, p.ExamineStatus, p.Remark, p.ApplyStatus, p.Id).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
修改申请状态
*/
func (p *Performance) UpdateApplyStatus() (b bool) {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("UPDATE performance SET apply_status=?,remark=? WHERE id=?", p.ApplyStatus, p.Remark, p.Id).Exec()
	if err != nil {
		logs.Error("update performance faild", err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}
