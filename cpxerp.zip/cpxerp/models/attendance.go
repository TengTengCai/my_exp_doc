package models

import (
	"cpxerp/util"
	"fmt"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"strconv"
	"time"
)

type Attendance struct {
	Id                     int       `orm:"column(id);pk;auto";form:"Id"`                                                           //id
	AreaId                 int       `orm:"column(area_id)" form:"AreaId"`                                                          //地区id
	AreaName               string    `orm:"column(area_name);size(10)" form:"AreaName"`                                             //地区名字
	UserId                 int       `orm:"column(user_id)" form:"UserId"`                                                          //员工id
	UserName               string    `orm:"column(user_name);size(10)" form:"UserName"`                                             //员工姓名
	EmployeeNum            string    `orm:"column(employee_num);size(32)" form:"EmployeeNum"`                                       //员工编号
	Month                  time.Time `orm:"column(month_time);type(date)" form:"Month"`                                             //所属月份
	DepartmentId           int       `orm:"column(department_id)"form:"DepartmentId"`                                               //部门id
	DepartmentName         string    `orm:"column(department_name)"form:"DepartmentName"`                                           //部门名称                                                             //所属月份
	FullAttendanceDays     float64   `orm:"column(full_attendance_days);digits(12);decimals(2);" form:"FullAttendanceDays"`         //满勤
	AttendanceDays         float64   `orm:"column(attendance_days);digits(12);decimals(2);" form:"AttendanceDays"`                  //出勤
	BusinessTravel         float64   `orm:"column(business_travel);digits(12);decimals(2);" form:"BusinessTravel"`                  //出差
	AnnualLeave            float64   `orm:"column(annual_leave);digits(12);decimals(2);" form:"AnnualLeave"`                        //年假
	PersonalLeave          float64   `orm:"column(personal_leave);digits(12);decimals(2);" form:"PersonalLeave"`                    //事假
	SickLeave              float64   `orm:"column(sick_leave);digits(12);decimals(2);" form:"SickLeave"`                            //病假
	Absenteeism            float64   `orm:"column(absenteeism);digits(12);decimals(2);" form:"Absenteeism"`                         //旷工
	TakeWorkingDaysOff     float64   `orm:"column(take_working_days_off);digits(12);decimals(2);" form:"TakeWorkingDaysOff"`        //调休
	MaritalLeave           float64   `orm:"column(marital_leave);digits(12);decimals(2);" form:"MaritalLeave"`                      //婚假
	FuneralLeave           float64   `orm:"column(funeral_leave);digits(12);decimals(2);" form:"FuneralLeave"`                      //丧假
	BreastfeedingLeave     float64   `orm:"column(breastfeeding_leave);digits(12);decimals(2);" form:"BreastfeedingLeave"`          //哺乳假
	MaternityLeave         float64   `orm:"column(maternity_leave);digits(12);decimals(2);" form:"MaternityLeave"`                  //产假
	PrenatalLeave          float64   `orm:"column(prenatal_leave);digits(12);decimals(2);" form:"PrenatalLeave"`                    //产前假
	PaternityLeave         float64   `orm:"column(paternity_leave);digits(12);decimals(2);" form:"PaternityLeave"`                  //陪产假
	EntryNotFull           float64   `orm:"column(entry_not_full);digits(12);decimals(2);" form:"EntryNotFull"`                     //入职（未满）
	QuitDeduction          float64   `orm:"column(quit_deduction);digits(12);decimals(2);" form:"QuitDeduction"`                    //离职（所扣）
	Late0To10              float64   `orm:"column(late0_10);digits(12);decimals(2);" form:"Late0To10"`                              //迟到0-10分钟
	Late10To30             float64   `orm:"column(late10_30);digits(12);decimals(2);" form:"Late10To30"`                            //迟到10-30分钟
	Late30To60             float64   `orm:"column(late30_60);digits(12);decimals(2);" form:"Late30To60"`                            //迟到30-60分钟
	Late60To120            float64   `orm:"column(late60_120);digits(12);decimals(2);" form:"Late60To120"`                          //迟到60-120分钟
	Early0To10             float64   `orm:"column(early0_10);digits(12);decimals(2);" form:"Early0To10"`                            //早退0-10分钟
	Early10To30            float64   `orm:"column(early10_30);digits(12);decimals(2);" form:"Early10To30"`                          //早退10-30分钟
	Early30To60            float64   `orm:"column(early30_60);digits(12);decimals(2);" form:"Early30To60"`                          //早退30-60分钟
	Early60To120           float64   `orm:"column(early60_120);digits(12);decimals(2);" form:"Early60To120"`                        //早退60-120分钟
	OvertopLackOfCard      float64   `orm:"column(overtop_lack_of_card);digits(12);decimals(2);" form:"OvertopLackOfCard"`          //超出缺卡次数
	OvertimePeacetime      float64   `orm:"column(overtime_peacetime);digits(12);decimals(2);" form:"OvertimePeacetime"`            //加班平时
	OvertimeGeneralHoliday float64   `orm:"column(overtime_general_holiday);digits(12);decimals(2);" form:"OvertimeGeneralHoliday"` //加班公休
	OvertimeFestival       float64   `orm:"column(overtime_festival);digits(12);decimals(2);" form:"OvertimeFestival"`              //加班节日
	CompanyId              int       `orm:"column(company_id)";form:"CompanyId"`                                                    //公司id
}

func init() {
	orm.RegisterModel(new(Attendance))
}

/*
批量插入数据
*/
func (a *Attendance) AddList(atts []Attendance, month time.Time, flag bool, companyId int) bool {
	var sqlAtt = "INSERT INTO attendance (area_id,area_name,user_id,user_name,employee_num," +
		"month_time,department_id,department_name,full_attendance_days,attendance_days," +
		"business_travel,annual_leave,personal_leave,sick_leave,absenteeism," +
		"take_working_days_off,marital_leave,funeral_leave,breastfeeding_leave,maternity_leave," +
		"prenatal_leave,paternity_leave,entry_not_full,quit_deduction,late0_10," +
		"late10_30,late30_60,late60_120,early0_10,early10_30," +
		"early30_60,early60_120,overtop_lack_of_card,overtime_peacetime,overtime_general_holiday," +
		"overtime_festival,company_id) VALUES"
	for k, v := range atts {
		if k == 0 {
			sqlAtt = sqlAtt + " ('" + strconv.Itoa(v.AreaId) + "','" + v.AreaName + "','" + strconv.Itoa(v.UserId) + "','" + v.UserName + "','" + v.EmployeeNum + "','" +
				v.Month.Format("2006-01-02 15:04:05") + "','" + strconv.Itoa(v.DepartmentId) + "','" + v.DepartmentName + "','" + uitl.Float64ToString(v.FullAttendanceDays) + "','" + uitl.Float64ToString(v.AttendanceDays) + "','" +
				uitl.Float64ToString(v.BusinessTravel) + "','" + uitl.Float64ToString(v.AnnualLeave) + "','" + uitl.Float64ToString(v.PersonalLeave) + "','" + uitl.Float64ToString(v.SickLeave) + "','" + uitl.Float64ToString(v.Absenteeism) + "','" +
				uitl.Float64ToString(v.TakeWorkingDaysOff) + "','" + uitl.Float64ToString(v.MaritalLeave) + "','" + uitl.Float64ToString(v.FuneralLeave) + "','" + uitl.Float64ToString(v.BreastfeedingLeave) + "','" + uitl.Float64ToString(v.MaternityLeave) + "','" +
				uitl.Float64ToString(v.PrenatalLeave) + "','" + uitl.Float64ToString(v.PaternityLeave) + "','" + uitl.Float64ToString(v.EntryNotFull) + "','" + uitl.Float64ToString(v.QuitDeduction) + "','" + uitl.Float64ToString(v.Late0To10) + "','" +
				uitl.Float64ToString(v.Late10To30) + "','" + uitl.Float64ToString(v.Late30To60) + "','" + uitl.Float64ToString(v.Late60To120) + "','" + uitl.Float64ToString(v.Early0To10) + "','" + uitl.Float64ToString(v.Early10To30) + "','" +
				uitl.Float64ToString(v.Early30To60) + "','" + uitl.Float64ToString(v.Early60To120) + "','" + uitl.Float64ToString(v.OvertopLackOfCard) + "','" + uitl.Float64ToString(v.OvertimePeacetime) + "','" + uitl.Float64ToString(v.OvertimeGeneralHoliday) + "','" +
				uitl.Float64ToString(v.OvertimeFestival) + "','" + strconv.Itoa(v.CompanyId) + "')"

		} else {
			sqlAtt = sqlAtt + " ,('" + strconv.Itoa(v.AreaId) + "','" + v.AreaName + "','" + strconv.Itoa(v.UserId) + "','" + v.UserName + "','" + v.EmployeeNum + "','" +
				v.Month.Format("2006-01-02 15:04:05") + "','" + strconv.Itoa(v.DepartmentId) + "','" + v.DepartmentName + "','" + uitl.Float64ToString(v.FullAttendanceDays) + "','" + uitl.Float64ToString(v.AttendanceDays) + "','" +
				uitl.Float64ToString(v.BusinessTravel) + "','" + uitl.Float64ToString(v.AnnualLeave) + "','" + uitl.Float64ToString(v.PersonalLeave) + "','" + uitl.Float64ToString(v.SickLeave) + "','" + uitl.Float64ToString(v.Absenteeism) + "','" +
				uitl.Float64ToString(v.TakeWorkingDaysOff) + "','" + uitl.Float64ToString(v.MaritalLeave) + "','" + uitl.Float64ToString(v.FuneralLeave) + "','" + uitl.Float64ToString(v.BreastfeedingLeave) + "','" + uitl.Float64ToString(v.MaternityLeave) + "','" +
				uitl.Float64ToString(v.PrenatalLeave) + "','" + uitl.Float64ToString(v.PaternityLeave) + "','" + uitl.Float64ToString(v.EntryNotFull) + "','" + uitl.Float64ToString(v.QuitDeduction) + "','" + uitl.Float64ToString(v.Late0To10) + "','" +
				uitl.Float64ToString(v.Late10To30) + "','" + uitl.Float64ToString(v.Late30To60) + "','" + uitl.Float64ToString(v.Late60To120) + "','" + uitl.Float64ToString(v.Early0To10) + "','" + uitl.Float64ToString(v.Early10To30) + "','" +
				uitl.Float64ToString(v.Early30To60) + "','" + uitl.Float64ToString(v.Early60To120) + "','" + uitl.Float64ToString(v.OvertopLackOfCard) + "','" + uitl.Float64ToString(v.OvertimePeacetime) + "','" + uitl.Float64ToString(v.OvertimeGeneralHoliday) + "','" +
				uitl.Float64ToString(v.OvertimeFestival) + "','" + strconv.Itoa(v.CompanyId) + "')"
		}
	}
	o := orm.NewOrm()
	o.Begin()
	if flag {
		_, err := o.Raw("DELETE FROM attendance WHERE company_id=? and  month_time='"+month.Format("2006-01-02")+"'", companyId).Exec()
		if err != nil {
			logs.Error(err)
			o.Rollback()
			return false
		}
	}
	_, err := o.Raw(sqlAtt).Exec()
	if err != nil {
		logs.Error(err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
根据月份查询数据
*/
func (a *Attendance) SelectByMonth(month time.Time, companyId int) (*[]Attendance, bool) {
	o := orm.NewOrm()
	atts := []Attendance{}
	_, err := o.Raw("SELECT a.* FROM attendance a LEFT JOIN user u on u.user_id=a.user_id WHERE u.company_id=? and month_time='"+month.Format("2006-01-02")+"'", companyId).QueryRows(&atts)
	if err != nil {
		logs.Error(err)
		return nil, false
	}
	return &atts, true
}

/*
根据月份删除数据
*/
func (a *Attendance) DeleteByMonth(month time.Time) bool {
	o := orm.NewOrm()
	o.Begin()
	_, err := o.Raw("DELETE FROM attendance WHERE company_id=? and  month_time='"+month.Format("2006-01-02")+"'", a.CompanyId).Exec()
	if err != nil {
		logs.Error(err)
		o.Rollback()
		return false
	}
	o.Commit()
	return true
}

/*
根据公司按月分页查询考勤数据
*/
func (a *Attendance) SelectByPage(companyId, page, limit int, month time.Time) *uitl.Page {
	o := orm.NewOrm()
	count := a.CountByCom(companyId, month)
	newPage := uitl.NewPage(page, limit, count)
	atts := []Attendance{}
	_, err := o.Raw("SELECT a.* FROM attendance a LEFT JOIN user u on u.user_id=a.user_id WHERE u.company_id=? and month_time='"+month.Format("2006-01-02")+"'"+" limit ?,?", companyId, newPage.StartIndex, newPage.PageSize).QueryRows(&atts)
	if err != nil {
		logs.Error("exec count faild", err)
		return nil
	}
	newPage.Data = atts
	return newPage
}

/*
根据公司按月全部查询考勤数据
*/
func (a *Attendance) SelectAll(companyId int, month time.Time) []Attendance {
	o := orm.NewOrm()
	atts := []Attendance{}
	_, err := o.Raw("SELECT a.* FROM attendance a LEFT JOIN user u on u.user_id=a.user_id WHERE u.company_id=? and month_time='"+month.Format("2006-01-02")+"'", companyId).QueryRows(&atts)
	if err != nil {
		logs.Error("exec count faild", err)
		return nil
	}
	return atts
}

/*
  以公司id统计考勤数据数量
*/
func (a *Attendance) CountByCom(companyId int, month time.Time) int {
	var sql = "SELECT COUNT(*) FROM attendance a LEFT JOIN user u on u.user_id=a.user_id WHERE u.company_id=? and month_time='" + month.Format("2006-01-02") + "'"
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw(sql, companyId).QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	fmt.Println(num)
	return num[0]

}
