package models

type DepartmentCompanyUser struct {
	DepartmentId   int    `orm:"department_id"`
	DepartmentName string `orm:"department_name"`
	CompanyId      int    `orm:"company_id"`
	CompanyName    string `orm:"company_name"`
	UserId         int    `orm:"user_id"`
	UserName       string `orm:"user_name"`
}
