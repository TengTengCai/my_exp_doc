package models

import (
	"cpxerp/util"
	"errors"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/orm"
	"reflect"
	"strings"
)

//角色
type Role struct {
	RoleId         int    `orm:"column(role_id);pk;auto"`
	RoleName       string `orm:"column(role_name);size(50)"`
	RoleLevel      int    `orm:"column(role_level);size(50)"`
	DepartmentId   int    `orm:"column(department_id);"`
	DepartmentName string `orm:"column(department_name);size(50)"`
	Flag           bool   `orm:"-"`
}

func init() {
	orm.RegisterModel(new(Role))
}

//手动代码段

//查询用户下的权限，根据role_id
func (r *Role) GetModuleList(roleId int) (error, []Module) {
	o := orm.NewOrm()
	models := []Module{}
	_, err := o.Raw("SELECT m.* FROM role_module r LEFT JOIN module m ON r.module_id = m.module_id WHERE r.role_id=?", roleId).QueryRows(&models)
	return err, models
}

//查询用户下的权限，根据role_id,返回map 这个方法有待修改,r已经是当前的role对象了,不需要再次传id来进行赋值
func (r *Role) GetModuleMaps(roleId int) (error, map[string]bool) {
	maps := make(map[string]bool)
	o := orm.NewOrm()
	models := []Module{}
	_, err := o.Raw("SELECT m.* FROM role_module r LEFT JOIN module m ON r.module_id = m.module_id WHERE r.role_id=?", roleId).QueryRows(&models)
	for i := 0; i < len(models); i++ {
		maps[models[i].ModuleKey] = true
	}
	return err, maps
}

//查询所有角色
func (r *Role) GetAll() []Role {
	o := orm.NewOrm()
	roles := []Role{}
	_, err := o.Raw("select * from role WHERE role_id !=5").QueryRows(&roles)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	return roles
}

func (r *Role) AddModules(roleId string, modules []string) bool {
	o := orm.NewOrm()
	o.Begin()
	if len(modules) > 0 && modules[0] != "" {
		sql := "INSERT into role_module (role_id,module_id) VALUES"
		for k, v := range modules {
			if k == 0 {
				sql = sql + "(" + roleId + "," + v + ")"
			} else {
				sql = sql + ",(" + roleId + "," + v + ")"
			}
		}

		_, err := o.Raw("DELETE FROM role_module WHERE role_id=?", roleId).Exec()
		_, err = o.Raw(sql).Exec()
		if err != nil {
			logs.Error(err)
			o.Rollback()
			return false
		} else {
			o.Commit()
			return true
		}
	} else {
		_, err := o.Raw("DELETE FROM role_module WHERE role_id=?", roleId).Exec()
		if err != nil {
			logs.Error(err)
			o.Rollback()
			return false
		} else {
			o.Commit()
			return true
		}
	}

}

func (b *Role) GetRoleByName(name string) (bool, Role) {
	o := orm.NewOrm()
	role := Role{}
	err := o.Raw("SELECT * FROM role where role_name = ? ", name).QueryRow(&role)
	if err != nil {
		logs.Error("select role err", err)
		return false, Role{}
	}
	return true, role
}

func (b *Role) GetRoleById(id int) (bool, *Role) {
	o := orm.NewOrm()
	err := o.Raw("SELECT * FROM role where role_id = ? ", id).QueryRow(&b)
	if err != nil {
		logs.Error("select role err", err)
		return false, nil
	}
	return true, b
}

func (r *Role) FinadAllByPage(page int, limit int) *uitl.Page {
	count := r.GetCount()
	newPage := uitl.NewPage(page, limit, count)
	roles := []Role{}
	o := orm.NewOrm()
	_, err := o.Raw("select r.*,d.department_name from role r LEFT JOIN department d on r.department_id=d.department_id where role_id !=5  limit ?,?", newPage.StartIndex, newPage.PageSize).QueryRows(&roles)
	if err != nil {
		logs.Error("exec select faild", err)
		return nil
	}
	newPage.Data = &roles
	return newPage
}

func (r *Role) GetCount() int {
	var num []int
	o := orm.NewOrm()
	_, err := o.Raw("select count(*) as num from role").QueryRows(&num)
	if err != nil {
		logs.Error("exec count faild", err)
		return 0
	}
	return num[0]
}

//逆向生成代码段
func (t *Role) TableName() string {
	return "role"
}

// AddRole insert a new Role into database and returns
// last inserted Id on success.
func AddRole(m *Role) (id int64, err error) {
	o := orm.NewOrm()
	id, err = o.Insert(m)
	return
}

// GetRoleById retrieves Role by Id. Returns error if
// Id doesn't exist
func GetRoleById(id int) (v *Role, err error) {
	o := orm.NewOrm()
	v = &Role{RoleId: id}
	if err = o.Read(v); err == nil {
		return v, nil
	}
	return nil, err
}

// GetAllRole retrieves all Role matches certain condition. Returns empty list if
// no records exist
func GetAllRole(query map[string]string, fields []string, sortby []string, order []string,
	offset int64, limit int64) (ml []interface{}, err error) {
	o := orm.NewOrm()
	qs := o.QueryTable(new(Role))
	// query k=v
	for k, v := range query {
		// rewrite dot-notation to Object__Attribute
		k = strings.Replace(k, ".", "__", -1)
		if strings.Contains(k, "isnull") {
			qs = qs.Filter(k, (v == "true" || v == "1"))
		} else {
			qs = qs.Filter(k, v)
		}
	}
	// order by:
	var sortFields []string
	if len(sortby) != 0 {
		if len(sortby) == len(order) {
			// 1) for each sort field, there is an associated order
			for i, v := range sortby {
				orderby := ""
				if order[i] == "desc" {
					orderby = "-" + v
				} else if order[i] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
			qs = qs.OrderBy(sortFields...)
		} else if len(sortby) != len(order) && len(order) == 1 {
			// 2) there is exactly one order, all the sorted fields will be sorted by this order
			for _, v := range sortby {
				orderby := ""
				if order[0] == "desc" {
					orderby = "-" + v
				} else if order[0] == "asc" {
					orderby = v
				} else {
					return nil, errors.New("Error: Invalid order. Must be either [asc|desc]")
				}
				sortFields = append(sortFields, orderby)
			}
		} else if len(sortby) != len(order) && len(order) != 1 {
			return nil, errors.New("Error: 'sortby', 'order' sizes mismatch or 'order' size is not 1")
		}
	} else {
		if len(order) != 0 {
			return nil, errors.New("Error: unused 'order' fields")
		}
	}

	var l []Role
	qs = qs.OrderBy(sortFields...)
	if _, err = qs.Limit(limit, offset).All(&l, fields...); err == nil {
		if len(fields) == 0 {
			for _, v := range l {
				ml = append(ml, v)
			}
		} else {
			// trim unused fields
			for _, v := range l {
				m := make(map[string]interface{})
				val := reflect.ValueOf(v)
				for _, fname := range fields {
					m[fname] = val.FieldByName(fname).Interface()
				}
				ml = append(ml, m)
			}
		}
		return ml, nil
	}
	return nil, err
}

// UpdateRole updates Role by Id and returns error if
// the record to be updated doesn't exist
func UpdateRoleById(m *Role) (err error) {
	o := orm.NewOrm()
	v := Role{RoleId: m.RoleId}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Update(m); err == nil {
			logs.Error("Number of records updated in database:", num)
		}
	}
	return
}

// DeleteRole deletes Role by Id and returns error if
// the record to be deleted doesn't exist
func DeleteRole(id int) (err error) {
	o := orm.NewOrm()
	v := Role{RoleId: id}
	// ascertain id exists in the database
	if err = o.Read(&v); err == nil {
		var num int64
		if num, err = o.Delete(&Role{RoleId: id}); err == nil {
			logs.Error("Number of records deleted in database:", num)
		}
	}
	return
}

func GetRoleByDepartId(departId int) []Role {
	o := orm.NewOrm()
	var roles []Role
	_, err := o.QueryTable(new(Role)).Filter("department_id", departId).All(&roles)
	if err != nil {
		return nil
	}
	return roles
}
