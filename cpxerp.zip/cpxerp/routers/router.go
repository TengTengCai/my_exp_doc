package routers

import (
	"cpxerp/controllers"
	"github.com/astaxie/beego"
)

func init() {
	//登录页面
	beego.Router("/login", &controllers.MainController{}, "*:Login")
	beego.Router("/dologin", &controllers.MainController{}, "post:DoLogin")

	//文件上传
	beego.Router("/erp/fileUpload", &controllers.MainController{}, "post:FileUpload")

	//文件展示
	beego.Router("/images/*", &controllers.MainController{}, "*:ImagesSee")
	beego.Router("/file/*", &controllers.MainController{}, "get:GetERPFile")

	//erp主页面
	beego.Router("/erp/index", &controllers.MainController{}, "*:Index")
	beego.Router("/erp/main", &controllers.MainController{}, "*:Main")
	beego.Router("/erp/logout", &controllers.MainController{}, "*:Logout")
	beego.Router("/erp/updatePwdHtml", &controllers.MainController{}, "*:UpdatePwdHtml")
	beego.Router("/erp/updatePwd", &controllers.MainController{}, "post:DoUpdatePwd")
	beego.Router("/erp/user/setSV", &controllers.MainController{}, "post:SetSessionValues")

	//人事员工信息模块
	beego.Router("/erp/user/add", &controllers.UserController{}, "*:AddHtml")
	beego.Router("/erp/user/list", &controllers.UserController{}, "*:ListHtml")
	beego.Router("/erp/user/update/:id", &controllers.UserController{}, "get:UpdateUserHtml")
	beego.Router("/erp/user/updateBase/:id", &controllers.UserController{}, "get:UpdateUserBaseHtml")
	beego.Router("/erp/user/updatePost/:id", &controllers.UserController{}, "get:UpdateUserPostHtml")
	beego.Router("/erp/user/updateSalary/:id", &controllers.UserController{}, "get:UpdateUserSalaryHtml")

	beego.Router("/erp/user/userDoAdd", &controllers.UserController{}, "post:UserDoAdd")
	beego.Router("/erp/user/userDoSelect", &controllers.UserController{}, "get:UserDoSelect")
	beego.Router("/erp/user/userDoUpdate", &controllers.UserController{}, "put:UserDoUpdate")
	beego.Router("/erp/user/userDoUpdateBase", &controllers.UserController{}, "put:UserDoUpdateBase")
	beego.Router("/erp/user/userDoUpdatePost", &controllers.UserController{}, "put:UserDoUpdatePost")
	beego.Router("/erp/user/userDoUpdateSalary", &controllers.UserController{}, "put:UserDoUpdateSalary")
	beego.Router("/erp/user/userDoDelete/:id", &controllers.UserController{}, "delete:UserDoDelete")
	beego.Router("/erp/user/userDoRegular/:id", &controllers.UserController{}, "put:UserDoRegular")
	//员工批量导入
	beego.Router("/erp/user/importByExcel", &controllers.UserController{}, "post:UserAddByExcel")
	beego.Router("/erp/user/outputToExcel", &controllers.UserController{}, "get:OutputUserExcel")
	// 选岗位属性获得职级
	beego.Router("/erp/user/getRankByType", &controllers.UserController{}, "get:GetRankByType")
	// 选部门获得角色信息
	beego.Router("/erp/user/getRoleByDepartId", &controllers.UserController{}, "get:GetRoleByDepartId")
	// 选部门获取相关用户数据
	beego.Router("/erp/user/getUsersByDepartId", &controllers.UserController{}, "get:GetUsersByDepartId")

	//人事模块-更加公司id和部门id获取用户信息
	beego.Router("/erp/user/userComDepList", &controllers.UserController{}, "*:CompanyDepartmentUserList")

	//人事模块-部门管理
	beego.Router("/erp/user/departAdd", &controllers.UserController{}, "*:DepartMentAddHtml")
	beego.Router("/erp/user/departDoAdd", &controllers.UserController{}, "*:DepartMentDoAdd")
	beego.Router("/erp/user/departUpdate/:id", &controllers.UserController{}, "*:DepartMentUpdateHtml")
	beego.Router("/erp/user/departDoUpdate", &controllers.UserController{}, "*:DepartMentDoUpdate")
	beego.Router("/erp/user/departList", &controllers.UserController{}, "*:DepartMentList")
	beego.Router("/erp/user/departSet/:id", &controllers.UserController{}, "*:DepartMentSetHtml")
	beego.Router("/erp/user/departDoSet", &controllers.UserController{}, "*:DepartMentDoSet")
	beego.Router("/erp/user/departComUserList", &controllers.UserController{}, "*:DepartComUserList")
	beego.Router("/erp/user/departComUserDel", &controllers.UserController{}, "*:DepartComUserDel")
	beego.Router("/erp/user/companyUserList", &controllers.UserController{}, "*:CompanyUserList")
	//人事模块-年假查询
	beego.Router("/erp/user/annualLeaveListHtml", &controllers.UserController{}, "*:AnnualLeaveListHtml")
	beego.Router("/erp/user/annualLeaveList", &controllers.UserController{}, "*:AnnualLeaveList")
	beego.Router("/erp/user/exportAnnualLeave", &controllers.UserController{}, "*:ExportAnnualLeave")
	beego.Router("/erp/user/importAnnualLeave", &controllers.UserController{}, "*:ImportAnnualLeave")
	//人事模块-员工工资
	beego.Router("/erp/user/payrollListHtml", &controllers.UserController{}, "*:PayrollListHtml")
	beego.Router("/erp/user/payrollList", &controllers.UserController{}, "*:PayrollList")
	beego.Router("/erp/user/calculatePay", &controllers.UserController{}, "*:CalculatePay")
	beego.Router("/erp/user/setPayRollOtherHtml/:id", &controllers.UserController{}, "*:SetPayRollOtherHtml")
	beego.Router("/erp/user/setPayRollOther", &controllers.UserController{}, "*:SetPayRollOther")

	//设置-业务线管理
	beego.Router("/erp/set/businessAdd", &controllers.SetController{}, "*:BusinessAddHtml")
	beego.Router("/erp/set/businessDoAdd", &controllers.SetController{}, "*:BusinessDoAdd")
	beego.Router("/erp/set/businessUpdate/:id", &controllers.SetController{}, "*:BusinessUpdateHtml")
	beego.Router("/erp/set/businessDoUpdate", &controllers.SetController{}, "*:BusinessDoUpdate")
	beego.Router("/erp/set/businessDoUpdateStatus", &controllers.SetController{}, "*:BusinessDoUpdateStatus")
	beego.Router("/erp/set/businessList", &controllers.SetController{}, "*:BusinessList")

	//设置-权限模块
	beego.Router("/erp/set/authorization", &controllers.SetController{}, "*:AuthorizationHtml")
	beego.Router("/erp/set/modulesByRoleId", &controllers.SetController{}, "*:ModulesByRoleId")
	beego.Router("/erp/set/roleModuleDoUpdate", &controllers.SetController{}, "*:RoleModuleDoUpdate")
	beego.Router("/erp/set/userRoleUpate", &controllers.SetController{}, "*:UserRoleDoUpate")

	//设置-岗位管理
	beego.Router("/erp/set/roleAdd", &controllers.SetController{}, "*:RoleAddHtml")
	beego.Router("/erp/set/roleDoAdd", &controllers.SetController{}, "*:RoleDoAdd")
	beego.Router("/erp/set/roleUpdate/:id", &controllers.SetController{}, "*:RoleUpdateHtml")
	beego.Router("/erp/set/roleDoUpdate", &controllers.SetController{}, "*:RoleDoUpdate")
	beego.Router("/erp/set/roleList", &controllers.SetController{}, "*:RoleList")

	//设置-区域管理
	beego.Router("/erp/set/areaAdd", &controllers.SetController{}, "*:AreaAddHtml")
	beego.Router("/erp/set/areaDoAdd", &controllers.SetController{}, "*:AreaDoAdd")
	beego.Router("/erp/set/areaUpdate/:id", &controllers.SetController{}, "*:AreaUpdateHtml")
	beego.Router("/erp/set/areaDoUpdate", &controllers.SetController{}, "*:AreaDoUpdate")
	beego.Router("/erp/set/areaList", &controllers.SetController{}, "*:AreaList")

	//设置-职级管理
	beego.Router("/erp/set/rankAdd", &controllers.SetController{}, "*:RankAddHtml")
	beego.Router("/erp/set/rankDoAdd", &controllers.SetController{}, "*:RankDoAdd")
	beego.Router("/erp/set/rankList", &controllers.SetController{}, "*:RankList")

	//设置-社保公积金
	beego.Router("/erp/set/ssfhtml", &controllers.SocialSecurityFundController{}, "*:SSFHtml")
	beego.Router("/erp/set/ssfDoAdd", &controllers.SocialSecurityFundController{}, "*:SSFDoAdd")
	beego.Router("/erp/set/ssfDoUdapte", &controllers.SocialSecurityFundController{}, "*:SSFDoUpdate")

	//客户模块-新建
	beego.Router("/erp/customer/customerAdd", &controllers.CustomerController{}, "*:CustomerNewHtml")
	//客户模块-审核
	beego.Router("/erp/customer/customerExamine", &controllers.CustomerController{}, "*:CustomerExamineHtml")
	//客户模块-查询
	beego.Router("/erp/customer/customerSelect", &controllers.CustomerController{}, "*:CustomerSelectHtml")
	beego.Router("/erp/customer/customerDoAdd", &controllers.CustomerController{}, "post:CustomerDoAdd")
	beego.Router("/erp/customer/customerData", &controllers.CustomerController{}, "*:GetDatas")
	beego.Router("/erp/customer/contactsDetail/:id/:status", &controllers.CustomerController{}, "*:ContactsHtml")
	beego.Router("/erp/customer/contactsData/:id", &controllers.CustomerController{}, "*:GetContacts")
	beego.Router("/erp/customer/contactDoDel", &controllers.CustomerController{}, "*:DoDelContact")
	beego.Router("/erp/customer/contactsUpate/:id", &controllers.CustomerController{}, "*:ContactsUpdateHtml")
	beego.Router("/erp/customer/contactsDoUpate", &controllers.CustomerController{}, "*:DoUpdateContact")
	beego.Router("/erp/customer/contactsAdd/:id", &controllers.CustomerController{}, "*:ContactsAddHtml")
	beego.Router("/erp/customer/contactsDoAdd", &controllers.CustomerController{}, "*:ContactsDoAdd")
	beego.Router("/erp/customer/customerUpdate/:id", &controllers.CustomerController{}, "*:CustomerUpdateHtml")
	beego.Router("/erp/customer/customerDoUpdate", &controllers.CustomerController{}, "*:CustomerDoUpdate")
	beego.Router("/erp/customer/customerExamineData", &controllers.CustomerController{}, "*:CustomerExamineData")
	beego.Router("/erp/customer/customerDoExamine", &controllers.CustomerController{}, "*:CustomerDoExamine")

	// 合同模块
	//页面路由
	beego.Router("/erp/contract/contractAdd", &controllers.ContractController{}, "get:ContractAddHtml")           // 合同添加
	beego.Router("/erp/contract/contractPurchase", &controllers.ContractController{}, "get:ContractPurchaseHtml") //采购合同查看
	beego.Router("/erp/contract/contractSales", &controllers.ContractController{}, "get:ContractSalesHtml")       // 销售合同查看
	beego.Router("/erp/contract/contractDetail/:id", &controllers.ContractController{}, "get:ContractDetailHtml") // 单条合同详情
	beego.Router("/erp/contract/contractVerify", &controllers.ContractController{}, "get:ContractVerifyHtml")     // 合同审核
	// 合同行为路由
	beego.Router("/erp/contract/contractUpload", &controllers.ContractController{}, "post:ContractUpload")                   // 合同文件上传, 表单中的上传文件
	beego.Router("/erp/contract/contractUploadById/:id", &controllers.ContractController{}, "post:ContractUploadById")       // 根据合同id上传文件
	beego.Router("/erp/contract/contractDoAdd", &controllers.ContractController{}, "post:ContractDoAdd")                     // 合同表单提交添加路由
	beego.Router("/erp/contract/contractSelect", &controllers.ContractController{}, "get:ContractSelectAll")                 // 合同查询接口
	beego.Router("/erp/contract/contractDoUpdate/:id", &controllers.ContractController{}, "put:ContractUpdateById")          // 合同更新接口
	beego.Router("/erp/contract/contractDoDelete/:id", &controllers.ContractController{}, "delete:ContractDeleteById")       // 合同删除接口
	beego.Router("/erp/contract/contractSelectCheck", &controllers.ContractController{}, "get:ContractGetCheckList")         // 合同审核查询接口,会根据用户的角色自动过滤
	beego.Router("/erp/contract/contractCheckPass/:id", &controllers.ContractController{}, "post:ContractDoCheckPass")       // 合同通过接口
	beego.Router("/erp/contract/contractCheckNotPass/:id", &controllers.ContractController{}, "post:ContractDoCheckNotPass") // 合同不通过接口
	// 返点模块路由
	beego.Router("/erp/rebate/getRebatesByCid/:id", &controllers.ReabseController{}, "get:GetReabetByCid")

	// 报销模块
	// 报销页面路由
	beego.Router("/erp/reimburse/ordReimburseApply", &controllers.ReimburseController{}, "get:OrdReimburseApplyHtml")
	beego.Router("/erp/reimburse/traReimburseApply", &controllers.ReimburseController{}, "get:TraReimburseApplyHtml")
	beego.Router("/erp/reimburse/reimburseList", &controllers.ReimburseController{}, "get:ReimburseListHtml")
	beego.Router("/erp/reimburse/reimburseVerify", &controllers.ReimburseController{}, "get:ReimburseVerifyHtml")
	beego.Router("/erp/reimburse/reimbursePayment", &controllers.ReimburseController{}, "get:ReimbursePaymentHtml")
	// 报销行为路由
	// 普通报销
	beego.Router("/erp/reimburse/ordReimburseDoApply", &controllers.ReimburseController{}, "post:OrdReimburseDoApply")
	beego.Router("/erp/reimburse/ordReimburseSelect", &controllers.ReimburseController{}, "get:GetOrdReimburseList")
	// 报销审核查询
	beego.Router("/erp/reimburse/ordReimburseExamineData", &controllers.ReimburseController{}, "*:OrdReimburseExamineData")
	// 打开报销详情页面
	beego.Router("/erp/reimburse/ordReimburseSeeDetails/:id", &controllers.ReimburseController{}, "get:SelectOrdDetailsHtml")
	// 查询报销详情列表
	beego.Router("/erp/reimburse/ordReimburseDetails/:id", &controllers.ReimburseController{}, "get:SelectOrdDetails")
	// 普通审核报销信息
	beego.Router("/erp/reimburse/ordReimburseDoExamine", &controllers.ReimburseController{}, "post:OrdReimburseDoExamine")
	// 普通报销待放款数据
	beego.Router("/erp/reimburse/ordReimbursePayData", &controllers.ReimburseController{}, "get:OrdReimbursePayData")
	// 普通报销放款
	beego.Router("/erp/reimburse/ordReimburseDoPay", &controllers.ReimburseController{}, "post:OrdReimburseDoPay")
	// 普通报销文件补传
	beego.Router("/erp/reimburse/ordReimburseUpload/:id", &controllers.ReimburseController{}, "post:OrdReimburseUploadById")

	//差旅报销

	//报销-差旅报销
	beego.Router("/erp/reimburse/traReimburseDoApply", &controllers.ReimburseController{}, "post:TraReimburseDoApply")
	//差旅报销查询
	beego.Router("/erp/reimburse/traReimburseData", &controllers.ReimburseController{}, "*:TraReimburseData")
	//差旅报销审核查询
	beego.Router("/erp/reimburse/traReimburseExamineData", &controllers.ReimburseController{}, "*:TraReimburseExamineData")
	//打开报销详情页面
	beego.Router("/erp/reimburse/traReimburseSeeDetails/:id", &controllers.ReimburseController{}, "*:SelectTraDetailsHtml")
	//查询报销详情列表
	beego.Router("/erp/reimburse/traReimburseDetails/:id", &controllers.ReimburseController{}, "*:SelectTraDetails")
	//差旅审核报销信息
	beego.Router("/erp/reimburse/travelReimburseDoExamine", &controllers.ReimburseController{}, "*:TravelReimburseDoExamine")
	//差旅报销待放款数据
	beego.Router("/erp/reimburse/travelReimbursePayData", &controllers.ReimburseController{}, "*:TravelReimbursePayData")
	//差旅报销放款
	beego.Router("/erp/reimburse/travelReimburseDoPay", &controllers.ReimburseController{}, "*:TravelReimburseDoPay")
	// 差旅报销文件上次更新数据
	beego.Router("/erp/reimburse/traReimburseUpload/:id", &controllers.ReimburseController{}, "post:TraReimburseUploadById")

	//借款模块
	beego.Router("/erp/borrow/borrowAdd", &controllers.BorrowController{}, "*:BorrowAddHtml")
	beego.Router("/erp/borrow/borrowDoAdd", &controllers.BorrowController{}, "*:BorrowDoAdd")
	beego.Router("/erp/borrow/borrowList", &controllers.BorrowController{}, "*:BorrowListHtml")
	beego.Router("/erp/borrow/borrowListData", &controllers.BorrowController{}, "*:BorrowList")
	beego.Router("/erp/borrow/borrowDoExamine", &controllers.BorrowController{}, "*:BorrowDoExamine")
	beego.Router("/erp/borrow/borrowSelect", &controllers.BorrowController{}, "*:BorrowSelectHtml")
	beego.Router("/erp/borrow/borrowPay", &controllers.BorrowController{}, "*:BorrowPayHtml")
	beego.Router("/erp/borrow/borrowPayData", &controllers.BorrowController{}, "*:BorrowPayData")
	beego.Router("/erp/borrow/borrowSelectData", &controllers.BorrowController{}, "*:BorrowSelectData")
	beego.Router("/erp/borrow/borrowDoPay", &controllers.BorrowController{}, "*:BorrowDoPay")

	//通知模块
	beego.Router("/erp/notice/noticeAddHtml", &controllers.NoiceController{}, "*:NoticeAddHtml")
	beego.Router("/erp/notice/noticeDoAdd", &controllers.NoiceController{}, "*:NoticeDoAdd")
	beego.Router("/erp/notice/noticeList", &controllers.NoiceController{}, "*:NoticeList")
	beego.Router("/erp/notice/noticeExamineHtml", &controllers.NoiceController{}, "*:NoticeExamineHtml")
	beego.Router("/erp/notice/noticeExamineList", &controllers.NoiceController{}, "*:NoticeExamineList")
	beego.Router("/erp/notice/noticeDoExamine", &controllers.NoiceController{}, "*:NoticeDoExamine")
	beego.Router("/erp/notice/noticeUpdateHtml/:id", &controllers.NoiceController{}, "*:NoticeUpdateHtml")
	beego.Router("/erp/notice/noticeDoUpdate", &controllers.NoiceController{}, "*:NoticeDoUpdate")
	beego.Router("/erp/notice/noticeDoDel", &controllers.NoiceController{}, "*:NoticeDoDel")
	beego.Router("/erp/notice/noticeDoDelFile", &controllers.NoiceController{}, "*:NoticeDoDelFile")

	//个人模块

	//个人模块-通知查看
	beego.Router("/erp/personal/noticeHtml", &controllers.PersonalController{}, "*:NoticeHtml")
	beego.Router("/erp/personal/noticeList", &controllers.PersonalController{}, "*:NoticeList")
	beego.Router("/erp/personal/internalHtml", &controllers.PersonalController{}, "get:InternalHtml")     // 內推查看页面
	beego.Router("/erp/personal/internalSelect", &controllers.PersonalController{}, "get:InternalSelect") // 內推数据获取

	//个人模块-年假查询模块
	beego.Router("/erp/personal/annualLeaveHtml", &controllers.PersonalController{}, "*:AnnualLeaveHtml")
	beego.Router("/erp/personal/annualLeave", &controllers.PersonalController{}, "*:AnnualLeave")
	//个人模块-工资条
	//人事模块-员工工资
	beego.Router("/erp/personal/payrollHtml", &controllers.PersonalController{}, "*:PayrollHtml")
	beego.Router("/erp/personal/payroll", &controllers.PersonalController{}, "*:Payroll")

	// 招聘模块
	beego.Router("/erp/recruit/recruitAdd", &controllers.RecruitController{}, "get:RecruitAddHtml")           // 招聘需求添加
	beego.Router("/erp/recruit/recruitVerify", &controllers.RecruitController{}, "get:RecruitVerifyHtml")     // 招聘需求审核
	beego.Router("/erp/recruit/recruitList", &controllers.RecruitController{}, "get:RecruitListHtml")         // 审核后招聘需求查看
	beego.Router("/erp/recruit/recruitDetail/:id", &controllers.RecruitController{}, "get:RecruitDetailHtml") // 招聘需求详情页面
	// 招聘模块行为路由
	beego.Router("/erp/recruit/recruitDoAdd", &controllers.RecruitController{}, "post:RecruitDoAdd")                    // 招聘需求添加行为
	beego.Router("/erp/recruit/recruitSelectByUser", &controllers.RecruitController{}, "get:RecruitSelectByCreateUser") // 根据创建人查询对应的招聘需求
	beego.Router("/erp/recruit/recruitSelectByVerify", &controllers.RecruitController{}, "get:RecruitSelectByVerify")   // 根据审核状态进行过滤查询
	beego.Router("/erp/recruit/recruitDoVerify/:id", &controllers.RecruitController{}, "put:RecruitDoVerify")           // 根据需求Id进行审核状态变更
	beego.Router("/erp/recruit/recruitHadDo/:id", &controllers.RecruitController{}, "put:RecruitHadDo")                 // 完成招聘行为
	beego.Router("/erp/recruit/recruitSelectHadPass", &controllers.RecruitController{}, "get:RecruitSelectHadPass")
	beego.Router("/erp/recruit/recruitDoInternal/:id", &controllers.RecruitController{}, "put:RecruitDoInternal")       // 招聘內推状态变更

	//社保公积金查询模块
	beego.Router("/erp/ssf/ssfSelectHtml", &controllers.SocialSecurityFundController{}, "*:SSFSelectHtml")
	beego.Router("/erp/ssf/ssfSelect", &controllers.SocialSecurityFundController{}, "*:SSFSelect")

	// 岗位,薪资变更记录获取
	beego.Router("/erp/record/postRecord/:id", &controllers.PostRecordController{}, "get:PostRecordHtml")                // 岗位变动页面
	beego.Router("/erp/record/salaryRecord/:id", &controllers.SalaryRecordController{}, "get:SalaryRecordHtml")          // 薪资变动页面
	beego.Router("/erp/record/postRecordSelect/:id", &controllers.PostRecordController{}, "get:GetPostRecordById")       // 岗位变动记录
	beego.Router("/erp/record/salaryRecordSelect/:id", &controllers.SalaryRecordController{}, "get:GetSalaryRecordById") // 薪资变动记录

	//绩效模块
	beego.Router("/erp/performance/performanceAddHtml", &controllers.PerformanceController{}, "*:PerformanceAddHtml")
	beego.Router("/erp/performance/performanceDoAdd", &controllers.PerformanceController{}, "*:PerformanceDoAdd")
	beego.Router("/erp/performance/performanceHRListHtml", &controllers.PerformanceController{}, "*:PerformanceHRListHtml")
	beego.Router("/erp/performance/performanceList", &controllers.PerformanceController{}, "*:PerformanceList")
	beego.Router("/erp/performance/performanceHRList", &controllers.PerformanceController{}, "*:PerformanceHRList")
	beego.Router("/erp/performance/performanceExamineHtml", &controllers.PerformanceController{}, "*:PerformanceExamineHtml")
	beego.Router("/erp/performance/performanceDoExamine", &controllers.PerformanceController{}, "*:PerformanceDoExamine")
	beego.Router("/erp/performance/performanceExamineList", &controllers.PerformanceController{}, "*:PerformanceExamineList")
	beego.Router("/erp/performance/performanceUpdateHtml/:id", &controllers.PerformanceController{}, "*:PerformanceUpdateHtml")
	beego.Router("/erp/performance/performanceDoUpdate", &controllers.PerformanceController{}, "*:PerformanceDoUpdate")
	beego.Router("/erp/performance/performanceApplyUpdate", &controllers.PerformanceController{}, "*:PerformanceApplyUpdate")
	beego.Router("/erp/performance/performanceExamineApply", &controllers.PerformanceController{}, "*:PerformanceExamineApply")
	beego.Router("/erp/performance/performanceExportExcel/*:month", &controllers.PerformanceController{}, "*:ExportExcel")

	//请假模块
	beego.Router("/erp/leave/leaveAddHtml", &controllers.LeaveController{}, "*:LeaveAddHtml")
	beego.Router("/erp/leave/leaveDoAdd", &controllers.LeaveController{}, "*:LeaveDoAdd")
	beego.Router("/erp/leave/leaveSelfList", &controllers.LeaveController{}, "*:SelectSelfList")
	beego.Router("/erp/leave/leaveExamineHtml", &controllers.LeaveController{}, "*:ExamineHtml")
	beego.Router("/erp/leave/leaveExamineList", &controllers.LeaveController{}, "*:ExamineList")
	beego.Router("/erp/leave/leaveDoExamine", &controllers.LeaveController{}, "*:DoExamine")
	beego.Router("/erp/leave/leaveDoDel", &controllers.LeaveController{}, "*:DoDel")
	beego.Router("/erp/leave/leaveListHtml", &controllers.LeaveController{}, "*:ListHtml")
	beego.Router("/erp/leave/leaveList", &controllers.LeaveController{}, "*:List")
	beego.Router("/erp/leave/leaveExportExcel", &controllers.LeaveController{}, "*:ExportExcel")
	beego.Router("/erp/leave/leaveOffHtml/:id", &controllers.LeaveController{}, "*:LeaveOffHtml")
	beego.Router("/erp/leave/leaveDoOff", &controllers.LeaveController{}, "*:LeaveDoOff")
	beego.Router("/erp/leave/leaveOffExamineHtml", &controllers.LeaveController{}, "*:LeaveOffExamineHtml")
	beego.Router("/erp/leave/leaveHROffExamineList", &controllers.LeaveController{}, "*:LeaveHROffExamineList")
	beego.Router("/erp/leave/leaveDoOffExamine", &controllers.LeaveController{}, "*:LeaveDoOffExamine")

	beego.Router("/erp/leave/leaveDelayHtml/:id", &controllers.LeaveController{}, "*:LeaveDelayHtml")
	beego.Router("/erp/leave/leaveDoDelay", &controllers.LeaveController{}, "*:LeaveDoDelay")
	beego.Router("/erp/leave/leaveDelayExamineHtml", &controllers.LeaveController{}, "*:LeaveDelayExamineHtml")
	beego.Router("/erp/leave/leaveHRDelayExamineList", &controllers.LeaveController{}, "*:LeaveHRDelayExamineList")
	beego.Router("/erp/leave/leaveDoDelayExamine", &controllers.LeaveController{}, "*:LeaveDoDelayExamine")

	// 异动模块
	beego.Router("/erp/abnormal/abnormalApplyHtml", &controllers.AbnormalChangeController{}, "get:AbnormalChangeApplyHtml")
	beego.Router("/erp/abnormal/abnormalVerifyHtml", &controllers.AbnormalChangeController{}, "get:AbnormalChangeVerifyHtml")
	beego.Router("/erp/abnormal/abnormalListHtml", &controllers.AbnormalChangeController{}, "get:AbnormalChangeListHtml")

	beego.Router("/erp/abnormal/abnormalApplyDoAdd", &controllers.AbnormalChangeController{}, "post:AbnormalChangeApplyDoAdd")
	beego.Router("/erp/abnormal/abnormalSelectByUser", &controllers.AbnormalChangeController{}, "get:AbnormalChangeSelectByUser")
	beego.Router("/erp/abnormal/abnormalSelectVerify", &controllers.AbnormalChangeController{}, "get:AbnormalChangeSelectVerify")
	beego.Router("/erp/abnormal/abnormalDoVerify/:id", &controllers.AbnormalChangeController{}, "put:AbnormalChangeDoVerify")
	beego.Router("/erp/abnormal/abnormalSelectHadPass", &controllers.AbnormalChangeController{}, "get:AbnormalChangeSelectHadPass")

	// 加班模块
	beego.Router("/erp/overtime/workOvertimeApplyHtml", &controllers.WorkOvertimeController{}, "get:WorkOvertimeApplyHtml")
	beego.Router("/erp/overtime/workOvertimeListHtml", &controllers.WorkOvertimeController{}, "get:WorkOvertimeListHtml")
	beego.Router("/erp/overtime/workOvertimeVerifyHtml", &controllers.WorkOvertimeController{}, "get:WorkOvertimeVerifyHtml")

	beego.Router("/erp/overtime/workOvertimeDoAdd", &controllers.WorkOvertimeController{}, "post:WorkOvertimeDoAdd")
	beego.Router("/erp/overtime/workOvertimeSelectByUser", &controllers.WorkOvertimeController{}, "get:WorkOvertimeSelectByUser")
	beego.Router("/erp/overtime/workOvertimeSelectVerify", &controllers.WorkOvertimeController{}, "get:WorkOvertimeSelectVerify")
	beego.Router("/erp/overtime/workOvertimeDoVerify/:id", &controllers.WorkOvertimeController{}, "put:WorkOvertimeDoVerify")
	beego.Router("/erp/overtime/workOvertimeSelectHadPass", &controllers.WorkOvertimeController{}, "get:WorkOvertimeSelectHadPass")
	beego.Router("/erp/overtime/worKOvertimeOutputExcel", &controllers.WorkOvertimeController{}, "get:OutputWorkOvertime")

	//考勤模块
	beego.Router("/erp/attendance/annualHtml", &controllers.AttendanceController{}, "*:AnnualHtml")
	beego.Router("/erp/attendance/annualList", &controllers.AttendanceController{}, "*:AnnualList")
	beego.Router("/erp/attendance/annualLeaveExportExcel", &controllers.AttendanceController{}, "*:AnnualLeaveExportExcel")
	beego.Router("/erp/attendance/attendanceFileUploadHtml", &controllers.AttendanceController{}, "*:AttendanceFileUploadHtml")
	beego.Router("/erp/attendance/attendanceFileUpload", &controllers.AttendanceController{}, "*:AttendanceFileUpload")
	beego.Router("/erp/attendance/attendanceListHtml", &controllers.AttendanceController{}, "*:AttendanceListHtml")
	beego.Router("/erp/attendance/attendanceList", &controllers.AttendanceController{}, "*:AttendanceList")
	// 考勤模块中的补卡功能
	beego.Router("/erp/attendance/supplementApplyHtml", &controllers.AttendanceController{}, "get:SupplementApplyHtml")   // 补卡申请页面
	beego.Router("/erp/attendance/supplementVerifyHtml", &controllers.AttendanceController{}, "get:SupplementVerifyHtml") // 补卡审核页面
	beego.Router("/erp/attendance/supplementListHtml", &controllers.AttendanceController{}, "get:SupplementListHtml")     // 补卡通过记录页面

	beego.Router("/erp/attendance/supplementApplyDoAdd", &controllers.AttendanceController{}, "post:SupplementApplyDoAdd")      // 添加行为
	beego.Router("/erp/attendance/supplementSelectByUser", &controllers.AttendanceController{}, "get:SupplementSelectByUser")   // 搜索用户的补卡
	beego.Router("/erp/attendance/supplementSelectVerify", &controllers.AttendanceController{}, "get:SupplementSelectVerify")   // 搜索待审核的补卡记录
	beego.Router("/erp/attendance/supplementDoVerify/:id", &controllers.AttendanceController{}, "put:SupplementDoVerify")       // 审核i行为
	beego.Router("/erp/attendance/supplementSelectHadPass", &controllers.AttendanceController{}, "get:SupplementSelectHadPass") // 搜索审核通过的补卡记录

	// 采购模块
	beego.Router("/erp/purchase/purchaseApplyHtml", &controllers.PurchaseController{}, "get:PurchaseApplyHtml")
	beego.Router("/erp/purchase/purchaseExamineHtml", &controllers.PurchaseController{}, "get:PurchaseExamineHtml")
	beego.Router("/erp/purchase/purchaseListHtml", &controllers.PurchaseController{}, "get:PurchaseListHtml")

	beego.Router("/erp/purchase/purchaseApplyDoAdd", &controllers.PurchaseController{}, "post:PurchaseApplyDoAdd")
	beego.Router("/erp/purchase/purchaseSelectByUser", &controllers.PurchaseController{}, "get:PurchaseSelectByUser")
	beego.Router("/erp/purchase/purchaseSelectExamine", &controllers.PurchaseController{}, "get:PurchaseSelectExamine")
	beego.Router("/erp/purchase/purchaseDoExamine/:id", &controllers.PurchaseController{}, "put:PurchaseDoExamine")
	beego.Router("/erp/purchase/purchaseSelectHadPass", &controllers.PurchaseController{}, "get:PurchaseSelectHadPass")
}
